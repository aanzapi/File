//JANGAN LU MALING
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'dart:ui';

// ===== GLOBAL THEME COLOR (Hitam Putih dengan aksen merah) =====
const Color primaryWhite = Colors.white;
const Color secondaryGrey = Color(0xFF9CA3AF);
const Color backgroundBlack = Color(0xFF000000);
const Color glassWhite = Color(0x0DFFFFFF);
const Color borderGrey = Color(0x1AFFFFFF);
const Color accentRed = Color(0xFFFF0000);
const Color subtleRed = Color(0x33FF0000);

class GroupBugPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const GroupBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<GroupBugPage> createState() => _GroupBugPageState();
}

class _GroupBugPageState extends State<GroupBugPage> with TickerProviderStateMixin {
  final linkGroupController = TextEditingController();
  static const String baseUrl = "http://server.aanz-panel.web.id:2000";

  // Animation controllers
  late AnimationController _buttonController;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _glowController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _glowAnimation;

  // Video controllers for banner
  late VideoPlayerController _bannerController;
  bool _bannerInitialized = false;
  bool _bannerError = false;

  // State variables
  bool _isSending = false;
  int _activeStep = 0;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeBannerVideo();
    _startAnimations();
  }

  void _initializeAnimations() {
    _buttonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));

    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  void _initializeBannerVideo() {
    try {
      _bannerController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _bannerInitialized = true;
            });
            _bannerController.setLooping(true);
            _bannerController.play();
            _bannerController.setVolume(0);
          }
        }).catchError((error) {
          print('Banner video initialization error: $error');
          if (mounted) {
            setState(() {
              _bannerError = true;
            });
          }
        });
    } catch (e) {
      print('Banner controller creation error: $e');
      if (mounted) {
        setState(() {
          _bannerError = true;
        });
      }
    }
  }

  bool _isValidGroupLink(String input) {
    final regex = RegExp(r'https://chat\.whatsapp\.com/[a-zA-Z0-9]{22}');
    return regex.hasMatch(input);
  }

  Future<void> _sendGroupBug() async {
    if (_isSending) return;

    setState(() {
      _isSending = true;
      _activeStep = 1;
    });

    _buttonController.forward().then((_) {
      _buttonController.reverse();
    });

    final linkGroup = linkGroupController.text.trim();
    final key = widget.sessionKey;

    if (linkGroup.isEmpty || !_isValidGroupLink(linkGroup)) {
      _showAlert("❌ Invalid Link", "Please enter a valid WhatsApp group link.");
      setState(() {
        _isSending = false;
        _activeStep = 0;
      });
      return;
    }

    try {
      final res = await http.get(Uri.parse("$baseUrl/api/whatsapp/groupBug?key=$key&linkGroup=$linkGroup"));
      final data = jsonDecode(res.body);

      if (data["valid"] == false) {
        _showAlert("❌ Failed", data["message"] ?? "Failed to send group bug.");
      } else {
        setState(() {
          _activeStep = 2;
        });
        _showSuccessPopup(linkGroup, data);
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
        if (_activeStep != 2) _activeStep = 0;
      });
    }
  }

  void _showSuccessPopup(String linkGroup, Map<String, dynamic> data) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => GroupBugSuccessDialog(
        linkGroup: linkGroup,
        data: data,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() {
            _activeStep = 0;
          });
        },
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: backgroundBlack.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: borderGrey, width: 1),
        ),
        title: Text(title, style: const TextStyle(color: primaryWhite, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: accentRed)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Only allow access to VIP and Owner roles
    if (!["vip", "owner"].contains(widget.role.toLowerCase())) {
      return Scaffold(
        backgroundColor: backgroundBlack,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _glowController,
                builder: (context, child) {
                  return Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: accentRed.withOpacity(0.1 + 0.1 * _glowAnimation.value),
                      borderRadius: BorderRadius.circular(100),
                      border: Border.all(
                        color: accentRed.withOpacity(0.3 + 0.2 * _glowAnimation.value),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: accentRed.withOpacity(0.2 * _glowAnimation.value),
                          blurRadius: 20,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: const Icon(
                      FontAwesomeIcons.lock,
                      color: accentRed,
                      size: 60,
                    ),
                  );
                },
              ),
              const SizedBox(height: 20),
              const Text(
                "ACCESS DENIED",
                style: TextStyle(
                  color: accentRed,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "This feature is only available for VIP and Owner users",
                style: TextStyle(
                  color: primaryWhite.withOpacity(0.7),
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: backgroundBlack,
      body: Stack(
        children: [
          // Pure black background
          Container(color: backgroundBlack),

          // Banner video at the top
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 200,
            child: _buildBannerVideo(),
          ),

          // Dark gradient overlay for smooth transition
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 220,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    backgroundBlack.withOpacity(0.3),
                    backgroundBlack.withOpacity(0.6),
                    backgroundBlack,
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),

          // Main content
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const SizedBox(height: 140), // Space for banner

                        // User info header with glassmorphism
                        _buildUserInfoHeader(),

                        const SizedBox(height: 20),

                        // Progress indicator
                        _buildProgressIndicator(),

                        const SizedBox(height: 20),

                        // Group link input card
                        _buildGroupLinkCard(),

                        const SizedBox(height: 20),

                        _buildSendButton(),

                        const SizedBox(height: 14),

                        _buildFooterInfo(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBannerVideo() {
    if (_bannerInitialized && !_bannerError) {
      return Container(
        width: double.infinity,
        height: 200,
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _bannerController.value.size.width,
            height: _bannerController.value.size.height,
            child: VideoPlayer(_bannerController),
          ),
        ),
      );
    } else {
      return Container(
        width: double.infinity,
        height: 200,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              accentRed.withOpacity(0.3),
              backgroundBlack,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Icon(
            FontAwesomeIcons.skull,
            color: accentRed.withOpacity(0.3),
            size: 80,
          ),
        ),
      );
    }
  }

  Widget _buildProgressIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: glassWhite,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderGrey),
      ),
      child: Row(
        children: [
          _buildStepIndicator(0, "Input", FontAwesomeIcons.link),
          _buildProgressLine(),
          _buildStepIndicator(1, "Process", FontAwesomeIcons.cogs),
          _buildProgressLine(),
          _buildStepIndicator(2, "Complete", FontAwesomeIcons.checkCircle),
        ],
      ),
    );
  }

  Widget _buildStepIndicator(int step, String label, IconData icon) {
    final isActive = _activeStep >= step;
    final isCurrent = _activeStep == step;

    return Expanded(
      child: Column(
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isActive ? subtleRed : glassWhite,
              shape: BoxShape.circle,
              border: Border.all(
                color: isActive ? accentRed : borderGrey,
                width: 2,
              ),
              boxShadow: isCurrent
                  ? [
                BoxShadow(
                  color: accentRed.withOpacity(0.2 * _glowAnimation.value),
                  blurRadius: 8,
                  spreadRadius: 1,
                )
              ]
                  : null,
            ),
            child: Icon(
              icon,
              color: isActive ? accentRed : secondaryGrey,
              size: 18,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              color: isActive ? accentRed : secondaryGrey,
              fontSize: 11,
              fontFamily: 'Orbitron',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressLine() {
    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.symmetric(horizontal: 6),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: _activeStep > 0
                ? [accentRed, accentRed.withOpacity(0.3)]
                : [borderGrey, borderGrey],
          ),
        ),
      ),
    );
  }

  Widget _buildUserInfoHeader() {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, child) {
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: glassWhite,
            border: Border.all(
              color: borderGrey,
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: accentRed.withOpacity(0.08 * _glowAnimation.value),
                blurRadius: 25,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: subtleRed,
                  border: Border.all(
                    color: accentRed.withOpacity(0.3),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accentRed.withOpacity(0.15 * _glowAnimation.value),
                      blurRadius: 18,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: Icon(
                  widget.role.toLowerCase() == "vip"
                      ? FontAwesomeIcons.crown
                      : FontAwesomeIcons.userShield,
                  color: accentRed,
                  size: 22,
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.username,
                      style: const TextStyle(
                        color: primaryWhite,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        fontSize: 18,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 6),

                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: subtleRed,
                            border: Border.all(
                              color: accentRed.withOpacity(0.3),
                            ),
                          ),
                          child: Text(
                            widget.role.toUpperCase(),
                            style: const TextStyle(
                              color: accentRed,
                              fontSize: 11,
                              fontFamily: 'ShareTechMono',
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ),

                        const SizedBox(width: 10),

                        Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: const Color(0xFF22C55E),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF22C55E).withOpacity(0.6),
                                blurRadius: 6,
                                spreadRadius: 1,
                              )
                            ],
                          ),
                        ),

                        const SizedBox(width: 6),

                        const Text(
                          "ACTIVE",
                          style: TextStyle(
                            color: Color(0xFF22C55E),
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: subtleRed,
                  border: Border.all(
                    color: accentRed.withOpacity(0.3),
                  ),
                ),
                child: Column(
                  children: [
                    const Icon(
                      FontAwesomeIcons.clock,
                      color: accentRed,
                      size: 14,
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      "EXPIRE",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 9,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      widget.expiredDate,
                      style: const TextStyle(
                        color: accentRed,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildGroupLinkCard() {
    return StatefulBuilder(
      builder: (context, setInnerState) {
        bool isFocused = false;

        return Focus(
          onFocusChange: (value) {
            setInnerState(() {
              isFocused = value;
            });
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 350),
            curve: Curves.easeInOut,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: glassWhite,
              border: Border.all(
                color: isFocused ? accentRed : borderGrey,
                width: 1.2,
              ),
              boxShadow: [
                if (isFocused)
                  BoxShadow(
                    color: accentRed.withOpacity(0.15),
                    blurRadius: 25,
                    spreadRadius: 2,
                  ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: subtleRed,
                        border: Border.all(color: accentRed.withOpacity(0.3)),
                      ),
                      child: const Icon(
                        FontAwesomeIcons.whatsapp,
                        color: accentRed,
                        size: 16,
                      ),
                    ),
                    const SizedBox(width: 14),
                    const Text(
                      "GROUP LINK",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 15,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 22),

                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    color: glassWhite,
                    border: Border.all(
                      color: isFocused ? accentRed : borderGrey,
                      width: 1.2,
                    ),
                  ),
                  child: TextField(
                    controller: linkGroupController,
                    style: const TextStyle(
                      color: primaryWhite,
                      fontSize: 15,
                      fontFamily: 'ShareTechMono',
                    ),
                    cursorColor: accentRed,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: "https://chat.whatsapp.com/XXXXXXXX",
                      hintStyle: TextStyle(
                        color: Colors.white.withOpacity(0.35),
                        fontSize: 14,
                      ),
                      prefixIcon: Icon(
                        FontAwesomeIcons.link,
                        color: accentRed.withOpacity(0.8),
                        size: 18,
                      ),
                      suffixIcon: isFocused
                          ? Icon(
                        FontAwesomeIcons.checkCircle,
                        color: accentRed,
                        size: 16,
                      )
                          : null,
                    ),
                  ),
                ),

                const SizedBox(height: 14),

                Row(
                  children: [
                    Icon(
                      FontAwesomeIcons.circleInfo,
                      size: 12,
                      color: accentRed,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        "Bot joins temporarily, executes the action, and exits automatically.",
                        style: TextStyle(
                          color: secondaryGrey,
                          fontSize: 11,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: accentRed.withOpacity(0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: accentRed.withOpacity(0.1),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: ElevatedButton.icon(
              icon: _isSending
                  ? SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: accentRed,
                  strokeWidth: 2,
                ),
              )
                  : const Icon(FontAwesomeIcons.user, color: accentRed, size: 18),
              label: Text(
                _isSending ? "PROCESSING..." : "ATTACK GROUP",
                style: const TextStyle(
                  fontSize: 16,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.4,
                  color: primaryWhite,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor: accentRed,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: _isSending ? null : _sendGroupBug,
            ),
          ),
        );
      },
    );
  }

  Widget _buildFooterInfo() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: subtleRed,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accentRed.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(
            FontAwesomeIcons.exclamationTriangle,
            color: accentRed,
            size: 14,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "This tool will join the group, send a bug, and leave without any trace.",
              style: TextStyle(
                color: secondaryGrey,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _buttonController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    _glowController.dispose();
    _bannerController.dispose();
    linkGroupController.dispose();
    super.dispose();
  }
}

// Custom success dialog for group bug
class GroupBugSuccessDialog extends StatefulWidget {
  final String linkGroup;
  final Map<String, dynamic> data;
  final VoidCallback onDismiss;

  const GroupBugSuccessDialog({
    super.key,
    required this.linkGroup,
    required this.data,
    required this.onDismiss,
  });

  @override
  State<GroupBugSuccessDialog> createState() => _GroupBugSuccessDialogState();
}

class _GroupBugSuccessDialogState extends State<GroupBugSuccessDialog> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late AnimationController _glowController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;
  bool _showDetails = false;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );

    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    // Show details after a short delay
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) {
        setState(() {
          _showDetails = true;
        });
        _fadeController.forward();
        _scaleController.forward();
      }
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final dialogWidth = screenSize.width * 0.9;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: Center(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: dialogWidth,
          ),
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: ScaleTransition(
              scale: _scaleAnimation,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: backgroundBlack.withOpacity(0.95),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: accentRed.withOpacity(0.3),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accentRed.withOpacity(0.2),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedBuilder(
                      animation: _glowController,
                      builder: (context, child) {
                        return Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: subtleRed,
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(
                              color: accentRed.withOpacity(0.3 * _glowAnimation.value),
                              width: 2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: accentRed.withOpacity(0.2 * _glowAnimation.value),
                                blurRadius: 15,
                                spreadRadius: 3,
                              ),
                            ],
                          ),
                          child: const Icon(
                            FontAwesomeIcons.checkDouble,
                            color: accentRed,
                            size: 40,
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      "GROUP BUG SENT!",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (_showDetails) ...[
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: glassWhite,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: borderGrey),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Attack Details:",
                              style: TextStyle(
                                color: primaryWhite,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                            const SizedBox(height: 12),
                            _buildDetailRow("Group Link", widget.linkGroup),
                            _buildDetailRow("Success", widget.data["success"] ? "Yes" : "No"),
                            if (widget.data["canSendMessage"] != null)
                              _buildDetailRow("Can Send Message", widget.data["canSendMessage"] ? "Yes" : "No"),
                            if (widget.data["groupInfo"] != null) ...[
                              _buildDetailRow("Group Name", widget.data["groupInfo"]["subject"] ?? "Unknown"),
                              _buildDetailRow("Members", widget.data["groupInfo"]["participants"]?.toString() ?? "Unknown"),
                            ],
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: accentRed.withOpacity(0.3)),
                      ),
                      child: TextButton(
                        onPressed: widget.onDismiss,
                        style: TextButton.styleFrom(
                          foregroundColor: accentRed,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: const Text(
                          "DONE",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              "$label:",
              style: TextStyle(
                color: secondaryGrey,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: accentRed,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }
}