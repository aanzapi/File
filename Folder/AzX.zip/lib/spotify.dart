//JANGAN LU MALING
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';

class SpotifyPage extends StatefulWidget {
  const SpotifyPage({super.key});

  @override
  State<SpotifyPage> createState() => _SpotifyPageState();
}

class _SpotifyPageState extends State<SpotifyPage> {
  final TextEditingController _searchController = TextEditingController();
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isLoading = false;
  bool _isPlaying = false;
  bool _hasSearchResult = false;
  Map<String, dynamic>? _trackData;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  @override
  void initState() {
    super.initState();
    _audioPlayer.onPlayerStateChanged.listen((state) {
      if (mounted) {
        setState(() {
          _isPlaying = state == PlayerState.playing;
        });
      }
    });

    _audioPlayer.onDurationChanged.listen((duration) {
      if (mounted) {
        setState(() {
          _duration = duration;
        });
      }
    });

    _audioPlayer.onPositionChanged.listen((position) {
      if (mounted) {
        setState(() {
          _position = position;
        });
      }
    });
  }

  Future<void> _searchTrack() async {
    if (_searchController.text.isEmpty) return;

    setState(() {
      _isLoading = true;
      _hasSearchResult = false;
      _isPlaying = false;
      _position = Duration.zero;
      _duration = Duration.zero;
    });

    try {
      final response = await http.get(
        Uri.parse('https://piantechh.vercel.app/search/spotify?apikey=pian&q=${_searchController.text}'),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == true && data['result'] != null) {
          if (mounted) {
            setState(() {
              _trackData = data;
              _hasSearchResult = true;
            });
            _playTrack();
          }
        } else {
          if (mounted) {
            _showError('Track tidak ditemukan');
          }
        }
      } else {
        if (mounted) {
          _showError('Gagal menghubungi server');
        }
      }
    } catch (e) {
      if (mounted) {
        _showError('Error: ${e.toString()}');
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _playTrack() async {
    try {
      if (_trackData != null && 
          _trackData!['result'] != null && 
          _trackData!['result']['dlink'] != null) {
        
        final url = _trackData!['result']['dlink'].toString();
        
        // Stop current playback if any
        await _audioPlayer.stop();
        
        // Play new track
        await _audioPlayer.play(UrlSource(url));
      } else {
        if (mounted) {
          _showError('Link lagu tidak tersedia');
        }
      }
    } catch (e) {
      if (mounted) {
        _showError('Gagal memutar lagu: ${e.toString()}');
      }
    }
  }

  Future<void> _pauseTrack() async {
    try {
      await _audioPlayer.pause();
    } catch (e) {
      if (mounted) {
        _showError('Gagal pause: ${e.toString()}');
      }
    }
  }

  Future<void> _stopTrack() async {
    try {
      await _audioPlayer.stop();
      if (mounted) {
        setState(() {
          _position = Duration.zero;
          _isPlaying = false;
        });
      }
    } catch (e) {
      if (mounted) {
        _showError('Gagal stop: ${e.toString()}');
      }
    }
  }

  Future<void> _seekTrack(double value) async {
    try {
      await _audioPlayer.seek(Duration(seconds: value.toInt()));
    } catch (e) {
      if (mounted) {
        _showError('Gagal seek: ${e.toString()}');
      }
    }
  }

  Future<void> _restartTrack() async {
    try {
      await _audioPlayer.seek(Duration.zero);
      if (!_isPlaying) {
        await _playTrack();
      }
      if (mounted) {
        setState(() {
          _position = Duration.zero;
        });
      }
    } catch (e) {
      if (mounted) {
        _showError('Gagal restart: ${e.toString()}');
      }
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.red,
        content: Text(message),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60);
    return '${twoDigits(minutes)}:${twoDigits(seconds)}';
  }

  String _formatTimeString(String timeStr) {
    try {
      final parts = timeStr.split(':');
      if (parts.length == 2) {
        final minutes = int.parse(parts[0]);
        final seconds = int.parse(parts[1]);
        return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
      }
      return timeStr;
    } catch (e) {
      return timeStr;
    }
  }

  @override
  void dispose() {
    _audioPlayer.stop();
    _audioPlayer.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            _audioPlayer.stop();
            Navigator.of(context).pop();
          },
        ),
        backgroundColor: const Color(0xFF0A0A0A),
        title: const Text(
          'Spotify Play',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Cari lagu...',
                      hintStyle: const TextStyle(color: Colors.grey),
                      filled: true,
                      fillColor: const Color(0xFF1A1A1A),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    ),
                    onSubmitted: (_) => _searchTrack(),
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFDC143C),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: IconButton(
                    icon: _isLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.search, color: Colors.white),
                    onPressed: _isLoading ? null : _searchTrack,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            if (_hasSearchResult && _trackData != null && 
                _trackData!['result'] != null && 
                _trackData!['result']['metadata'] != null)
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1A1A1A),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.network(
                                _trackData!['result']['metadata']['cover']?.toString() ?? '',
                                width: 200,
                                height: 200,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) => Container(
                                  width: 200,
                                  height: 200,
                                  color: const Color(0xFF2A2A2A),
                                  child: const Icon(Icons.music_note, color: Colors.grey, size: 60),
                                ),
                              ),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              _trackData!['result']['metadata']['title']?.toString() ?? 'Unknown Title',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              _trackData!['result']['metadata']['artist']?.toString() ?? 'Unknown Artist',
                              style: const TextStyle(
                                color: Colors.grey,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.schedule, color: Colors.grey.shade400, size: 16),
                                const SizedBox(width: 4),
                                Text(
                                  _formatTimeString(_trackData!['result']['metadata']['duration']?.toString() ?? '0:00'),
                                  style: TextStyle(
                                    color: Colors.grey.shade400,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1A1A1A),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          children: [
                            Slider(
                              value: _position.inSeconds.toDouble(),
                              min: 0,
                              max: _duration.inSeconds > 0 ? _duration.inSeconds.toDouble() : 1,
                              onChanged: (value) async {
                                await _seekTrack(value);
                              },
                              activeColor: const Color(0xFFDC143C),
                              inactiveColor: Colors.grey.shade700,
                            ),
                            const SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  _formatDuration(_position),
                                  style: const TextStyle(color: Colors.white),
                                ),
                                Text(
                                  _formatDuration(_duration),
                                  style: const TextStyle(color: Colors.white),
                                ),
                              ],
                            ),
                            const SizedBox(height: 24),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.stop, color: Colors.white, size: 30),
                                  onPressed: _stopTrack,
                                ),
                                const SizedBox(width: 20),
                                Container(
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Color(0xFFDC143C),
                                  ),
                                  child: IconButton(
                                    icon: Icon(
                                      _isPlaying ? Icons.pause : Icons.play_arrow,
                                      color: Colors.white,
                                      size: 40,
                                    ),
                                    onPressed: _isPlaying ? _pauseTrack : _playTrack,
                                  ),
                                ),
                                const SizedBox(width: 20),
                                IconButton(
                                  icon: const Icon(Icons.replay, color: Colors.white, size: 30),
                                  onPressed: _restartTrack,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else if (_isLoading)
              const Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: Color(0xFFDC143C),
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Mencari lagu...',
                        style: TextStyle(
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else
              const Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.music_note,
                        color: Colors.grey,
                        size: 80,
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Cari lagu favoritmu',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Masukkan judul lagu atau nama artis',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}