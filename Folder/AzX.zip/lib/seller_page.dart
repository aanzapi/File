//JANGAN LU MALING
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> with SingleTickerProviderStateMixin {
  final _newUser = TextEditingController();
  final _newPass = TextEditingController();
  final _days = TextEditingController();
  final _editUser = TextEditingController();
  final _editDays = TextEditingController();

  bool loading = false;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _newUser.dispose();
    _newPass.dispose();
    _days.dispose();
    _editUser.dispose();
    _editDays.dispose();
    super.dispose();
  }

  // ================= API =================

  Future<void> _create() async {
    final u = _newUser.text.trim();
    final p = _newPass.text.trim();
    final d = _days.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      return _showNotification("Semua field wajib diisi", isError: true);
    }

    setState(() => loading = true);

    try {
      final res = await http.get(Uri.parse(
        "http://server.aanz-panel.web.id:2000/api/user/createAccount"
        "?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d",
      ));

      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _showNotification("Akun berhasil dibuat");
        _newUser.clear();
        _newPass.clear();
        _days.clear();
        Navigator.pop(context);
      } else {
        _showNotification(data['message'] ?? "Gagal membuat akun", isError: true);
      }
    } catch (e) {
      _showNotification("Error: $e", isError: true);
    }

    setState(() => loading = false);
  }

  Future<void> _edit() async {
    final u = _editUser.text.trim();
    final d = _editDays.text.trim();

    if (u.isEmpty || d.isEmpty) {
      return _showNotification("Username dan durasi wajib diisi", isError: true);
    }

    setState(() => loading = true);

    try {
      final res = await http.get(Uri.parse(
        "http://server.aanz-panel.web.id:2000/api/user/editUser"
        "?key=${widget.keyToken}&username=$u&addDays=$d",
      ));

      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _showNotification("Durasi berhasil diperbarui");
        _editUser.clear();
        _editDays.clear();
        Navigator.pop(context);
      } else {
        _showNotification(data['message'] ?? "Gagal mengubah durasi", isError: true);
      }
    } catch (e) {
      _showNotification("Error: $e", isError: true);
    }

    setState(() => loading = false);
  }

  void _showNotification(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: isError ? Colors.grey[800] : Colors.grey[900],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: Colors.grey[700]!, width: 1),
        ),
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: isError ? Colors.grey[400] : Colors.grey[300],
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                msg,
                style: TextStyle(color: Colors.grey[300], fontFamily: "ShareTechMono"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================= UI =================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        // Back button removed
        automaticallyImplyLeading: false,
        title: const Text(
          "SELLER PANEL",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.4,
            fontFamily: "Orbitron",
          ),
        ),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.grey[900]!.withOpacity(0.3),
                Colors.transparent,
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            border: Border(
              bottom: BorderSide(color: Colors.grey[800]!, width: 1),
            ),
          ),
        ),
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.grey[900]!,
                Colors.black,
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildHeader(),
                  const SizedBox(height: 40),
                  _mainActionButton(
                    "Buat Akun Baru",
                    Icons.person_add_alt_1,
                    _showCreateAccountDialog,
                  ),
                  const SizedBox(height: 20),
                  _mainActionButton(
                    "Ubah Durasi Akun",
                    Icons.edit_calendar,
                    _showEditDurationDialog,
                  ),
                  const SizedBox(height: 40),
                  _buildFooter(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [
                Colors.grey[800]!,
                Colors.grey[900]!,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: Colors.grey[700]!, width: 2),
            boxShadow: [
              BoxShadow(
                color: Colors.grey[900]!.withOpacity(0.5),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Icon(
            Icons.admin_panel_settings,
            color: Colors.grey[400],
            size: 40,
          ),
        ),
        const SizedBox(height: 16),
        Text(
          "RESELLER DASHBOARD",
          style: TextStyle(
            color: Colors.grey[300],
            fontSize: 14,
            fontFamily: "ShareTechMono",
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          height: 1,
          width: 100,
          color: Colors.grey[800],
        ),
      ],
    );
  }

  Widget _buildFooter() {
    return Text(
      "MANAGE YOUR ACCOUNTS",
      style: TextStyle(
        color: Colors.grey[700],
        fontSize: 10,
        fontFamily: "ShareTechMono",
        letterSpacing: 1,
      ),
    );
  }

  Widget _mainActionButton(String title, IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 26),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            colors: [
              Colors.grey[850]!,
              Colors.grey[900]!,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: Colors.grey[700]!,
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.grey[900]!.withOpacity(0.5),
              blurRadius: 30,
              offset: const Offset(0, 14),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey[800]!.withOpacity(0.5),
              ),
              child: Icon(icon, color: Colors.grey[300], size: 30),
            ),
            const SizedBox(width: 18),
            Text(
              title,
              style: TextStyle(
                color: Colors.grey[200],
                fontSize: 18,
                fontWeight: FontWeight.w700,
                fontFamily: "Orbitron",
                letterSpacing: 1,
              ),
            ),
            const SizedBox(width: 10),
            Icon(
              Icons.arrow_forward_ios,
              color: Colors.grey[500],
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  // ================= DIALOG =================

  void _showCreateAccountDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _buildDialog(
        title: "Buat Akun Baru",
        fields: [
          _inputField("Username", _newUser),
          _inputField("Password", _newPass),
          _inputField("Durasi (hari)", _days, type: TextInputType.number),
        ],
        onConfirm: _create,
      ),
    );
  }

  void _showEditDurationDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _buildDialog(
        title: "Ubah Durasi Akun",
        fields: [
          _inputField("Username", _editUser),
          _inputField("Tambah Durasi (hari)", _editDays, type: TextInputType.number),
        ],
        onConfirm: _edit,
      ),
    );
  }

  Widget _buildDialog({
    required String title,
    required List<Widget> fields,
    required VoidCallback onConfirm,
  }) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
            colors: [
              Colors.grey[900]!.withOpacity(0.95),
              Colors.grey[850]!.withOpacity(0.9),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: Colors.grey[700]!,
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.grey[900]!.withOpacity(0.5),
              blurRadius: 30,
              spreadRadius: 5,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Header
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.grey[800]!.withOpacity(0.5),
                        ),
                        child: Icon(
                          title.contains("Buat") ? Icons.person_add : Icons.edit,
                          color: Colors.grey[400],
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        title,
                        style: TextStyle(
                          color: Colors.grey[200],
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Orbitron",
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Fields
                  ...fields,
                  
                  const SizedBox(height: 24),
                  
                  // Divider
                  Container(
                    height: 1,
                    color: Colors.grey[800],
                  ),
                  
                  const SizedBox(height: 20),
                  
                  // Buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: loading ? null : () => Navigator.pop(context),
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.grey[400],
                        ),
                        child: const Text(
                          "BATAL",
                          style: TextStyle(
                            fontFamily: "ShareTechMono",
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.grey[700]!,
                              Colors.grey[800]!,
                            ],
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: ElevatedButton(
                          onPressed: loading ? null : onConfirm,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.white,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 12,
                            ),
                          ),
                          child: loading
                              ? SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.grey[300]!,
                                    ),
                                  ),
                                )
                              : const Text(
                                  "KONFIRMASI",
                                  style: TextStyle(
                                    fontFamily: "ShareTechMono",
                                    letterSpacing: 1,
                                  ),
                                ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _inputField(
    String label,
    TextEditingController c, {
    TextInputType type = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Icons.circle,
              color: Colors.grey[600],
              size: 6,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 12,
                fontFamily: "ShareTechMono",
                letterSpacing: 1,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: LinearGradient(
              colors: [
                Colors.grey[850]!.withOpacity(0.5),
                Colors.grey[900]!.withOpacity(0.3),
              ],
            ),
            border: Border.all(
              color: Colors.grey[700]!,
              width: 1,
            ),
          ),
          child: TextField(
            controller: c,
            keyboardType: type,
            style: TextStyle(
              color: Colors.grey[200],
              fontFamily: "ShareTechMono",
              fontSize: 14,
            ),
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
              border: InputBorder.none,
              hintText: "Masukkan $label",
              hintStyle: TextStyle(
                color: Colors.grey[600],
                fontSize: 13,
                fontFamily: "ShareTechMono",
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}