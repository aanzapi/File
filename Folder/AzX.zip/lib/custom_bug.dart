//JANGAN LU MALING
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'dart:ui';

// === GLOBAL THEME COLOR (Hitam Putih dengan aksen merah) ===
const Color primaryWhite = Colors.white;
const Color secondaryGrey = Color(0xFF9CA3AF);
const Color darkGrey = Color(0xFF1F2937);
const Color backgroundBlack = Color(0xFF000000);
const Color glassWhite = Color(0x0DFFFFFF);
const Color borderGrey = Color(0x1AFFFFFF);
const Color accentRed = Color(0xFFFF0000);
const Color subtleRed = Color(0x33FF0000);

class CustomAttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listPayload;
  final String role;
  final String expiredDate;

  const CustomAttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listPayload,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<CustomAttackPage> createState() => _CustomAttackPageState();
}

class _CustomAttackPageState extends State<CustomAttackPage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final qtyController = TextEditingController(text: "5");
  final delayController = TextEditingController(text: "100");
  static const String baseUrl = "http://server.aanz-panel.web.id:2000";

  // Animation controllers
  late AnimationController _buttonController;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _glowController;
  late AnimationController _pulseController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _glowAnimation;
  late Animation<double> _pulseAnimation;

  // Video controllers for banner
  late VideoPlayerController _bannerController;
  bool _bannerInitialized = false;
  bool _bannerError = false;

  // State variables
  List<String> selectedBugs = [];
  bool _isSending = false;
  int _activeStep = 0;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeBannerVideo();
    _setDefaultBugs();
    _startAnimations();
  }

  void _initializeAnimations() {
    _buttonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));

    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    _pulseAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  void _setDefaultBugs() {
    if (widget.listPayload.isNotEmpty) {
      selectedBugs.add(widget.listPayload[0]['bug_id']);
    }
  }

  void _initializeBannerVideo() {
    try {
      _bannerController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _bannerInitialized = true;
            });
            _bannerController.setLooping(true);
            _bannerController.play();
            _bannerController.setVolume(0);
          }
        }).catchError((error) {
          print('Banner video initialization error: $error');
          if (mounted) {
            setState(() {
              _bannerError = true;
            });
          }
        });
    } catch (e) {
      print('Banner controller creation error: $e');
      if (mounted) {
        setState(() {
          _bannerError = true;
        });
      }
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _toggleBugSelection(String bugId) {
    setState(() {
      if (selectedBugs.contains(bugId)) {
        selectedBugs.remove(bugId);
      } else {
        selectedBugs.add(bugId);
      }
    });
  }

  Future<void> _sendCustomBug() async {
    if (_isSending) return;

    setState(() {
      _isSending = true;
      _activeStep = 1;
    });

    _buttonController.forward().then((_) {
      _buttonController.reverse();
    });

    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;
    final qty = int.tryParse(qtyController.text) ?? 1;
    final delay = int.tryParse(delayController.text) ?? 100;

    if (target == null || key.isEmpty) {
      _showAlert("❌ Invalid Number", "Gunakan nomor internasional (tanpa 0 atau +).");
      setState(() {
        _isSending = false;
        _activeStep = 0;
      });
      return;
    }

    if (selectedBugs.isEmpty) {
      _showAlert("❌ No Payload Selected", "Please select at least one payload to send.");
      setState(() {
        _isSending = false;
        _activeStep = 0;
      });
      return;
    }

    try {
      final bugsParam = selectedBugs.join(',');

      final res = await http.get(Uri.parse("$baseUrl/api/whatsapp/customBug?key=$key&target=$target&bug=$bugsParam&qty=$qty&delay=$delay"));
      final data = jsonDecode(res.body);

      if (data["valid"] == false) {
        _showAlert("❌ Failed", data["message"] ?? "Failed to send custom bug.");
      } else {
        setState(() {
          _activeStep = 2;
        });
        _showSuccessPopup(target, data["details"]);
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
        if (_activeStep != 2) _activeStep = 0;
      });
    }
  }

  void _showSuccessPopup(String target, Map<String, dynamic> details) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => CustomSuccessDialog(
        target: target,
        details: details,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() {
            _activeStep = 0;
          });
        },
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: backgroundBlack.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: borderGrey, width: 1),
        ),
        title: Text(title, style: const TextStyle(color: primaryWhite, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: accentRed)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!["vip", "owner"].contains(widget.role.toLowerCase())) {
      return Scaffold(
        backgroundColor: backgroundBlack,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _glowController,
                builder: (context, child) {
                  return Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: accentRed.withOpacity(0.1 + 0.1 * _glowAnimation.value),
                      borderRadius: BorderRadius.circular(100),
                      border: Border.all(
                        color: accentRed.withOpacity(0.3 + 0.2 * _glowAnimation.value),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: accentRed.withOpacity(0.2 * _glowAnimation.value),
                          blurRadius: 20,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: const Icon(
                      FontAwesomeIcons.lock,
                      color: accentRed,
                      size: 60,
                    ),
                  );
                },
              ),
              const SizedBox(height: 20),
              const Text(
                "ACCESS DENIED",
                style: TextStyle(
                  color: accentRed,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "This feature is only available for VIP and Owner users",
                style: TextStyle(
                  color: primaryWhite.withOpacity(0.7),
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: backgroundBlack,
      body: Stack(
        children: [
          // Pure black background
          Container(color: backgroundBlack),

          // Banner video at the top
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 200,
            child: _buildBannerVideo(),
          ),

          // Dark gradient overlay for smooth transition
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 220,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    backgroundBlack.withOpacity(0.3),
                    backgroundBlack.withOpacity(0.6),
                    backgroundBlack,
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),

          // Main content
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const SizedBox(height: 140), // Space for banner

                        // User info header with glassmorphism
                        _buildUserInfoHeader(),

                        const SizedBox(height: 20),

                        // Main content cards
                        _buildTargetInputCard(),

                        const SizedBox(height: 14),

                        _buildPayloadSelectionCard(),

                        const SizedBox(height: 14),

                        _buildQuantityDelayCard(),

                        const SizedBox(height: 20),

                        _buildSendButton(),

                        const SizedBox(height: 14),

                        _buildFooterInfo(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBannerVideo() {
    if (_bannerInitialized && !_bannerError) {
      return Container(
        width: double.infinity,
        height: 200,
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _bannerController.value.size.width,
            height: _bannerController.value.size.height,
            child: VideoPlayer(_bannerController),
          ),
        ),
      );
    } else {
      return Container(
        width: double.infinity,
        height: 200,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              accentRed.withOpacity(0.3),
              backgroundBlack,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Icon(
            FontAwesomeIcons.skull,
            color: accentRed.withOpacity(0.3),
            size: 80,
          ),
        ),
      );
    }
  }

  Widget _buildUserInfoHeader() {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, child) {
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: glassWhite,
            border: Border.all(
              color: borderGrey,
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: accentRed.withOpacity(0.08 * _glowAnimation.value),
                blurRadius: 25,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: glassWhite,
                  border: Border.all(
                    color: accentRed.withOpacity(0.3),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accentRed.withOpacity(0.15 * _glowAnimation.value),
                      blurRadius: 18,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: Icon(
                  widget.role.toLowerCase() == "vip"
                      ? FontAwesomeIcons.crown
                      : FontAwesomeIcons.userShield,
                  color: primaryWhite,
                  size: 22,
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.username,
                      style: const TextStyle(
                        color: primaryWhite,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        fontSize: 18,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 6),

                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: subtleRed,
                            border: Border.all(
                              color: accentRed.withOpacity(0.3),
                            ),
                          ),
                          child: Text(
                            widget.role.toUpperCase(),
                            style: const TextStyle(
                              color: accentRed,
                              fontSize: 11,
                              fontFamily: 'ShareTechMono',
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ),

                        const SizedBox(width: 10),

                        Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: const Color(0xFF22C55E),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF22C55E).withOpacity(0.6),
                                blurRadius: 6,
                                spreadRadius: 1,
                              )
                            ],
                          ),
                        ),

                        const SizedBox(width: 6),

                        const Text(
                          "ACTIVE",
                          style: TextStyle(
                            color: Color(0xFF22C55E),
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: subtleRed,
                  border: Border.all(
                    color: accentRed.withOpacity(0.3),
                  ),
                ),
                child: Column(
                  children: [
                    const Icon(
                      FontAwesomeIcons.clock,
                      color: accentRed,
                      size: 14,
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      "EXPIRE",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 9,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      widget.expiredDate,
                      style: const TextStyle(
                        color: accentRed,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTargetInputCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: glassWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderGrey),
        boxShadow: [
          BoxShadow(
            color: accentRed.withOpacity(0.05),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: subtleRed,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: accentRed.withOpacity(0.3)),
                ),
                child: const Icon(
                  FontAwesomeIcons.phone,
                  color: accentRed,
                  size: 16,
                ),
              ),
              const SizedBox(width: 10),
              const Text(
                "Target Number",
                style: TextStyle(
                  color: primaryWhite,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          TextField(
            controller: targetController,
            style: const TextStyle(color: primaryWhite, fontSize: 16),
            cursorColor: accentRed,
            decoration: InputDecoration(
              hintText: "e.g. 628xxxxxxxxx",
              hintStyle: TextStyle(color: secondaryGrey),
              filled: true,
              fillColor: glassWhite,
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: borderGrey),
                borderRadius: BorderRadius.circular(12),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: accentRed, width: 2),
                borderRadius: BorderRadius.circular(12),
              ),
              prefixIcon: Container(
                margin: const EdgeInsets.all(10),
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: subtleRed,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: accentRed.withOpacity(0.3)),
                ),
                child: const Icon(
                  FontAwesomeIcons.globe,
                  color: accentRed,
                  size: 16,
                ),
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            "Use international format without 0 or +",
            style: TextStyle(
              color: secondaryGrey,
              fontSize: 11,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPayloadSelectionCard() {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, child) {
        return Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            color: glassWhite,
            border: Border.all(
              color: borderGrey,
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: accentRed.withOpacity(0.06 * _glowAnimation.value),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: subtleRed,
                      border: Border.all(color: accentRed.withOpacity(0.3)),
                    ),
                    child: const Icon(
                      FontAwesomeIcons.cube,
                      size: 16,
                      color: accentRed,
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Text(
                    "Payload Arsenal",
                    style: TextStyle(
                      color: primaryWhite,
                      fontSize: 18,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    "${selectedBugs.length} Selected",
                    style: TextStyle(
                      color: selectedBugs.isNotEmpty
                          ? accentRed
                          : secondaryGrey,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 22),

              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: widget.listPayload.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 14,
                  childAspectRatio: 2.7,
                ),
                itemBuilder: (context, index) {
                  final bug = widget.listPayload[index];
                  final bugId = bug['bug_id'];
                  final bugName = bug['bug_name'];
                  final isSelected = selectedBugs.contains(bugId);

                  return GestureDetector(
                    onTap: () => _toggleBugSelection(bugId),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      curve: Curves.easeOutCubic,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: isSelected ? subtleRed : glassWhite,
                        border: Border.all(
                          color: isSelected
                              ? accentRed
                              : borderGrey,
                          width: isSelected ? 1.6 : 1,
                        ),
                        boxShadow: isSelected
                            ? [
                                BoxShadow(
                                  color: accentRed.withOpacity(0.15),
                                  blurRadius: 18,
                                  spreadRadius: -2,
                                )
                              ]
                            : [],
                      ),
                      child: Row(
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 250),
                            width: 34,
                            height: 34,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isSelected ? accentRed.withOpacity(0.2) : glassWhite,
                              border: Border.all(color: isSelected ? accentRed : borderGrey),
                            ),
                            child: Icon(
                              isSelected
                                  ? FontAwesomeIcons.check
                                  : FontAwesomeIcons.code,
                              size: 14,
                              color: isSelected
                                  ? accentRed
                                  : secondaryGrey,
                            ),
                          ),

                          const SizedBox(width: 12),

                          Expanded(
                            child: Text(
                              bugName,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: isSelected
                                    ? accentRed
                                    : primaryWhite.withOpacity(0.7),
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),

                          AnimatedOpacity(
                            duration: const Duration(milliseconds: 200),
                            opacity: isSelected ? 1 : 0,
                            child: Icon(
                              Icons.radio_button_checked,
                              size: 16,
                              color: accentRed,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),

              const SizedBox(height: 18),

              Center(
                child: Text(
                  "Multiple payload selection enabled",
                  style: TextStyle(
                    color: secondaryGrey,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildQuantityDelayCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: glassWhite,
        border: Border.all(color: borderGrey),
        boxShadow: [
          BoxShadow(
            color: accentRed.withOpacity(0.08),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: subtleRed,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: accentRed.withOpacity(0.3)),
                ),
                child: const Icon(
                  FontAwesomeIcons.slidersH,
                  color: accentRed,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                "Quantity & Delay",
                style: TextStyle(
                  color: primaryWhite,
                  fontSize: 18,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: glassWhite,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: borderGrey),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(FontAwesomeIcons.layerGroup, size: 14, color: accentRed),
                    const SizedBox(width: 8),
                    const Text(
                      "Quantity",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 14,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: qtyController,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: primaryWhite, fontSize: 14),
                  cursorColor: accentRed,
                  decoration: InputDecoration(
                    hintText: "Enter quantity",
                    hintStyle: TextStyle(color: secondaryGrey),
                    filled: true,
                    fillColor: glassWhite,
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: borderGrey),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: accentRed),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: glassWhite,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: borderGrey),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(FontAwesomeIcons.clock, size: 14, color: accentRed),
                    const SizedBox(width: 8),
                    const Text(
                      "Delay (ms)",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 14,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: delayController,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: primaryWhite, fontSize: 14),
                  cursorColor: accentRed,
                  decoration: InputDecoration(
                    hintText: "Enter delay in milliseconds",
                    hintStyle: TextStyle(color: secondaryGrey),
                    filled: true,
                    fillColor: glassWhite,
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: borderGrey),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: accentRed),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: subtleRed,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: accentRed.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                const Icon(
                  FontAwesomeIcons.circleInfo,
                  size: 14,
                  color: accentRed,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    "You can freely adjust quantity and delay values.",
                    style: TextStyle(
                      color: secondaryGrey,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: accentRed.withOpacity(0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: accentRed.withOpacity(0.1),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: ElevatedButton.icon(
              icon: _isSending
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        color: accentRed,
                        strokeWidth: 2,
                      ),
                    )
                  : const Icon(FontAwesomeIcons.paperPlane, color: accentRed, size: 18),
              label: Text(
                _isSending ? "SENDING..." : "SEND CUSTOM PAYLOAD",
                style: const TextStyle(
                  fontSize: 16,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.4,
                  color: primaryWhite,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor: accentRed,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: _isSending ? null : _sendCustomBug,
            ),
          ),
        );
      },
    );
  }

  Widget _buildFooterInfo() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: subtleRed,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accentRed.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(
            FontAwesomeIcons.exclamationTriangle,
            color: accentRed,
            size: 14,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "Custom attack with multiple payloads. Use responsibly.",
              style: TextStyle(
                color: secondaryGrey,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _buttonController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    _glowController.dispose();
    _pulseController.dispose();
    _bannerController.dispose();
    targetController.dispose();
    qtyController.dispose();
    delayController.dispose();
    super.dispose();
  }
}

class CustomSuccessDialog extends StatefulWidget {
  final String target;
  final Map<String, dynamic> details;
  final VoidCallback onDismiss;

  const CustomSuccessDialog({
    super.key,
    required this.target,
    required this.details,
    required this.onDismiss,
  });

  @override
  State<CustomSuccessDialog> createState() => _CustomSuccessDialogState();
}

class _CustomSuccessDialogState extends State<CustomSuccessDialog> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late AnimationController _glowController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;
  bool _showDetails = false;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );

    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) {
        setState(() {
          _showDetails = true;
        });
        _fadeController.forward();
        _scaleController.forward();
      }
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(26),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: Container(
            width: size.width,
            decoration: BoxDecoration(
              color: backgroundBlack.withOpacity(0.95),
              borderRadius: BorderRadius.circular(26),
              border: Border.all(
                color: accentRed.withOpacity(0.3),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: accentRed.withOpacity(0.15),
                  blurRadius: 30,
                  spreadRadius: 4,
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _glowController,
                    builder: (_, __) {
                      return Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: subtleRed,
                          border: Border.all(
                            color: accentRed.withOpacity(0.3),
                            width: 2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: accentRed.withOpacity(0.25 * _glowAnimation.value),
                              blurRadius: 20,
                              spreadRadius: 3,
                            ),
                          ],
                        ),
                        child: const Icon(
                          FontAwesomeIcons.check,
                          color: accentRed,
                          size: 42,
                        ),
                      );
                    },
                  ),

                  const SizedBox(height: 16),

                  const Text(
                    "CUSTOM ATTACK SENT",
                    style: TextStyle(
                      color: primaryWhite,
                      fontSize: 20,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.6,
                    ),
                  ),

                  const SizedBox(height: 6),

                  Text(
                    "Operation completed successfully",
                    style: TextStyle(
                      color: secondaryGrey,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),

                  const SizedBox(height: 20),

                  FadeTransition(
                    opacity: _fadeAnimation,
                    child: ScaleTransition(
                      scale: _scaleAnimation,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: subtleRed,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: accentRed.withOpacity(0.3),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildDetailRow("Target", widget.target),
                            _buildDetailRow("Payload", widget.details["bugs"].toString()),
                            _buildDetailRow("Quantity", widget.details["qty"].toString()),
                            _buildDetailRow("Delay", "${widget.details["delay"]} ms"),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 22),

                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton(
                      onPressed: widget.onDismiss,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                          side: BorderSide(
                            color: accentRed.withOpacity(0.3),
                          ),
                        ),
                      ),
                      child: const Text(
                        "DONE",
                        style: TextStyle(
                          color: accentRed,
                          fontSize: 14,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              "$label:",
              style: TextStyle(
                color: secondaryGrey,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: accentRed,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }
}