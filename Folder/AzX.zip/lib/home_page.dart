//JANGAN LU MALING
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'dart:ui';

// ===== GLOBAL THEME COLOR (Hitam Putih dengan aksen merah) =====
const Color primaryWhite = Colors.white;
const Color secondaryGrey = Color(0xFF9CA3AF);
const Color backgroundBlack = Color(0xFF000000);
const Color glassWhite = Color(0x0DFFFFFF);
const Color borderGrey = Color(0x1AFFFFFF);
const Color accentRed = Color(0xFFFF0000);
const Color subtleRed = Color(0x33FF0000);

class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  static const String baseUrl = "http://server.aanz-panel.web.id:2000";

  // Animation controllers
  late AnimationController _buttonController;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _glowController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _glowAnimation;

  // Video controllers for banner
  late VideoPlayerController _bannerController;
  bool _bannerInitialized = false;
  bool _bannerError = false;

  // State variables
  String selectedBugId = "";
  bool _isSending = false;
  bool _isSuccess = false;
  int _activeStep = 0;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeBannerVideo();
    _setDefaultBug();
    _startAnimations();
  }

  void _initializeAnimations() {
    _buttonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));

    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  void _setDefaultBug() {
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  void _initializeBannerVideo() {
    try {
      _bannerController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _bannerInitialized = true;
            });
            _bannerController.setLooping(true);
            _bannerController.play();
            _bannerController.setVolume(0);
          }
        }).catchError((error) {
          print('Banner video initialization error: $error');
          if (mounted) {
            setState(() {
              _bannerError = true;
            });
          }
        });
    } catch (e) {
      print('Banner controller creation error: $e');
      if (mounted) {
        setState(() {
          _bannerError = true;
        });
      }
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    if (_isSending) return;

    setState(() {
      _isSending = true;
      _activeStep = 1;
    });

    _buttonController.forward().then((_) {
      _buttonController.reverse();
    });

    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: 628xxx), bukan 08xxx.");
      setState(() {
        _isSending = false;
        _activeStep = 0;
      });
      return;
    }

    try {
      final res = await http.get(Uri.parse("$baseUrl/api/whatsapp/sendBug?key=$key&target=$target&bug=$selectedBugId"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["senderOn"] == false) {
        _showAlert("⚠️ Gagal", "Gagal mengirim bug. Sender Kosong, Hubungi Seller.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Session key tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Gagal mengirim bug. Mungkin server sedang maintenance.");
      } else {
        setState(() {
          _activeStep = 2;
          _isSuccess = true;
        });
        _showSuccessPopup(target);
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
        if (!_isSuccess) _activeStep = 0;
      });
    }
  }

  void _showSuccessPopup(String target) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => SuccessDialog(
        target: target,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() {
            _isSuccess = false;
            _activeStep = 0;
          });
        },
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: backgroundBlack.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: borderGrey, width: 1),
        ),
        title: Text(title, style: const TextStyle(color: primaryWhite, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: accentRed)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundBlack,
      body: Stack(
        children: [
          // Pure black background
          Container(color: backgroundBlack),

          // Banner video at the top
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 200,
            child: _buildBannerVideo(),
          ),

          // Dark gradient overlay for smooth transition
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 220,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    backgroundBlack.withOpacity(0.3),
                    backgroundBlack.withOpacity(0.6),
                    backgroundBlack,
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),

          // Main content
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const SizedBox(height: 140), // Space for banner

                        // User info header with glassmorphism
                        _buildUserInfoHeader(),

                        const SizedBox(height: 20),

                        // Progress indicator
                        _buildProgressIndicator(),

                        const SizedBox(height: 20),

                        // Main content cards
                        _buildTargetInputCard(),

                        const SizedBox(height: 14),

                        _buildPayloadTypeCard(),

                        const SizedBox(height: 20),

                        _buildSendButton(),

                        const SizedBox(height: 14),

                        _buildFooterInfo(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBannerVideo() {
    if (_bannerInitialized && !_bannerError) {
      return Container(
        width: double.infinity,
        height: 200,
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _bannerController.value.size.width,
            height: _bannerController.value.size.height,
            child: VideoPlayer(_bannerController),
          ),
        ),
      );
    } else {
      return Container(
        width: double.infinity,
        height: 200,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              accentRed.withOpacity(0.3),
              backgroundBlack,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Icon(
            FontAwesomeIcons.skull,
            color: accentRed.withOpacity(0.3),
            size: 80,
          ),
        ),
      );
    }
  }

  Widget _buildProgressIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: glassWhite,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderGrey),
      ),
      child: Row(
        children: [
          _buildStepIndicator(0, "Input", FontAwesomeIcons.edit),
          _buildProgressLine(),
          _buildStepIndicator(1, "Process", FontAwesomeIcons.cogs),
          _buildProgressLine(),
          _buildStepIndicator(2, "Complete", FontAwesomeIcons.checkCircle),
        ],
      ),
    );
  }

  Widget _buildStepIndicator(int step, String label, IconData icon) {
    final isActive = _activeStep >= step;
    final isCurrent = _activeStep == step;

    return Expanded(
      child: Column(
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isActive ? subtleRed : glassWhite,
              shape: BoxShape.circle,
              border: Border.all(
                color: isActive ? accentRed : borderGrey,
                width: 2,
              ),
              boxShadow: isCurrent
                  ? [
                BoxShadow(
                  color: accentRed.withOpacity(0.2 * _glowAnimation.value),
                  blurRadius: 8,
                  spreadRadius: 1,
                )
              ]
                  : null,
            ),
            child: Icon(
              icon,
              color: isActive ? accentRed : secondaryGrey,
              size: 18,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              color: isActive ? accentRed : secondaryGrey,
              fontSize: 11,
              fontFamily: 'Orbitron',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressLine() {
    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.symmetric(horizontal: 6),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: _activeStep > 0
                ? [accentRed, accentRed.withOpacity(0.3)]
                : [borderGrey, borderGrey],
          ),
        ),
      ),
    );
  }

  Widget _buildUserInfoHeader() {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, child) {
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: glassWhite,
            border: Border.all(
              color: borderGrey,
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: accentRed.withOpacity(0.08 * _glowAnimation.value),
                blurRadius: 25,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: subtleRed,
                  border: Border.all(
                    color: accentRed.withOpacity(0.3),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accentRed.withOpacity(0.15 * _glowAnimation.value),
                      blurRadius: 18,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: Icon(
                  widget.role.toLowerCase() == "vip"
                      ? FontAwesomeIcons.crown
                      : FontAwesomeIcons.userShield,
                  color: accentRed,
                  size: 22,
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.username,
                      style: const TextStyle(
                        color: primaryWhite,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        fontSize: 18,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 6),

                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: subtleRed,
                            border: Border.all(
                              color: accentRed.withOpacity(0.3),
                            ),
                          ),
                          child: Text(
                            widget.role.toUpperCase(),
                            style: const TextStyle(
                              color: accentRed,
                              fontSize: 11,
                              fontFamily: 'ShareTechMono',
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ),

                        const SizedBox(width: 10),

                        Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: const Color(0xFF22C55E),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF22C55E).withOpacity(0.6),
                                blurRadius: 6,
                                spreadRadius: 1,
                              )
                            ],
                          ),
                        ),

                        const SizedBox(width: 6),

                        const Text(
                          "ACTIVE",
                          style: TextStyle(
                            color: Color(0xFF22C55E),
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: subtleRed,
                  border: Border.all(
                    color: accentRed.withOpacity(0.3),
                  ),
                ),
                child: Column(
                  children: [
                    const Icon(
                      FontAwesomeIcons.clock,
                      color: accentRed,
                      size: 14,
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      "EXPIRE",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 9,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      widget.expiredDate,
                      style: const TextStyle(
                        color: accentRed,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTargetInputCard() {
    return StatefulBuilder(
      builder: (context, setInnerState) {
        bool isFocused = false;

        return Focus(
          onFocusChange: (value) {
            setInnerState(() {
              isFocused = value;
            });
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 350),
            curve: Curves.easeInOut,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: glassWhite,
              border: Border.all(
                color: isFocused ? accentRed : borderGrey,
                width: 1.2,
              ),
              boxShadow: [
                if (isFocused)
                  BoxShadow(
                    color: accentRed.withOpacity(0.15),
                    blurRadius: 25,
                    spreadRadius: 2,
                  ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: subtleRed,
                        border: Border.all(color: accentRed.withOpacity(0.3)),
                      ),
                      child: const Icon(
                        FontAwesomeIcons.phoneVolume,
                        color: accentRed,
                        size: 16,
                      ),
                    ),
                    const SizedBox(width: 14),
                    const Text(
                      "TARGET NUMBER",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 15,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 22),

                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    color: glassWhite,
                    border: Border.all(
                      color: isFocused ? accentRed : borderGrey,
                      width: 1.2,
                    ),
                  ),
                  child: TextField(
                    controller: targetController,
                    style: const TextStyle(
                      color: primaryWhite,
                      fontSize: 17,
                      fontFamily: 'ShareTechMono',
                      letterSpacing: 1.5,
                    ),
                    cursorColor: accentRed,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: "628xxxxxxxxx",
                      hintStyle: TextStyle(
                        color: Colors.white.withOpacity(0.35),
                        fontSize: 15,
                      ),
                      prefixIcon: Padding(
                        padding: const EdgeInsets.only(top: 14),
                        child: Text(
                          "+",
                          style: TextStyle(
                            color: accentRed.withOpacity(0.8),
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      suffixIcon: isFocused
                          ? Icon(
                              FontAwesomeIcons.checkCircle,
                              color: accentRed,
                              size: 16,
                            )
                          : null,
                    ),
                  ),
                ),

                const SizedBox(height: 14),

                Row(
                  children: [
                    Icon(
                      FontAwesomeIcons.circleInfo,
                      size: 12,
                      color: accentRed,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        "Use international format without 0 (example: 628xxxx)",
                        style: TextStyle(
                          color: secondaryGrey,
                          fontSize: 11,
                          fontFamily: 'ShareTechMono',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPayloadTypeCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: glassWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderGrey),
        boxShadow: [
          BoxShadow(
            color: accentRed.withOpacity(0.05),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: subtleRed,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: accentRed.withOpacity(0.3)),
                ),
                child: const Icon(
                  FontAwesomeIcons.whatsapp,
                  color: accentRed,
                  size: 16,
                ),
              ),
              const SizedBox(width: 10),
              const Text(
                "Bug Type",
                style: TextStyle(
                  color: primaryWhite,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            decoration: BoxDecoration(
              color: glassWhite,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: borderGrey, width: 1),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: backgroundBlack.withOpacity(0.95),
                value: selectedBugId,
                isExpanded: true,
                iconEnabledColor: accentRed,
                style: const TextStyle(color: primaryWhite, fontSize: 14),
                items: widget.listBug.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Container(
                      constraints: const BoxConstraints(minHeight: 40),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: subtleRed,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Icon(
                              FontAwesomeIcons.virus,
                              color: accentRed,
                              size: 14,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  bug['bug_name'],
                                  style: const TextStyle(
                                    color: primaryWhite,
                                    fontSize: 14,
                                    height: 1.2,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                if (bug['description'] != null)
                                  Text(
                                    bug['description'],
                                    style: TextStyle(
                                      color: secondaryGrey,
                                      fontSize: 11,
                                      height: 1.2,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedBugId = value!;
                  });
                },
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Icon(
                FontAwesomeIcons.infoCircle,
                color: accentRed,
                size: 12,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  "Select the appropriate bug type for maximum effectiveness",
                  style: TextStyle(
                    color: secondaryGrey,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: accentRed.withOpacity(0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: accentRed.withOpacity(0.1),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: ElevatedButton.icon(
              icon: _isSending
                  ? SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: accentRed,
                  strokeWidth: 2,
                ),
              )
                  : const Icon(FontAwesomeIcons.paperPlane, color: accentRed, size: 18),
              label: Text(
                _isSending ? "SENDING..." : "SEND BUG",
                style: const TextStyle(
                  fontSize: 16,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.4,
                  color: primaryWhite,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor: accentRed,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: _isSending ? null : _sendBug,
            ),
          ),
        );
      },
    );
  }

  Widget _buildFooterInfo() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: subtleRed,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accentRed.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(
            FontAwesomeIcons.exclamationTriangle,
            color: accentRed,
            size: 14,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "Use this tool responsibly. We are not responsible for any misuse.",
              style: TextStyle(
                color: secondaryGrey,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _buttonController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    _glowController.dispose();
    _bannerController.dispose();
    targetController.dispose();
    super.dispose();
  }
}

// Success Dialog tanpa video
class SuccessDialog extends StatefulWidget {
  final String target;
  final VoidCallback onDismiss;

  const SuccessDialog({
    super.key,
    required this.target,
    required this.onDismiss,
  });

  @override
  State<SuccessDialog> createState() => _SuccessDialogState();
}

class _SuccessDialogState extends State<SuccessDialog> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late AnimationController _glowController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );

    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    _fadeController.forward();
    _scaleController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final dialogWidth = screenSize.width * 0.85;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: Center(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: dialogWidth,
          ),
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: ScaleTransition(
              scale: _scaleAnimation,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: backgroundBlack.withOpacity(0.95),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: accentRed.withOpacity(0.3),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accentRed.withOpacity(0.2),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedBuilder(
                      animation: _glowController,
                      builder: (context, child) {
                        return Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: subtleRed,
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(
                              color: accentRed.withOpacity(0.3 * _glowAnimation.value),
                              width: 2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: accentRed.withOpacity(0.2 * _glowAnimation.value),
                                blurRadius: 15,
                                spreadRadius: 3,
                              ),
                            ],
                          ),
                          child: const Icon(
                            FontAwesomeIcons.checkDouble,
                            color: accentRed,
                            size: 40,
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      "ATTACK SUCCESSFUL!",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Bug successfully sent to ${widget.target}",
                      style: TextStyle(
                        color: secondaryGrey,
                        fontSize: 14,
                        fontFamily: 'ShareTechMono',
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 28),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: accentRed.withOpacity(0.3)),
                      ),
                      child: TextButton(
                        onPressed: widget.onDismiss,
                        style: TextButton.styleFrom(
                          foregroundColor: accentRed,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: const Text(
                          "DONE",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}