//JANGAN LU MALING
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';

class SenderPage extends StatefulWidget {
  final String sessionKey;

  const SenderPage({super.key, required this.sessionKey});

  @override
  State<SenderPage> createState() => _SenderPageState();
}

class _SenderPageState extends State<SenderPage> with TickerProviderStateMixin {
  // Constants
  static const String baseUrl = "http://server.aanz-panel.web.id:2000";
  
  // Warna hitam putih
  final Color primaryWhite = Colors.white;
  final Color secondaryGrey = Colors.grey.shade400;
  final Color darkGrey = Colors.grey.shade800;
  final Color lightGrey = Colors.grey.shade200;
  final Color backgroundBlack = Colors.black;
  final Color surfaceBlack = Colors.black.withOpacity(0.9);
  final Color glassWhite = Colors.white.withOpacity(0.05);
  final Color borderGrey = Colors.white.withOpacity(0.1);
  final Color accentGrey = Colors.grey.shade300;
  final Color vipColor = Colors.amber.withOpacity(0.2);
  final Color memberColor = Colors.blue.withOpacity(0.2);

  // State variables
  Map<String, dynamic> connections = {"private": []}; // Hanya private
  bool isLoading = false;
  late AnimationController _fabController;
  late Animation<double> _fabAnimation;

  // Untuk tracking jumlah per owner
  Map<String, int> ownerCounts = {};

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _fetchSenders();
  }

  void _initializeAnimations() {
    _fabController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _fabAnimation = Tween<double>(begin: 1.0, end: 1.2).animate(
      CurvedAnimation(parent: _fabController, curve: Curves.easeInOut),
    );
  }

  Future<void> _fetchSenders() async {
    if (isLoading) return;

    setState(() => isLoading = true);

    try {
      final res = await ApiService.getMySender(widget.sessionKey);

      if (res['valid'] == true) {
        // DEBUG: Cetak respons dari server untuk membantu debugging
        print("RESPONSE FROM SERVER: ${res["connections"]}");

        setState(() {
          // Hanya ambil private connections
          connections = {"private": res["connections"]?["private"] ?? []};
          _calculateOwnerCounts();
        });
      } else {
        _showErrorSnackBar(res['message'] ?? "Failed to fetch senders");
      }
    } catch (e) {
      debugPrint("Error fetching senders: $e");
      _showErrorSnackBar("Failed to fetch senders. Please try again.");
    }

    setState(() => isLoading = false);
  }

  void _calculateOwnerCounts() {
    ownerCounts = {};
    final privateSenders = connections["private"] ?? [];
    
    for (var sender in privateSenders) {
      String owner = sender['owner'] ?? 'Unknown';
      ownerCounts[owner] = (ownerCounts[owner] ?? 0) + 1;
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: TextStyle(color: primaryWhite),
        ),
        backgroundColor: surfaceBlack,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: borderGrey),
        ),
      ),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: TextStyle(color: primaryWhite),
        ),
        backgroundColor: surfaceBlack,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: borderGrey),
        ),
      ),
    );
  }

  void _showAddSenderDialog() {
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            color: surfaceBlack,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: borderGrey),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: glassWhite,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: borderGrey),
                          ),
                          child: Icon(Icons.add, color: primaryWhite),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          "Add Sender",
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Container(
                      decoration: BoxDecoration(
                        color: glassWhite,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderGrey),
                      ),
                      child: TextField(
                        controller: controller,
                        keyboardType: TextInputType.phone,
                        style: TextStyle(color: primaryWhite),
                        decoration: InputDecoration(
                          hintText: "Enter phone number",
                          hintStyle: TextStyle(color: secondaryGrey),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                          prefixIcon: Icon(Icons.phone, color: secondaryGrey),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          style: TextButton.styleFrom(
                            foregroundColor: secondaryGrey,
                          ),
                          child: const Text("Cancel"),
                          onPressed: () => Navigator.pop(context),
                        ),
                        const SizedBox(width: 10),
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: glassWhite,
                            border: Border.all(color: borderGrey),
                          ),
                          child: TextButton(
                            style: TextButton.styleFrom(
                              foregroundColor: primaryWhite,
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                            ),
                            child: const Text("Submit"),
                            onPressed: () async {
                              Navigator.pop(context);
                              final number = controller.text.trim();
                              if (number.isEmpty) {
                                _showErrorSnackBar("Phone number cannot be empty");
                                return;
                              }

                              try {
                                final res = await ApiService.getPairing(widget.sessionKey, number);

                                if (res['valid'] == true) {
                                  _showPairingCodeDialog(number, res['pairingCode']);
                                  _fetchSenders();
                                } else {
                                  _showErrorSnackBar("Failed: ${res['message'] ?? 'Unknown error'}");
                                }
                              } catch (e) {
                                debugPrint("Error adding sender: $e");
                                _showErrorSnackBar("An error occurred. Please try again.");
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            color: surfaceBlack,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: borderGrey),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: glassWhite,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: borderGrey),
                          ),
                          child: Icon(Icons.phonelink_lock, color: primaryWhite),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          "Pairing Code",
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: glassWhite,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderGrey),
                      ),
                      child: Column(
                        children: [
                          Text(
                            "Number: $number",
                            style: TextStyle(
                              color: secondaryGrey,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 15),
                          Row(
                            children: [
                              Expanded(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                                  decoration: BoxDecoration(
                                    color: glassWhite,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(color: borderGrey),
                                  ),
                                  child: Text(
                                    code,
                                    style: TextStyle(
                                      color: primaryWhite,
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 3,
                                      fontFamily: 'Orbitron',
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 15),
                          Text(
                            "Enter this code in your WhatsApp app to complete pairing.",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: secondaryGrey,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: glassWhite,
                              border: Border.all(color: borderGrey),
                            ),
                            child: TextButton.icon(
                              style: TextButton.styleFrom(
                                foregroundColor: primaryWhite,
                                padding: const EdgeInsets.symmetric(vertical: 12),
                              ),
                              icon: const Icon(Icons.copy, size: 18),
                              label: const Text("Copy Code"),
                              onPressed: () {
                                Clipboard.setData(ClipboardData(text: code));
                                _showSuccessSnackBar("Pairing code copied to clipboard!");
                              },
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: glassWhite,
                              border: Border.all(color: borderGrey),
                            ),
                            child: TextButton(
                              style: TextButton.styleFrom(
                                foregroundColor: primaryWhite,
                                padding: const EdgeInsets.symmetric(vertical: 12),
                              ),
                              onPressed: () => Navigator.pop(context),
                              child: const Text("Close"),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  int _getTotalSenderCount() {
    return connections["private"]?.length ?? 0;
  }

  bool _isVipOwner(String owner) {
    // Asumsi: owner dengan username tertentu adalah VIP
    // Bisa disesuaikan dengan logika backend
    return owner.toLowerCase().contains('vip') || owner.toLowerCase().startsWith('vip');
  }

  @override
  Widget build(BuildContext context) {
    final totalSenders = _getTotalSenderCount();

    return Scaffold(
      backgroundColor: backgroundBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            color: glassWhite,
            border: Border(
              bottom: BorderSide(color: borderGrey, width: 1),
            ),
          ),
          child: ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(),
            ),
          ),
        ),
        title: Text(
          "My Senders",
          style: TextStyle(
            color: primaryWhite,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          // Stats Counter
          Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: glassWhite,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: borderGrey),
            ),
            child: Row(
              children: [
                Icon(Icons.phone, color: primaryWhite, size: 16),
                const SizedBox(width: 4),
                Text(
                  "$totalSenders",
                  style: TextStyle(
                    color: primaryWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            margin: const EdgeInsets.only(right: 8),
            child: IconButton(
              icon: Icon(Icons.refresh, color: primaryWhite),
              onPressed: _fetchSenders,
            ),
          ),
        ],
      ),
      floatingActionButton: AnimatedBuilder(
        animation: _fabAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: _fabAnimation.value,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: borderGrey, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.white.withOpacity(0.1),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: FloatingActionButton(
                backgroundColor: glassWhite,
                onPressed: () {
                  _fabController.forward().then((_) {
                    _fabController.reverse();
                  });
                  _showAddSenderDialog();
                },
                child: Icon(Icons.add, color: primaryWhite),
              ),
            ),
          );
        },
      ),
      body: isLoading
          ? Center(
              child: CircularProgressIndicator(
                color: primaryWhite,
              ),
            )
          : totalSenders == 0
              ? _buildEmptyState()
              : Column(
                  children: [
                    // Owner Statistics Section
                    if (ownerCounts.isNotEmpty) _buildOwnerStats(),
                    Expanded(child: _buildSenderList()),
                  ],
                ),
    );
  }

  Widget _buildOwnerStats() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Owner Statistics",
            style: TextStyle(
              color: secondaryGrey,
              fontSize: 12,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: ownerCounts.entries.map((entry) {
                final isVip = _isVipOwner(entry.key);
                return Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: isVip ? vipColor : memberColor,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isVip ? Colors.amber.withOpacity(0.3) : Colors.blue.withOpacity(0.3),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        isVip ? Icons.star : Icons.person,
                        color: isVip ? Colors.amber : Colors.blue,
                        size: 14,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        entry.key,
                        style: TextStyle(
                          color: primaryWhite,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: glassWhite,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          "${entry.value}",
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      if (isVip)
                        Padding(
                          padding: const EdgeInsets.only(left: 4),
                          child: Text(
                            "VIP",
                            style: TextStyle(
                              color: Colors.amber,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: glassWhite,
              shape: BoxShape.circle,
              border: Border.all(color: borderGrey),
            ),
            child: Icon(
              Icons.phone_disabled,
              color: secondaryGrey,
              size: 60,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            "No senders found",
            style: TextStyle(
              color: primaryWhite,
              fontSize: 18,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            "Add a sender to get started",
            style: TextStyle(
              color: secondaryGrey,
              fontSize: 14,
              fontFamily: 'ShareTechMono',
            ),
          ),
          const SizedBox(height: 20),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: glassWhite,
              border: Border.all(color: borderGrey),
            ),
            child: TextButton.icon(
              onPressed: _showAddSenderDialog,
              icon: Icon(Icons.add, color: primaryWhite),
              label: Text(
                "Add Sender",
                style: TextStyle(
                  color: primaryWhite,
                  fontFamily: 'Orbitron',
                ),
              ),
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderList() {
    final senders = connections["private"] ?? [];

    return RefreshIndicator(
      onRefresh: _fetchSenders,
      color: primaryWhite,
      backgroundColor: surfaceBlack,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        itemCount: senders.length,
        itemBuilder: (context, index) {
          final sender = senders[index];
          final owner = sender['owner'] ?? 'Unknown';
          final isVip = _isVipOwner(owner);

          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: glassWhite,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: borderGrey,
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: isVip ? vipColor : glassWhite,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isVip ? Colors.amber.withOpacity(0.3) : borderGrey,
                      ),
                    ),
                    child: Icon(
                      isVip ? Icons.star : Icons.phone,
                      color: isVip ? Colors.amber : primaryWhite,
                      size: 20,
                    ),
                  ),
                  title: Row(
                    children: [
                      Expanded(
                        child: Text(
                          sender['sessionName'] ?? 'Unknown',
                          style: TextStyle(
                            color: primaryWhite,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            fontSize: 14,
                          ),
                        ),
                      ),
                      if (isVip)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.amber.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.amber.withOpacity(0.3)),
                          ),
                          child: Text(
                            "VIP",
                            style: TextStyle(
                              color: Colors.amber,
                              fontSize: 8,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                    ],
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.person_outline,
                              size: 12,
                              color: isVip ? Colors.amber : secondaryGrey,
                            ),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                "Owner: $owner",
                                style: TextStyle(
                                  color: isVip ? Colors.amber : secondaryGrey,
                                  fontSize: 11,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: isVip ? FontWeight.w600 : FontWeight.normal,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Row(
                          children: [
                            Icon(
                              Icons.info_outline,
                              size: 12,
                              color: secondaryGrey,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              "Type: ${sender['type'] ?? 'N/A'}",
                              style: TextStyle(
                                color: secondaryGrey,
                                fontSize: 11,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: glassWhite,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderGrey),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: Colors.green,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "Active",
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _fabController.dispose();
    super.dispose();
  }
}

// API Service untuk komunikasi dengan backend
class ApiService {
  static const String _baseUrl = "http://server.aanz-panel.web.id:2000";

  static Future<Map<String, dynamic>> getMySender(String sessionKey) async {
    try {
      final response = await http.get(
        Uri.parse("$_baseUrl/api/whatsapp/mySender?key=$sessionKey"),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to fetch senders: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching senders: $e');
    }
  }

  static Future<Map<String, dynamic>> getPairing(String sessionKey, String number) async {
    try {
      final response = await http.get(
        Uri.parse("$_baseUrl/api/whatsapp/getPairing?key=$sessionKey&number=$number"),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get pairing code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error getting pairing code: $e');
    }
  }
}