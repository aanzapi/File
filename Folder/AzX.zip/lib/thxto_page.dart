//JANGAN LU MALING
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;

// ===== GLOBAL THEME COLOR (Hitam Putih dengan aksen merah) =====
const Color primaryWhite = Colors.white;
const Color secondaryGrey = Color(0xFF9CA3AF);
const Color backgroundBlack = Color(0xFF000000);
const Color glassWhite = Color(0x0DFFFFFF);
const Color borderGrey = Color(0x1AFFFFFF);
const Color accentRed = Color(0xFFFF0000);
const Color subtleRed = Color(0x33FF0000);

/// ==========================
/// CONFIG API
/// ==========================
const String baseUrl = "http://server.aanz-panel.web.id:2000";

/// ==========================
/// THANKS TO PAGE
/// ==========================
class ThanksToPage extends StatefulWidget {
  const ThanksToPage({super.key});

  @override
  State<ThanksToPage> createState() => _ThanksToPageState();
}

class _ThanksToPageState extends State<ThanksToPage> {
  List<Map<String, String>> thanksToList = [];
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    fetchThanksToList();
  }

  Future<void> fetchThanksToList() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      // Panggil API public (gak pake key)
      final uri = Uri.parse("$baseUrl/api/thx/list");
      
      final response = await http.get(uri).timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          throw TimeoutException("Koneksi timeout");
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonResponse = json.decode(response.body);
        
        if (jsonResponse['valid'] == true) {
          final List<dynamic> data = jsonResponse['data'] ?? [];
          setState(() {
            thanksToList = data.map((item) => {
              "name": item["name"]?.toString() ?? "",
              "role": item["role"]?.toString() ?? "",
              "photo": item["photo"]?.toString() ?? "",
              "telegram": item["telegram"]?.toString() ?? "",
            }).toList();
            isLoading = false;
          });
        } else {
          setState(() {
            errorMessage = jsonResponse['message'] ?? "Gagal memuat data";
            isLoading = false;
          });
        }
      } else {
        setState(() {
          errorMessage = "Gagal memuat data (${response.statusCode})";
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Error: ${e.toString()}";
        isLoading = false;
      });
      
      // Fallback ke data lokal jika error
      setState(() {
        thanksToList = [
          {
            "name": "AanzCuyxzzz",
            "role": "Developer",
            "photo": "https://cdn.yupra.my.id/yp/kxi0joa7.jpg",
            "telegram": "https://t.me/aanpublic",
          }
        ];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          "Thanks To",
          style: TextStyle(
            color: primaryWhite,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.4,
            fontFamily: 'Orbitron',
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            color: glassWhite,
            border: Border(
              bottom: BorderSide(color: borderGrey, width: 1),
            ),
          ),
          child: ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(),
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: accentRed),
            onPressed: fetchThanksToList,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Special Appreciation",
              style: TextStyle(
                color: primaryWhite,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
            const SizedBox(height: 6),
            Text(
              "Support & contribution behind this application",
              style: TextStyle(
                color: secondaryGrey,
                fontSize: 13,
                fontFamily: 'ShareTechMono',
              ),
            ),
            const SizedBox(height: 20),

            Expanded(
              child: isLoading
                  ? Center(
                      child: CircularProgressIndicator(
                        color: accentRed,
                      ),
                    )
                  : errorMessage != null
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.error_outline,
                                color: accentRed,
                                size: 48,
                              ),
                              const SizedBox(height: 12),
                              Text(
                                errorMessage!,
                                style: TextStyle(
                                  color: secondaryGrey,
                                  fontSize: 14,
                                  fontFamily: 'ShareTechMono',
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 16),
                              ElevatedButton(
                                onPressed: fetchThanksToList,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: subtleRed,
                                  foregroundColor: accentRed,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    side: BorderSide(color: accentRed.withOpacity(0.3)),
                                  ),
                                ),
                                child: const Text("Coba Lagi"),
                              ),
                            ],
                          ),
                        )
                      : thanksToList.isEmpty
                          ? Center(
                              child: Text(
                                "Belum ada data",
                                style: TextStyle(color: secondaryGrey, fontFamily: 'ShareTechMono'),
                              ),
                            )
                          : ListView.builder(
                              itemCount: thanksToList.length,
                              itemBuilder: (context, index) {
                                final item = thanksToList[index];
                                return ThanksCard(
                                  name: item["name"]!,
                                  role: item["role"]!,
                                  photo: item["photo"]!,
                                  telegram: item["telegram"]!,
                                );
                              },
                            ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ==========================
/// THANKS CARD (TETAP SAMA)
/// ==========================
class ThanksCard extends StatelessWidget {
  final String name;
  final String role;
  final String photo;
  final String telegram;

  const ThanksCard({
    super.key,
    required this.name,
    required this.role,
    required this.photo,
    required this.telegram,
  });

  Future<void> _openTelegram() async {
    final uri = Uri.parse(telegram);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: glassWhite,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: borderGrey,
              ),
            ),
            child: Row(
              children: [
                /// FOTO
                CircleAvatar(
                  radius: 24,
                  backgroundImage: NetworkImage(photo),
                  backgroundColor: Colors.transparent,
                  onBackgroundImageError: (_, __) {
                    // Fallback jika gambar error
                  },
                ),

                const SizedBox(width: 14),

                /// TEXT
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        role,
                        style: TextStyle(
                          color: secondaryGrey,
                          fontSize: 12,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),

                /// BUTTON TELEGRAM
                InkWell(
                  onTap: _openTelegram,
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: subtleRed,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: accentRed.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          FontAwesomeIcons.telegram,
                          color: accentRed,
                          size: 14,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "Telegram",
                          style: TextStyle(
                            color: accentRed,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}