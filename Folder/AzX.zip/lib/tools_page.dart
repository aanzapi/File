//JANGAN LU MALING
import 'chat_page.dart';
import 'sholat_tools_page.dart';
import 'al_quran.dart';
import 'tiktok.dart';
import 'Instagram.dart';
import 'spotify.dart';
import 'nik_parse.dart';
import 'spam_ngl.dart';
import 'telegram.dart';
import 'ddos_panel.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'chat_ai_page.dart';
import 'nik_check_page.dart';
import 'phone_lookup.dart'; // Tambahkan import untuk PhoneLookupPage
import 'subdomain_finder_page.dart';
import 'anime.dart';

// ===== GLOBAL COLOR CONFIG =====
const Color primaryColor = Color(0xFF9CA3AF); // Abu-abu (Tailwind Gray-400)

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _headerController;
  late AnimationController _listController;
  late Animation<double> _headerAnimation;
  late List<Animation<double>> _itemAnimations;

  @override
  void initState() {
    super.initState();
    _headerController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _listController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _headerAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _headerController, curve: Curves.easeOutBack),
    );

    _itemAnimations = List.generate(
  15,
  (index) => Tween<double>(begin: 0, end: 1).animate(
    CurvedAnimation(
      parent: _listController,
      curve: Interval(
        index * 0.1,
        0.5 + (index * 0.1),
        curve: Curves.easeOutBack,
      ),
    ),
  ),
);

    _headerController.forward();
    _listController.forward();
  }

  @override
  void dispose() {
    _headerController.dispose();
    _listController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              color: Colors.black,
            ),
          ),
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _headerController,
              builder: (context, child) {
                return Opacity(
                  opacity: _headerAnimation.value * 0.05,
                  child: CustomPaint(
                    painter: GridPatternPainter(),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _buildAnimatedHeader(),
                const SizedBox(height: 24),
                Expanded(child: _buildToolsList()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedHeader() {
  return AnimatedBuilder(
    animation: _headerAnimation,
    builder: (context, child) {
      return Transform.translate(
        offset: Offset(0, (1 - _headerAnimation.value) * 30),
        child: Opacity(
          opacity: _headerAnimation.value,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                child: Container(
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        primaryColor.withOpacity(0.18),
                        Colors.black.withOpacity(0.65),
                      ],
                    ),
                    image: const DecorationImage(
                      image: AssetImage('assets/images/digital.jpg'),
                      fit: BoxFit.cover,
                      opacity: 0.25,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: primaryColor.withOpacity(0.4),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: primaryColor.withOpacity(0.18),
                        blurRadius: 24,
                        spreadRadius: 2,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  primaryColor.withOpacity(0.45),
                                  primaryColor.withOpacity(0.15),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Icon(
                              Icons.apps,
                              color: primaryColor,
                              size: 26,
                            ),
                          ),
                          const SizedBox(width: 14),
                          const Text(
                            "Digital Tools",
                            style: TextStyle(
                              color: primaryColor,
                              fontSize: 26,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        "Select a tool to begin",
                        style: TextStyle(
                          color: primaryColor.withOpacity(0.85),
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    },
  );
}

  Widget _buildToolsList() {
  final tools = [
    {'icon': Icons.chat, 'label': 'Chat AI Assistant Avg 7', 'description': 'Asisten percakapan bertenaga AI'},
    {'icon': Icons.badge, 'label': 'NIK Check', 'description': 'Validasi nomor identitas (KTP)'},
    {'icon': Icons.phone, 'label': 'Phone Lookup', 'description': 'Cari informasi detail nomor telepon'},
    {'icon': Icons.language, 'label': 'Subdomain Finder', 'description': 'Temukan subdomain dari sebuah domain'},
    {'icon': Icons.movie_filter_outlined, 'label': 'Anime', 'description': 'Tempatnya para wibu marathon anime'},
    {'icon': Icons.security_update_warning, 'label': 'DDoS Attack', 'description': 'Panel Stress Test Jaringan (Attack Panel)'},
    {'icon': Icons.send_and_archive, 'label': 'Report Telegram', 'description': 'Layanan pelaporan akun Telegram (Spam)'},
    {'icon': Icons.report_gmailerrorred, 'label': 'Spam NGL', 'description': 'spam link akun NGL'},
    {'icon': Icons.visibility, 'label': 'NIK Parse', 'description': 'Validasi nomor identitas Menggunakan Nik Track'},
    {'icon': Icons.queue_music, 'label': 'Search Music', 'description': 'Cari playlist musik kesukaan mu'},
    {'icon': Icons.camera_alt, 'label': 'Instagram Downloader', 'description': 'Masukkan URL Instagram Reel, Post, atau Story untuk mendownload media'},
    {'icon': Icons.visibility, 'label': 'Tiktok Downloader', 'description': 'Masukan URL TikTok Postingan Kesukaanmu'},
    {'icon': Icons.import_contacts, 'label': 'Al Quran', 'description': 'Islamic membaca Al quran'},
    {'icon': Icons.access_time, 'label': 'Jadwal Sholat', 'description': 'Jadwal sholat tasbih dan arah Kiblat'},
    {'icon': Icons.chat_bubble_outline, 'label': 'Chat User', 'description': 'Berkomunikasi dengan user Lain'},
  ];

  return ListView.builder(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    itemCount: tools.length,
    itemBuilder: (context, index) {
      final tool = tools[index];
      return _buildAnimatedToolItem(
        icon: tool['icon'] as IconData,
        label: tool['label'] as String,
        description: tool['description'] as String,
        animation: _itemAnimations[index],
        onTap: () => _navigateToTool(tool['label'] as String),
      );
    },
  );
}



  void _navigateToTool(String toolName) {
  Widget page;
  switch (toolName) {
    case 'Chat AI Assistant Avg 7':
      page = ChatAIPage(sessionKey: widget.sessionKey);
      break;
    case 'NIK Check':
      page = NIKCheckPage(sessionKey: widget.sessionKey);
      break;
    case 'Phone Lookup':
      page = PhoneLookupPage(sessionKey: widget.sessionKey);
      break;
    case 'Anime':
      page = const HomeAnimePage();
      break;
    case 'Subdomain Finder':
      page = SubdomainFinderPage(sessionKey: widget.sessionKey);
      break;
    case 'DDoS Attack':
  page = AttackPanel(
    sessionKey: widget.sessionKey,
    listDDoS: const [], // Tambahkan list kosong ini agar tidak eror
  ); 
  break;
    case 'Report Telegram':
  page = TelegramSpamPage(sessionKey: widget.sessionKey);
  break;

case 'Spam NGL':
  page = NglPage();
  break;
  
  case 'NIK Parse':
  page = NikParsePage();
  break;
  
  case 'Search Music':
  page = SpotifyPage();
  break;
  
  case 'Instagram Downloader':
  page = InstagramDownloaderPage();
  break;
  
  case 'Tiktok Downloader':
  page = TiktokDownloaderPage();
  break;
  
  case 'Al Quran':
  page = AlQuranPage();
  break;
  
  case 'Jadwal Sholat':
  page = const SholatToolsPage();
  break;
  
  case 'Chat User':
  page = ChatPage(sessionKey: widget.sessionKey);
  break;
    default:
      return;
  }

  Navigator.of(context).push(
    PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(1.0, 0.0);
        const end = Offset.zero;
        const curve = Curves.easeInOut;
        var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
        return SlideTransition(position: animation.drive(tween), child: child);
      },
      transitionDuration: const Duration(milliseconds: 300),
    ),
  );
}



  Widget _buildAnimatedToolItem({
    required IconData icon,
    required String label,
    required String description,
    required Animation<double> animation,
    required VoidCallback onTap,
  }) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset((1 - animation.value) * 50, 0),
          child: Opacity(
            opacity: animation.value,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: _InteractiveToolItem(icon: icon, label: label, description: description, onTap: onTap),
            ),
          ),
        );
      },
    );
  }
}

class _InteractiveToolItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final String description;
  final VoidCallback onTap;

  const _InteractiveToolItem({
    required this.icon,
    required this.label,
    required this.description,
    required this.onTap,
  });

  @override
  State<_InteractiveToolItem> createState() => _InteractiveToolItemState();
}

class _InteractiveToolItemState extends State<_InteractiveToolItem>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  bool _isPressed = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 180),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.96).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        setState(() => _isPressed = true);
        _controller.forward();
      },
      onTapUp: (_) {
        setState(() => _isPressed = false);
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () {
        setState(() => _isPressed = false);
        _controller.reverse();
      },
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),

                // 🔥 Gradient Glass Effect
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    primaryColor.withOpacity(0.15),
                    Colors.white.withOpacity(0.02),
                  ],
                ),

                // ✨ Elegant Border
                border: Border.all(
                  color: _isPressed
                      ? primaryColor.withOpacity(0.6)
                      : primaryColor.withOpacity(0.25),
                  width: 1.2,
                ),

                // 🌫 Glow + Depth Shadow
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(
                        _isPressed ? 0.35 : 0.18),
                    blurRadius: _isPressed ? 25 : 18,
                    spreadRadius: 1,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Row(
                children: [
                  // ICON CONTAINER
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      gradient: LinearGradient(
                        colors: [
                          primaryColor.withOpacity(0.4),
                          primaryColor.withOpacity(0.15),
                        ],
                      ),
                    ),
                    child: Icon(
                      widget.icon,
                      color: primaryColor,
                      size: 26,
                    ),
                  ),

                  const SizedBox(width: 18),

                  // TEXT SECTION
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.label,
                          style: const TextStyle(
                            color: primaryColor,
                            fontSize: 17,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          widget.description,
                          style: TextStyle(
                            color: primaryColor.withOpacity(0.75),
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ARROW
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    child: Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: primaryColor.withOpacity(0.6),
                      size: 18,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class GridPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = primaryColor // Hijau muda cerah
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.5;
    const gridSize = 30.0;
    for (double x = 0; x < size.width; x += gridSize) canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y < size.height; y += gridSize) canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}