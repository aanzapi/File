//JANGAN LU MALING
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart'; // Tambahkan ini untuk clipboard

class SubdomainFinderPage extends StatefulWidget {
  final String sessionKey;

  const SubdomainFinderPage({super.key, required this.sessionKey});

  @override
  State<SubdomainFinderPage> createState() => _SubdomainFinderPageState();
}

class _SubdomainFinderPageState extends State<SubdomainFinderPage> {
  final TextEditingController _domainController = TextEditingController();
  List<String> _subdomains = [];
  bool _isLoading = false;

  Future<void> _findSubdomains() async {
    if (_domainController.text.isEmpty) return;
    setState(() {
      _isLoading = true;
      _subdomains = [];
    });
    try {
      final response = await http.get(Uri.parse('http://server.aanz-panel.web.id:2000/api/tools/subdomain-finder?key=${widget.sessionKey}&domain=${_domainController.text}'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            final allSubdomains = <String>{};
            for (var item in data['data']) {
              final subdomainList = item.toString().split('\n');
              for (var subdomain in subdomainList) {
                if (subdomain.isNotEmpty) {
                  allSubdomains.add(subdomain.trim());
                }
              }
            }
            _subdomains = allSubdomains.toList();
            _subdomains.sort();
          });
        } else {
          _showSnackBar('Failed to find subdomains', isError: true);
        }
      } else {
        _showSnackBar('Failed to connect to subdomain service', isError: true);
      }
    } catch (e) {
      _showSnackBar('Error: ${e.toString()}', isError: true);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message),
      backgroundColor: isError ? Colors.red.shade900 : Colors.grey.shade800,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text('Subdomain Finder', style: TextStyle(color: Color(0xFFFF0000))),
        iconTheme: const IconThemeData(color: Color(0xFFFF0000)),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFFF0000).withOpacity(0.3))
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Enter Domain', style: TextStyle(color: Color(0xFFFF0000), fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _domainController,
                    style: const TextStyle(color: Color(0xFFFF0000)),
                    decoration: InputDecoration(
                      hintText: 'example.com',
                      hintStyle: TextStyle(color: const Color(0xFFFF0000).withOpacity(0.5)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: const BorderSide(color: Color(0xFFFF0000))
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: const Color(0xFFFF0000).withOpacity(0.3))
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: const BorderSide(color: Color(0xFFFF0000))
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade800,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _isLoading ? null : _findSubdomains,
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFF0000),
                        foregroundColor: Colors.black
                    ),
                    child: _isLoading
                        ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            color: Colors.black,
                            strokeWidth: 2
                        )
                    )
                        : const Text('Find Subdomains'),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator(color: Color(0xFFFF0000)))
                : _subdomains.isEmpty
                ? const Center(child: Text('No subdomains found', style: TextStyle(color: Color(0xFFFF0000))))
                : ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _subdomains.length,
              itemBuilder: (context, index) {
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                      color: Colors.grey.shade900,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFFFF0000).withOpacity(0.2))
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.link, color: Color(0xFFFF0000), size: 16),
                      const SizedBox(width: 12),
                      Expanded(child: Text(_subdomains[index], style: const TextStyle(color: Color(0xFFFF0000)))),
                      IconButton(
                        icon: const Icon(Icons.copy, color: Color(0xFFFF0000), size: 16),
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: _subdomains[index]));
                          _showSnackBar('Copied to clipboard!');
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}