//JANGAN LU MALING
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';

// ===== GLOBAL THEME COLOR (Hitam Putih dengan aksen merah) =====
const Color primaryWhite = Colors.white;
const Color secondaryGrey = Color(0xFF9CA3AF);
const Color backgroundBlack = Color(0xFF000000);
const Color glassWhite = Color(0x0DFFFFFF);
const Color borderGrey = Color(0x1AFFFFFF);
const Color accentRed = Color(0xFFFF0000);
const Color subtleRed = Color(0x33FF0000);

const String baseUrl = "http://server.aanz-panel.web.id:2000/api/user";

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> with SingleTickerProviderStateMixin {
  final oldPassCtrl = TextEditingController();
  final newPassCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading = false;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutQuad,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    oldPassCtrl.dispose();
    newPassCtrl.dispose();
    confirmPassCtrl.dispose();
    super.dispose();
  }

  Future<void> _changePassword() async {
    final oldPass = oldPassCtrl.text.trim();
    final newPass = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showMessage("All fields are required");
      return;
    }

    if (newPass != confirmPass) {
      _showMessage("New password doesn't match confirmation");
      return;
    }

    if (newPass.length < 6) {
      _showMessage("Password must be at least 6 characters");
      return;
    }

    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "key": widget.sessionKey,
        },
      );

      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _showMessage("Password changed successfully", isSuccess: true);
        // Clear fields after success
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _showMessage(data['message'] ?? "Failed to change password");
      }
    } catch (e) {
      _showMessage("Server error: $e");
    }

    setState(() => isLoading = false);
  }

  void _showMessage(String msg, {bool isSuccess = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: backgroundBlack.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: borderGrey, width: 1),
        ),
        title: Row(
          children: [
            Icon(
              isSuccess ? Icons.check_circle : Icons.info_outline,
              color: isSuccess ? const Color(0xFF22C55E) : accentRed,
              size: 28,
            ),
            const SizedBox(width: 10),
            Text(
              isSuccess ? "Success" : "Information",
              style: TextStyle(
                color: primaryWhite,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                fontSize: 18,
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: TextStyle(color: secondaryGrey, fontFamily: 'ShareTechMono'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              foregroundColor: accentRed,
              backgroundColor: subtleRed,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: accentRed.withOpacity(0.3)),
              ),
            ),
            child: const Text("CLOSE"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundBlack,
      appBar: AppBar(
        title: Text(
          "Change Password",
          style: TextStyle(
            color: primaryWhite,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            color: glassWhite,
            border: Border(
              bottom: BorderSide(color: borderGrey, width: 1),
            ),
          ),
          child: ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(),
            ),
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: primaryWhite),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header dengan ikon
                Center(
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: subtleRed,
                      border: Border.all(
                        color: accentRed.withOpacity(0.3),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: accentRed.withOpacity(0.2),
                          blurRadius: 30,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.lock_reset,
                      color: accentRed,
                      size: 50,
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                
                // Form Title
                Center(
                  child: Text(
                    "SECURITY SETTINGS",
                    style: TextStyle(
                      color: secondaryGrey,
                      fontSize: 12,
                      fontFamily: "ShareTechMono",
                      letterSpacing: 2,
                    ),
                  ),
                ),
                const SizedBox(height: 30),

                // Old Password Field
                _buildGlassField(
                  hint: "Old Password",
                  controller: oldPassCtrl,
                  obscure: true,
                  icon: Icons.lock_outline,
                ),
                const SizedBox(height: 20),

                // New Password Field
                _buildGlassField(
                  hint: "New Password",
                  controller: newPassCtrl,
                  obscure: true,
                  icon: Icons.fingerprint,
                ),
                const SizedBox(height: 20),

                // Confirm Password Field
                _buildGlassField(
                  hint: "Confirm Password",
                  controller: confirmPassCtrl,
                  obscure: true,
                  icon: Icons.verified_outlined,
                ),
                
                const SizedBox(height: 40),

                // Password Requirements
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    color: glassWhite,
                    border: Border.all(color: borderGrey),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Password Requirements:",
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 14,
                          fontFamily: "Orbitron",
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      _buildRequirementItem(
                        "Minimum 6 characters",
                        newPassCtrl.text.length >= 6,
                      ),
                      _buildRequirementItem(
                        "Match confirmation",
                        newPassCtrl.text.isNotEmpty && 
                        newPassCtrl.text == confirmPassCtrl.text,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 40),

                // Change Password Button
                Center(
                  child: _buildGlassButton(
                    onPressed: isLoading ? null : _changePassword,
                    label: "CHANGE PASSWORD",
                    isLoading: isLoading,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassField({
    required String hint,
    required TextEditingController controller,
    required bool obscure,
    required IconData icon,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: glassWhite,
        border: Border.all(color: borderGrey),
        boxShadow: [
          BoxShadow(
            color: accentRed.withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: TextField(
            controller: controller,
            obscureText: obscure,
            style: TextStyle(color: primaryWhite, fontSize: 16),
            cursorColor: accentRed,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: secondaryGrey.withOpacity(0.7), fontFamily: 'ShareTechMono'),
              prefixIcon: Icon(icon, color: accentRed),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 16,
              ),
            ),
            onChanged: (_) => setState(() {}), // Untuk update requirements
          ),
        ),
      ),
    );
  }

  Widget _buildRequirementItem(String text, bool isMet) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(
            isMet ? Icons.check_circle : Icons.radio_button_unchecked,
            color: isMet ? const Color(0xFF22C55E) : accentRed,
            size: 16,
          ),
          const SizedBox(width: 10),
          Text(
            text,
            style: TextStyle(
              color: isMet ? primaryWhite : secondaryGrey,
              fontSize: 12,
              fontFamily: "ShareTechMono",
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGlassButton({
    required VoidCallback? onPressed,
    required String label,
    required bool isLoading,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: accentRed.withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: subtleRed,
          foregroundColor: accentRed,
          disabledBackgroundColor: Colors.transparent,
          disabledForegroundColor: secondaryGrey,
          padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: accentRed.withOpacity(0.3)),
          ),
          elevation: 0,
        ),
        child: isLoading
            ? SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  color: accentRed,
                  strokeWidth: 2,
                ),
              )
            : Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  fontFamily: "Orbitron",
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                ),
              ),
      ),
    );
  }
}