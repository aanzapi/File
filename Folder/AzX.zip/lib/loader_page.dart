//JANGAN LU MALING - COMPLETELY REDESIGNED VERSION
import 'report_wa.dart';
import 'thxto_page.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'dart:async';
import 'package:flutter/services.dart';

import 'telegram.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'sender_page.dart';

// ===== NEW COLOR SCHEME - CYAN/TEAL THEME =====
const Color primaryCyan = Color(0xFF00E0FF);
const Color secondaryBlue = Color(0xFF2A2A4A);
const Color deepBlue = Color(0xFF0A0A1A);
const Color glassBlue = Color(0x1A00E0FF);
const Color accentPurple = Color(0xFF9D4EFF);
const Color softPurple = Color(0x1A9D4EFF);
const Color cardBg = Color(0xFF131328);
const Color lightCard = Color(0xFF1A1A35);

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with TickerProviderStateMixin {
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  late Widget _selectedPage;
  
  // Animation Controllers
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  
  // Stats
  int _totalUsers = 0;
  bool _isLoadingTotalUsers = false;
  
  // WebSocket
  late WebSocketChannel channel;
  
  // Update Info
  Map<String, dynamic> _appUpdateInfo = {};
  bool _isLoadingUpdateInfo = false;
  bool _hasUpdateError = false;

  @override
  void initState() {
    super.initState();
    
    // Initialize data
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    // Setup animations
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    );

    // Start animations
    _fadeController.forward();

    // Set initial page
    _selectedPage = _buildDashboard();

    // Initialize
    _initAndroidIdAndConnect();
    _fetchAppUpdateInfo();
    _fetchTotalUsers();
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('http://server.aanz-panel.web.id:2000'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        _handleInvalidSession(data['reason'] == 'androidIdMismatch' 
          ? "Account logged on another device" 
          : "Invalid session");
      }
    });
  }

  Future<void> _fetchAppUpdateInfo() async {
    setState(() {
      _isLoadingUpdateInfo = true;
      _hasUpdateError = false;
    });

    try {
      final response = await http.get(
        Uri.parse('http://server.aanz-panel.web.id:2000/api/update/info'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _appUpdateInfo = Map<String, dynamic>.from(data['data']);
            _isLoadingUpdateInfo = false;
          });
        } else {
          setState(() {
            _isLoadingUpdateInfo = false;
            _hasUpdateError = true;
          });
        }
      }
    } catch (e) {
      setState(() {
        _isLoadingUpdateInfo = false;
        _hasUpdateError = true;
      });
    }
  }

  Future<void> _fetchTotalUsers() async {
    setState(() => _isLoadingTotalUsers = true);
    
    try {
      final response = await http.get(
        Uri.parse('http://server.aanz-panel.web.id:2000/api/user/listUsers?key=$sessionKey'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _totalUsers = (data['users'] as List).length;
            _isLoadingTotalUsers = false;
          });
        }
      }
    } catch (e) {
      setState(() => _isLoadingTotalUsers = false);
    }
  }

  void _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: deepBlue,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: primaryCyan.withOpacity(0.3)),
        ),
        title: Text(
          "Session Expired",
          style: TextStyle(
            color: primaryCyan,
            fontFamily: "Orbitron",
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Text(
          message,
          style: TextStyle(color: Colors.white70, fontFamily: "ShareTechMono"),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Text(
              "OK",
              style: TextStyle(color: primaryCyan, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
      _fadeController.reset();
      _fadeController.forward();

      switch(index) {
        case 0:
          _selectedPage = _buildDashboard();
          break;
        case 1:
          if (!["vip", "owner"].contains(role.toLowerCase())) {
            _selectedPage = AttackPage(
              username: username,
              password: password,
              listBug: listBug,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            );
          } else {
            _showAttackMenu();
          }
          break;
        case 2:
          _selectedPage = ToolsPage(
            sessionKey: sessionKey,
            userRole: role,
          );
          break;
      }
    });
  }

  void _showAttackMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: deepBlue,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
          border: Border.all(color: primaryCyan.withOpacity(0.2)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 50,
              height: 4,
              margin: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: primaryCyan.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                "Attack Modules",
                style: TextStyle(
                  color: primaryCyan,
                  fontSize: 22,
                  fontFamily: "Orbitron",
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
            ),
            _buildAttackOption(
              icon: Icons.person_outline,
              title: "Bug Contact",
              desc: "Target phone numbers",
              color: primaryCyan,
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  _selectedPage = AttackPage(
                    username: username,
                    password: password,
                    listBug: listBug,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey,
                  );
                });
              },
            ),
            _buildAttackOption(
              icon: Icons.auto_awesome,
              title: "Custom Bug",
              desc: "Advanced payload",
              color: accentPurple,
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  _selectedPage = CustomAttackPage(
                    username: username,
                    password: password,
                    listPayload: listPayload,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey,
                  );
                });
              },
            ),
            _buildAttackOption(
              icon: Icons.report,
              title: "Report WA",
              desc: "Report accounts",
              color: Colors.orangeAccent,
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  _selectedPage = const ReportWaPage(
                    sessionKey: "data",
                    role: "user",
                  );
                });
              },
            ),
            _buildAttackOption(
              icon: Icons.group,
              title: "Bug Group",
              desc: "Group attacks",
              color: Colors.greenAccent,
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  _selectedPage = GroupBugPage(
                    username: username,
                    password: password,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey,
                  );
                });
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildAttackOption({
    required IconData icon,
    required String title,
    required String desc,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          colors: [
            cardBg,
            cardBg.withBlue(40),
          ],
        ),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withOpacity(0.1),
          ),
          child: Icon(icon, color: color),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: Colors.white,
            fontFamily: "Orbitron",
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(
          desc,
          style: const TextStyle(color: Colors.white60, fontFamily: "ShareTechMono"),
        ),
        trailing: Icon(Icons.arrow_forward_ios, color: color, size: 16),
        onTap: onTap,
      ),
    );
  }

  Widget _buildDashboard() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            deepBlue,
            const Color(0xFF0D0D1A),
            cardBg,
          ],
        ),
      ),
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(),
                  const SizedBox(height: 24),
                  _buildStatsRow(),
                  const SizedBox(height: 24),
                  _buildQuickAccess(),
                  const SizedBox(height: 24),
                  _buildNewsSection(),
                  const SizedBox(height: 24),
                  _buildUpdateSection(),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    bool isExpired = false;
    try {
      DateTime expDate = DateTime.parse(expiredDate);
      isExpired = expDate.isBefore(DateTime.now());
    } catch (e) {}

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            cardBg,
            lightCard,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: primaryCyan.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: primaryCyan.withOpacity(0.1),
            blurRadius: 30,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 70,
                height: 70,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: primaryCyan, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: primaryCyan.withOpacity(0.3),
                      blurRadius: 15,
                      spreadRadius: 2,
                    ),
                  ],
                  image: const DecorationImage(
                    image: NetworkImage('https://cdn.yupra.my.id/yp/s3m8hy4p.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontFamily: "Orbitron",
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: primaryCyan.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: primaryCyan.withOpacity(0.3)),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: TextStyle(
                          color: primaryCyan,
                          fontSize: 12,
                          fontFamily: "Orbitron",
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isExpired ? Colors.red.withOpacity(0.1) : primaryCyan.withOpacity(0.1),
                  border: Border.all(
                    color: isExpired ? Colors.red : primaryCyan,
                    width: 1,
                  ),
                ),
                child: Icon(
                  isExpired ? Icons.warning_rounded : Icons.check_circle_rounded,
                  color: isExpired ? Colors.red : primaryCyan,
                  size: 28,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.02),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.05)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildInfoChip(
                  icon: Icons.timer,
                  label: "Expires",
                  value: _formatExpiredDate(expiredDate),
                  color: isExpired ? Colors.red : primaryCyan,
                ),
                Container(width: 1, height: 30, color: Colors.white.withOpacity(0.1)),
                _buildInfoChip(
                  icon: Icons.devices,
                  label: "Device ID",
                  value: androidId.length > 15 ? '${androidId.substring(0, 12)}...' : androidId,
                  color: accentPurple,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: color, size: 16),
              const SizedBox(width: 4),
              Text(
                label,
                style: const TextStyle(color: Colors.white60, fontSize: 12, fontFamily: "ShareTechMono"),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontFamily: "ShareTechMono",
              fontWeight: FontWeight.bold,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            title: "TOTAL USERS",
            value: _isLoadingTotalUsers ? "..." : _totalUsers.toString(),
            icon: Icons.people_alt,
            gradient: [primaryCyan, accentPurple],
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildStatCard(
            title: "BUGS READY",
            value: listBug.length.toString(),
            icon: Icons.bug_report,
            gradient: [accentPurple, Colors.pinkAccent],
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required List<Color> gradient,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardBg, lightCard],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: gradient.first.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: gradient.first.withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: gradient,
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: Colors.white, size: 20),
              ),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 10,
                  fontFamily: "ShareTechMono",
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 32,
              fontFamily: "Orbitron",
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickAccess() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8, bottom: 16),
          child: Text(
            "QUICK ACCESS",
            style: TextStyle(
              color: primaryCyan.withOpacity(0.7),
              fontSize: 14,
              fontFamily: "Orbitron",
              letterSpacing: 2,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Row(
          children: [
            Expanded(
              child: _buildActionButton(
                icon: FontAwesomeIcons.telegram,
                label: "Telegram",
                color: primaryCyan,
                onTap: () async {
                  final uri = Uri.parse("tg://resolve?domain=ZYxxx80");
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  } else {
                    await launchUrl(
                      Uri.parse("https://t.me/aanchannell"),
                      mode: LaunchMode.externalApplication,
                    );
                  }
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildActionButton(
                icon: Icons.phone_android,
                label: "Senders",
                color: accentPurple,
                onTap: () {
                  setState(() {
                    _selectedPage = SenderPage(sessionKey: sessionKey);
                  });
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                cardBg,
                lightCard,
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(height: 8),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: "Orbitron",
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNewsSection() {
    if (newsList.isEmpty) {
      return Container(
        height: 180,
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.newspaper, color: Colors.white24, size: 48),
              const SizedBox(height: 12),
              Text(
                "No Announcements",
                style: TextStyle(color: Colors.white60, fontFamily: "ShareTechMono"),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8, bottom: 16),
          child: Text(
            "LATEST NEWS",
            style: TextStyle(
              color: accentPurple.withOpacity(0.7),
              fontSize: 14,
              fontFamily: "Orbitron",
              letterSpacing: 2,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        SizedBox(
          height: 220,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: newsList.length,
            itemBuilder: (context, index) {
              final news = newsList[index];
              return Container(
                width: 300,
                margin: const EdgeInsets.only(right: 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [cardBg, lightCard],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: primaryCyan.withOpacity(0.2)),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(28),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (news['image'] != null && news['image'].toString().isNotEmpty)
                        Positioned.fill(
                          child: Opacity(
                            opacity: 0.3,
                            child: Image.network(
                              news['image'],
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(color: lightCard),
                            ),
                          ),
                        ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              deepBlue.withOpacity(0.9),
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: primaryCyan.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: primaryCyan.withOpacity(0.3)),
                              ),
                              child: Text(
                                "NEWS #${index + 1}",
                                style: TextStyle(
                                  color: primaryCyan,
                                  fontSize: 10,
                                  fontFamily: "Orbitron",
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              news['title'] ?? 'No Title',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontFamily: "Orbitron",
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              news['desc'] ?? '',
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                                fontFamily: "ShareTechMono",
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildUpdateSection() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardBg, lightCard],
        ),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: primaryCyan.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [primaryCyan, accentPurple],
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(Icons.system_update_rounded, color: Colors.white, size: 28),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "App Version",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.5),
                          fontSize: 12,
                          fontFamily: "ShareTechMono",
                        ),
                      ),
                      Text(
                        "v${_appUpdateInfo['version'] ?? '4.0.0'}",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontFamily: "Orbitron",
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                if (_appUpdateInfo.isNotEmpty && !_isLoadingUpdateInfo)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: primaryCyan.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: primaryCyan.withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: primaryCyan,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "Update",
                          style: TextStyle(color: primaryCyan, fontSize: 12, fontFamily: "Orbitron"),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
            if (_appUpdateInfo.isNotEmpty && !_isLoadingUpdateInfo) ...[
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.02),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.05)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            _appUpdateInfo['description'] ?? 'New update available',
                            style: const TextStyle(color: Colors.white70, fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    if (_appUpdateInfo['downloadUrl'] != null)
                      Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () async {
                            final url = _appUpdateInfo['downloadUrl'].toString();
                            await Clipboard.setData(ClipboardData(text: url));
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: const Text("Download link copied!"),
                                backgroundColor: primaryCyan,
                                behavior: SnackBarBehavior.floating,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                            );
                          },
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [primaryCyan, accentPurple],
                              ),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: const Center(
                              child: Text(
                                "COPY DOWNLOAD LINK",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: "Orbitron",
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
            if (_isLoadingUpdateInfo)
              const Padding(
                padding: EdgeInsets.all(32.0),
                child: Center(
                  child: CircularProgressIndicator(color: primaryCyan),
                ),
              ),
          ],
        ),
      ),
    );
  }

  String _formatExpiredDate(String date) {
    try {
      DateTime expDate = DateTime.parse(date);
      Duration diff = expDate.difference(DateTime.now());
      if (diff.inDays > 30) return "${expDate.day}/${expDate.month}/${expDate.year}";
      if (diff.inDays > 0) return "${diff.inDays}d left";
      if (diff.inHours > 0) return "${diff.inHours}h left";
      if (diff.inMinutes > 0) return "${diff.inMinutes}m left";
      return "EXPIRED";
    } catch (e) {
      return date;
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_selectedIndex != 0) {
          setState(() {
            _selectedIndex = 0;
            _selectedPage = _buildDashboard();
          });
          return false;
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: deepBlue,
        extendBody: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: Builder(
            builder: (context) => IconButton(
              icon: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: primaryCyan.withOpacity(0.2)),
                ),
                child: Icon(Icons.menu_rounded, color: primaryCyan, size: 24),
              ),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
          title: Image.asset('assets/images/title.png', height: 35),
          centerTitle: true,
          actions: [
            Container(
              margin: const EdgeInsets.only(right: 16),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: primaryCyan.withOpacity(0.3)),
              ),
              child: const CircleAvatar(
                radius: 18,
                backgroundImage: NetworkImage('https://cdn.yupra.my.id/yp/s3m8hy4p.jpg'),
              ),
            ),
          ],
        ),
        drawer: _buildDrawer(),
        body: FadeTransition(
          opacity: _fadeAnimation,
          child: _selectedPage,
        ),
        bottomNavigationBar: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [cardBg, lightCard],
            ),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: primaryCyan.withOpacity(0.2)),
            boxShadow: [
              BoxShadow(
                color: primaryCyan.withOpacity(0.1),
                blurRadius: 20,
                spreadRadius: 0,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30),
            child: BottomNavigationBar(
              backgroundColor: Colors.transparent,
              selectedItemColor: primaryCyan,
              unselectedItemColor: Colors.white30,
              currentIndex: _selectedIndex,
              onTap: _onTabSelected,
              type: BottomNavigationBarType.fixed,
              elevation: 0,
              items: const [
                BottomNavigationBarItem(
                  icon: Icon(Icons.dashboard_outlined, size: 26),
                  activeIcon: Icon(Icons.dashboard, size: 28),
                  label: "Home",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.flash_on_outlined, size: 26),
                  activeIcon: Icon(Icons.flash_on, size: 28),
                  label: "Attack",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.tune_outlined, size: 26),
                  activeIcon: Icon(Icons.tune, size: 28),
                  label: "Tools",
                ),
              ],
              selectedLabelStyle: const TextStyle(fontFamily: "Orbitron", fontSize: 11),
              unselectedLabelStyle: const TextStyle(fontFamily: "Orbitron", fontSize: 11),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [deepBlue, cardBg],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: const BorderRadius.horizontal(right: Radius.circular(32)),
          border: Border.all(color: primaryCyan.withOpacity(0.2)),
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.horizontal(right: Radius.circular(32)),
          child: Column(
            children: [
              Container(
                height: 200,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      primaryCyan.withOpacity(0.2),
                      Colors.transparent,
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: primaryCyan, width: 2),
                        image: const DecorationImage(
                          image: NetworkImage('https://cdn.yupra.my.id/yp/s3m8hy4p.jpg'),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontFamily: "Orbitron",
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      role.toUpperCase(),
                      style: TextStyle(color: primaryCyan, fontSize: 12, fontFamily: "Orbitron"),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    _buildDrawerItem(
                      icon: Icons.home_outlined,
                      title: "Home",
                      onTap: () {
                        Navigator.pop(context);
                        setState(() {
                          _selectedIndex = 0;
                          _selectedPage = _buildDashboard();
                        });
                      },
                    ),
                    if (role == "reseller" || role == "owner")
                      _buildDrawerItem(
                        icon: Icons.person_add_outlined,
                        title: "Reseller",
                        onTap: () {
                          Navigator.pop(context);
                          setState(() {
                            _selectedPage = SellerPage(keyToken: sessionKey);
                          });
                        },
                      ),
                    if (role == "owner")
                      _buildDrawerItem(
                        icon: Icons.admin_panel_settings_outlined,
                        title: "Admin",
                        onTap: () {
                          Navigator.pop(context);
                          setState(() {
                            _selectedPage = AdminPage(sessionKey: sessionKey);
                          });
                        },
                      ),
                    _buildDrawerItem(
                      icon: Icons.phone_android_outlined,
                      title: "Senders",
                      onTap: () {
                        Navigator.pop(context);
                        setState(() {
                          _selectedPage = SenderPage(sessionKey: sessionKey);
                        });
                      },
                    ),
                    _buildDrawerItem(
                      icon: Icons.favorite_outline,
                      title: "Thank To",
                      onTap: () {
                        Navigator.pop(context);
                        setState(() {
                          _selectedPage = const ThanksToPage();
                        });
                      },
                    ),
                    const Divider(color: Colors.white12, height: 40),
                    _buildDrawerItem(
                      icon: Icons.lock_outline,
                      title: "Change Password",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ChangePasswordPage(
                              username: username,
                              sessionKey: sessionKey,
                            ),
                          ),
                        );
                      },
                    ),
                    _buildDrawerItem(
                      icon: Icons.logout_outlined,
                      title: "Logout",
                      color: Colors.redAccent,
                      onTap: () async {
                        final prefs = await SharedPreferences.getInstance();
                        await prefs.clear();
                        if (!mounted) return;
                        Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()),
                          (route) => false,
                        );
                      },
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  "Version 4.0.0",
                  style: TextStyle(color: Colors.white30, fontSize: 10, fontFamily: "ShareTechMono"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color color = Colors.white,
  }) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: color, size: 22),
      ),
      title: Text(
        title,
        style: TextStyle(
          color: color,
          fontFamily: "Orbitron",
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
      onTap: onTap,
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    channel.sink.close(status.goingAway);
    super.dispose();
  }
}