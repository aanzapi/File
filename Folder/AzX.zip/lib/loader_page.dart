//JANGAN LU MALING - UPGRADED VERSION
import 'report_wa.dart';
import 'thxto_page.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'dart:async';
import 'package:flutter/services.dart';

import 'telegram.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'sender_page.dart';

// ===== GLOBAL THEME COLORS - MUDAH DIGANTI =====
// Cukup ganti nilai-nilai di bawah ini untuk mengubah tema warna
class AppTheme {
  // Warna Utama
  static const Color primary = Color(0xFF6C5CE7);      // Ungu (bisa diganti)
  static const Color primaryLight = Color(0xFF8F7FEF); // Ungu Muda
  static const Color primaryDark = Color(0xFF4A3B9E);  // Ungu Tua
  
  // Warna Background
  static const Color background = Color(0xFF0A0A0A);   // Hitam Pekat
  static const Color surface = Color(0xFF1A1A1A);      // Hitam Lebih Terang
  static const Color surfaceLight = Color(0xFF2A2A2A); // Abu-abu Gelap
  
  // Warna Teks
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xFFB0B0B0);
  static const Color textMuted = Color(0xFF6B6B6B);
  
  // Warna Status
  static const Color success = Color(0xFF00C48C);
  static const Color warning = Color(0xFFFFB800);
  static const Color error = Color(0xFFFF4757);
  static const Color info = Color(0xFF3B9EFF);
  
  // Warna Border
  static const Color border = Color(0xFF2D2D2D);
  static const Color borderLight = Color(0xFF3D3D3D);
  
  // Opacity dan Effect
  static Color glassBg = const Color(0xFF1A1A1A).withOpacity(0.8);
  static Color glassBorder = Colors.white.withOpacity(0.1);
  static Color primaryWithOpacity(double opacity) => primary.withOpacity(opacity);
}

// Dark Andx Theme - Style seperti gambar
class DarkAndxStyle {
  // Gradient untuk background
  static LinearGradient backgroundGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      AppTheme.background,
      AppTheme.surface,
      AppTheme.background,
    ],
  );
  
  // Gradient untuk card
  static LinearGradient cardGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      AppTheme.surfaceLight.withOpacity(0.5),
      AppTheme.surface.withOpacity(0.5),
    ],
  );
  
  // Gradient untuk button
  static LinearGradient buttonGradient = LinearGradient(
    colors: [
      AppTheme.primary,
      AppTheme.primaryDark,
    ],
  );
  
  // Shadow untuk card
  static List<BoxShadow> cardShadow = [
    BoxShadow(
      color: AppTheme.primary.withOpacity(0.1),
      blurRadius: 20,
      spreadRadius: 0,
      offset: const Offset(0, 5),
    ),
  ];
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;
  late VideoPlayerController _bgController;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();

  final GlobalKey _bugButtonKey = GlobalKey();
  final PageController _pageController = PageController(viewportFraction: 0.85);
  int _currentNewsIndex = 0;

  Map<String, dynamic> _appUpdateInfo = {};
  bool _isLoadingUpdateInfo = false;
  bool _hasUpdateError = false;
  bool _showUpdateNotification = false;

  int _totalUsers = 0;
  bool _isLoadingTotalUsers = false;

  late AnimationController _drawerAnimationController;
  late Animation<double> _drawerAnimation;

  Timer? _bgTimer;

  // Status Online
  int _onlineUsers = 0;
  int _onlineSenders = 0;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _initBackgroundVideo();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _drawerAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _drawerAnimation = CurvedAnimation(
      parent: _drawerAnimationController,
      curve: Curves.easeInOut,
    );

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _fetchAppUpdateInfo();
    _fetchTotalUsers();

    _bgTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (_bgController.value.isInitialized && !_bgController.value.isPlaying) {
        _bgController.play();
      }
    });
  }

  Future<void> _initBackgroundVideo() async {
    _bgController = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        _bgController.setLooping(true);
        _bgController.setVolume(0);
        _bgController.play();
        if (mounted) setState(() {});
      }).catchError((error) {
        print('Error loading video: $error');
      });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('http://server.aanz-panel.web.id:2000'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      } else if (data['type'] == 'stats') {
        setState(() {
          _onlineUsers = data['onlineUsers'] ?? 0;
          _onlineSenders = data['onlineSenders'] ?? 0;
        });
      }
    });
  }

  Future<void> _fetchAppUpdateInfo() async {
    setState(() {
      _isLoadingUpdateInfo = true;
      _hasUpdateError = false;
    });

    try {
      final response = await http.get(
        Uri.parse('http://server.aanz-panel.web.id:2000/api/update/info'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _appUpdateInfo = Map<String, dynamic>.from(data['data']);
            _isLoadingUpdateInfo = false;
            _showUpdateNotification = true;
          });
          
          Future.delayed(Duration(seconds: 1), () {
            if (mounted && _showUpdateNotification) {
              _showUpdateNotificationDialog();
            }
          });
        } else {
          setState(() {
            _isLoadingUpdateInfo = false;
            _hasUpdateError = true;
          });
        }
      } else {
        setState(() {
          _isLoadingUpdateInfo = false;
          _hasUpdateError = true;
        });
      }
    } catch (e) {
      print('Error fetching app update info: $e');
      setState(() {
        _isLoadingUpdateInfo = false;
        _hasUpdateError = true;
      });
    }
  }

  void _showUpdateNotificationDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppTheme.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: AppTheme.border, width: 1),
          ),
          title: Row(
            children: [
              Icon(Icons.system_update, color: AppTheme.primary, size: 28),
              const SizedBox(width: 10),
              Text(
                "Update Available",
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontFamily: "Orbitron",
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3), width: 0.5),
                ),
                child: Row(
                  children: [
                    Icon(Icons.new_releases, color: AppTheme.primary, size: 16),
                    const SizedBox(width: 8),
                    Text(
                      "Version ${_appUpdateInfo['version'] ?? '4.0.0'}",
                      style: TextStyle(
                        color: AppTheme.primary,
                        fontWeight: FontWeight.bold,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text(
                _appUpdateInfo['description'] ?? 'New update is available with latest features and improvements.',
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontFamily: "ShareTechMono",
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 12),
              ...(_appUpdateInfo['changelog'] as List? ?? []).take(3).map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("• ", style: TextStyle(color: AppTheme.primary)),
                    Expanded(
                      child: Text(
                        item.toString(),
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontFamily: "ShareTechMono",
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              )),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "Later",
                style: TextStyle(color: AppTheme.textSecondary, fontFamily: "ShareTechMono"),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                _copyDownloadLink();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primary.withOpacity(0.1),
                foregroundColor: AppTheme.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: BorderSide(color: AppTheme.primary.withOpacity(0.3)),
                ),
              ),
              child: Text(
                "Copy Link",
                style: TextStyle(fontFamily: "ShareTechMono", color: AppTheme.primary),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _fetchTotalUsers() async {
    if (_isLoadingTotalUsers) return;
    
    setState(() {
      _isLoadingTotalUsers = true;
    });

    try {
      final response = await http.get(
        Uri.parse('http://server.aanz-panel.web.id:2000/api/user/listUsers?key=$sessionKey'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _totalUsers = (data['users'] as List).length;
            _isLoadingTotalUsers = false;
          });
        } else {
          setState(() {
            _isLoadingTotalUsers = false;
          });
        }
      } else {
        setState(() {
          _isLoadingTotalUsers = false;
        });
      }
    } catch (e) {
      print('Error fetching total users: $e');
      setState(() {
        _isLoadingTotalUsers = false;
      });
    }
  }

  Future<void> _refreshUpdateInfo() async {
    await _fetchAppUpdateInfo();
    await _fetchTotalUsers();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: AppTheme.primary, size: 20),
              const SizedBox(width: 10),
              Text(
                "Dashboard refreshed!",
                style: TextStyle(fontFamily: "ShareTechMono", color: AppTheme.textPrimary),
              ),
            ],
          ),
          backgroundColor: AppTheme.surface,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: AppTheme.border),
          ),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _copyDownloadLink() async {
    String downloadUrl = _appUpdateInfo['downloadUrl'] ?? '';
    
    if (downloadUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Download link not available",
            style: TextStyle(fontFamily: "ShareTechMono", color: AppTheme.textPrimary),
          ),
          backgroundColor: AppTheme.surface,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: AppTheme.primary.withOpacity(0.3)),
          ),
        ),
      );
      return;
    }
    
    await Clipboard.setData(ClipboardData(text: downloadUrl));
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.check_circle, color: AppTheme.primary, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                "Download link copied! Paste in browser",
                style: TextStyle(fontFamily: "ShareTechMono", color: AppTheme.textPrimary),
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.surface,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: AppTheme.primary.withOpacity(0.3)),
        ),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: AppTheme.border, width: 1),
        ),
        title: const Text("⚠️ Session Expired", style: TextStyle(color: AppTheme.textPrimary, fontFamily: "Orbitron")),
        content: Text(message, style: const TextStyle(color: AppTheme.textSecondary, fontFamily: "ShareTechMono")),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            child: const Text("OK", style: TextStyle(color: AppTheme.primary)),
          ),
        ],
      ),
    );
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
      _controller.reset();
      _controller.forward();

      if (index == 0) {
        _selectedPage = _buildNewsPage();
        _refreshUpdateInfo();
      } 
      else if (index == 1) {
        if (!["vip", "owner"].contains(role.toLowerCase())) {
          _selectedPage = AttackPage(
            username: username,
            password: password,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          );
        } else {
          _showBugMenu();
        }
      } 
      else if (index == 2) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
        );
      }
    });
  }

  void _showBugMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 30),
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          color: AppTheme.surface,
          border: Border.all(
            color: AppTheme.border,
            width: 1,
          ),
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 50,
                  height: 5,
                  decoration: BoxDecoration(
                    color: AppTheme.border,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  "SELECT ATTACK TYPE",
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 18,
                    fontFamily: "Orbitron",
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 22),
                _attackItem(
                  icon: Icons.person_add_alt_1,
                  title: "Bug Contact",
                  subtitle: "Target personal phone number",
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _selectedPage = AttackPage(
                        username: username,
                        password: password,
                        listBug: listBug,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey,
                      );
                    });
                  },
                ),
                _attackItem(
                  icon: Icons.auto_fix_high,
                  title: "Custom Bug",
                  subtitle: "Advanced payload customization",
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _selectedPage = CustomAttackPage(
                        username: username,
                        password: password,
                        listPayload: listPayload,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey,
                      );
                    });
                  },
                ),
                _attackItem(
                  icon: Icons.report_problem,
                  title: "Report Whatsapp",
                  subtitle: "Report accounts to WhatsApp",
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _selectedPage = const ReportWaPage(
                        sessionKey: "data",
                        role: "user",
                      );
                    });
                  },
                ),
                _attackItem(
                  icon: Icons.groups,
                  title: "Bug Group",
                  subtitle: "Massive attack via group links",
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _selectedPage = GroupBugPage(
                        username: username,
                        password: password,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey,
                      );
                    });
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _attackItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: AppTheme.glassBg,
            border: Border.all(
              color: AppTheme.glassBorder,
              width: 1,
            ),
            boxShadow: DarkAndxStyle.cardShadow,
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: AppTheme.primary.withOpacity(0.1),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Icon(
                  icon,
                  color: AppTheme.primary,
                  size: 26,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 16,
                        fontFamily: "Orbitron",
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.6,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right, color: AppTheme.textMuted),
            ],
          ),
        ),
      ),
    );
  }

  void _selectFromDrawer(String page) {
    Navigator.pop(context);
    setState(() {
      if (page == 'reseller') {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (page == 'admin') {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (page == 'sender') {
        _selectedPage = SenderPage(sessionKey: sessionKey);
      } else if (page == 'thanksto') {
        _selectedPage = const ThanksToPage();
      }
    });
  }

  Widget _buildNewsPage() {
    return Container(
      decoration: BoxDecoration(
        gradient: DarkAndxStyle.backgroundGradient,
      ),
      child: Stack(
        children: [
          // Background video (splash.mp4)
          if (_bgController.value.isInitialized)
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _bgController,
                builder: (context, child) {
                  return FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _bgController.value.size.width,
                      height: _bgController.value.size.height,
                      child: VideoPlayer(_bgController),
                    ),
                  );
                },
              ),
            ),
          // Dark overlay
          Positioned.fill(
            child: Container(
              color: AppTheme.background.withOpacity(0.85),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 2, sigmaY: 2),
                child: Container(color: Colors.transparent),
              ),
            ),
          ),
          RefreshIndicator(
            color: AppTheme.primary,
            backgroundColor: AppTheme.surface,
            onRefresh: _refreshUpdateInfo,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeaderSection(),
                  _buildServerStatus(),
                  _buildWelcomeSection(),
                  _buildStatsOverview(),
                  _buildNewsCarousel(),
                  _buildQuickActionsGrid(),
                  _buildAppUpdateInfo(),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: DarkAndxStyle.cardGradient,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.border, width: 1),
        boxShadow: DarkAndxStyle.cardShadow,
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Dark Andx",
                    style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 24,
                      fontFamily: "Orbitron",
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                  Text(
                    "PROJECT • NEW ENGINE",
                    style: TextStyle(
                      color: AppTheme.primary,
                      fontSize: 12,
                      fontFamily: "ShareTechMono",
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Text(
                  "4764-01-05",
                  style: TextStyle(
                    color: AppTheme.primary,
                    fontFamily: "ShareTechMono",
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildServerStatus() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: DarkAndxStyle.cardGradient,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.border, width: 1),
        boxShadow: DarkAndxStyle.cardShadow,
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatusItem(
                label: "Online Users",
                value: _onlineUsers.toString(),
                icon: Icons.people,
              ),
              Container(
                height: 40,
                width: 1,
                color: AppTheme.border,
              ),
              _buildStatusItem(
                label: "Online Sender",
                value: _onlineSenders.toString(),
                icon: Icons.phone_android,
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: AppTheme.success.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppTheme.success.withOpacity(0.3)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.circle, color: AppTheme.success, size: 8),
                const SizedBox(width: 8),
                Text(
                  "Server Status • 99.9% Uptime",
                  style: TextStyle(
                    color: AppTheme.success,
                    fontFamily: "ShareTechMono",
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusItem({
    required String label,
    required String value,
    required IconData icon,
  }) {
    return Column(
      children: [
        Icon(icon, color: AppTheme.primary, size: 24),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: AppTheme.textSecondary,
            fontFamily: "ShareTechMono",
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: AppTheme.textPrimary,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontFamily: "Orbitron",
          ),
        ),
      ],
    );
  }

  Widget _buildStatsOverview() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              title: "TOTAL USERS",
              value: _isLoadingTotalUsers ? "..." : _totalUsers.toString(),
              icon: Icons.people,
              subtitle: "All registered accounts",
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              title: "ACTIVE BUGS",
              value: listBug.length.toString(),
              icon: Icons.bug_report,
              subtitle: "Available attack methods",
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required String subtitle,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: DarkAndxStyle.cardGradient,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppTheme.border,
          width: 1,
        ),
        boxShadow: DarkAndxStyle.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.primary.withOpacity(0.1),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Icon(icon, color: AppTheme.primary, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11,
                    fontFamily: "ShareTechMono",
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            value,
            style: TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 28,
              fontWeight: FontWeight.bold,
              fontFamily: "Orbitron",
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 10,
              fontFamily: "ShareTechMono",
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWelcomeSection() {
    bool isExpired = false;
    try {
      DateTime expDate = DateTime.parse(expiredDate);
      isExpired = expDate.isBefore(DateTime.now());
    } catch (e) {}

    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: DarkAndxStyle.cardGradient,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: AppTheme.border,
          width: 1,
        ),
        boxShadow: DarkAndxStyle.cardShadow,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    TweenAnimationBuilder(
                      duration: const Duration(milliseconds: 1000),
                      tween: Tween<double>(begin: 0.8, end: 1.0),
                      builder: (context, double value, child) {
                        return Transform.scale(
                          scale: value,
                          child: Container(
                            width: 64,
                            height: 64,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: AppTheme.primary.withOpacity(0.5),
                                width: 2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: AppTheme.primary.withOpacity(0.3),
                                  blurRadius: 25,
                                  spreadRadius: 4,
                                ),
                              ],
                              image: const DecorationImage(
                                image: NetworkImage(
                                  'https://cdn.yupra.my.id/yp/s3m8hy4p.jpg',
                                ),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                "DARK ANDX IS IMPOSSIBLE...",
                                style: TextStyle(
                                  color: AppTheme.primary,
                                  fontSize: 11,
                                  fontFamily: "ShareTechMono",
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Text(
                                "Welcome back,",
                                style: TextStyle(
                                  color: AppTheme.textSecondary,
                                  fontSize: 12,
                                  fontFamily: "ShareTechMono",
                                ),
                              ),
                              const SizedBox(width: 4),
                              Text(
                                username,
                                style: TextStyle(
                                  color: AppTheme.textPrimary,
                                  fontSize: 14,
                                  fontFamily: "Orbitron",
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppTheme.primary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: AppTheme.primary.withOpacity(0.5),
                                    width: 0.5,
                                  ),
                                ),
                                child: Text(
                                  "A Gacor Fast Bug",
                                  style: TextStyle(
                                    color: AppTheme.primary,
                                    fontSize: 8,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppTheme.warning.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: AppTheme.warning.withOpacity(0.5),
                                    width: 0.5,
                                  ),
                                ),
                                child: Text(
                                  "owner",
                                  style: TextStyle(
                                    color: AppTheme.warning,
                                    fontSize: 8,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 20),
                
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppTheme.border, width: 1),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildFeatureChip("High Quality"),
                      Container(width: 1, height: 20, color: AppTheme.border),
                      _buildFeatureChip("Server Stable"),
                      Container(width: 1, height: 20, color: AppTheme.border),
                      _buildFeatureChip("Damn Simple"),
                    ],
                  ),
                ),
                
                const SizedBox(height: 16),
                
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.shopping_cart, color: AppTheme.primary, size: 20),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          "./Dark Andx Project [ New Engine ]\nBuy Access Chat Me @andipmx",
                          style: TextStyle(
                            color: AppTheme.textSecondary,
                            fontFamily: "ShareTechMono",
                            fontSize: 12,
                            height: 1.5,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          gradient: DarkAndxStyle.buttonGradient,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          "BUY",
                          style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 16),
                
                Row(
                  children: [
                    Expanded(
                      child: _buildActionButton(
                        label: "Join Community",
                        icon: Icons.people,
                        onTap: () {},
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildActionButton(
                        label: "Manage Bug",
                        icon: Icons.bug_report,
                        onTap: () {},
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureChip(String text) {
    return Text(
      text,
      style: TextStyle(
        color: AppTheme.textSecondary,
        fontSize: 12,
        fontFamily: "ShareTechMono",
      ),
    );
  }

  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: AppTheme.surfaceLight,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.border),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppTheme.primary, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 12,
                fontFamily: "ShareTechMono",
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getGreetingMessage() {
    var hour = DateTime.now().hour;
    if (hour < 12) return "Good morning! Ready to attack? ☀️";
    if (hour < 17) return "Good afternoon! Target is waiting 🔥";
    if (hour < 20) return "Good evening! Let's crash some numbers 🌙";
    return "Late night? The best time to attack 💀";
  }

  Color _getRoleColor() {
    switch (role.toLowerCase()) {
      case 'owner':
        return AppTheme.warning;
      case 'vip':
        return AppTheme.primary;
      case 'reseller':
        return AppTheme.info;
      default:
        return AppTheme.textPrimary;
    }
  }

  String _formatExpiredDate(String date) {
    try {
      DateTime expDate = DateTime.parse(date);
      Duration diff = expDate.difference(DateTime.now());
      if (diff.inDays > 30) return "${expDate.day}/${expDate.month}/${expDate.year}";
      if (diff.inDays > 0) return "${diff.inDays} days left";
      if (diff.inHours > 0) return "${diff.inHours} hours left";
      if (diff.inMinutes > 0) return "${diff.inMinutes} minutes left";
      return "EXPIRED";
    } catch (e) {
      return date;
    }
  }

  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        height: 160,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: DarkAndxStyle.cardGradient,
          border: Border.all(color: AppTheme.border, width: 1),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.newspaper, color: AppTheme.textMuted, size: 40),
              const SizedBox(height: 10),
              Text(
                "No announcements",
                style: TextStyle(color: AppTheme.textSecondary, fontFamily: "ShareTechMono"),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "📢 LATEST NEWS",
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 14,
                  fontFamily: "Orbitron",
                  letterSpacing: 1,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Text(
                  "${_currentNewsIndex + 1}/${newsList.length}",
                  style: TextStyle(color: AppTheme.primary, fontSize: 10),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 200,
          child: PageView.builder(
            controller: _pageController,
            itemCount: newsList.length,
            onPageChanged: (index) {
              setState(() {
                _currentNewsIndex = index;
              });
            },
            itemBuilder: (context, index) {
              final item = newsList[index];
              return AnimatedContainer(
                duration: Duration(milliseconds: 300),
                margin: EdgeInsets.symmetric(
                  horizontal: _currentNewsIndex == index ? 8 : 12,
                  vertical: 10,
                ),
                child: TweenAnimationBuilder(
                  duration: Duration(milliseconds: 500),
                  tween: Tween<double>(begin: 0.9, end: 1.0),
                  builder: (context, double value, child) {
                    return Transform.scale(
                      scale: value,
                      child: child,
                    );
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      gradient: DarkAndxStyle.cardGradient,
                      border: Border.all(
                        color: _currentNewsIndex == index ? AppTheme.primary : AppTheme.border,
                        width: _currentNewsIndex == index ? 2 : 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _currentNewsIndex == index ? AppTheme.primary.withOpacity(0.2) : Colors.transparent,
                          blurRadius: 15,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          if (item['image'] != null && item['image'].toString().isNotEmpty)
                            NewsMedia(url: item['image']),
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  AppTheme.background.withOpacity(0.8),
                                  Colors.transparent,
                                  AppTheme.background.withOpacity(0.5),
                                ],
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: 16,
                            left: 16,
                            right: 16,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item['title'] ?? 'No Title',
                                  style: TextStyle(
                                    color: AppTheme.textPrimary,
                                    fontSize: 18,
                                    fontFamily: "Orbitron",
                                    fontWeight: FontWeight.bold,
                                    shadows: [
                                      Shadow(
                                        color: AppTheme.background,
                                        blurRadius: 10,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  item['desc'] ?? '',
                                  style: TextStyle(
                                    color: AppTheme.textSecondary,
                                    fontFamily: "ShareTechMono",
                                    fontSize: 12,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                          if (_currentNewsIndex == index)
                            Positioned(
                              top: 10,
                              right: 10,
                              child: Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: AppTheme.primary.withOpacity(0.1),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: AppTheme.primary),
                                ),
                                child: Icon(Icons.circle, color: AppTheme.primary, size: 8),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget _buildQuickActionsGrid() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "⚡ QUICK ACTIONS",
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 14,
                  fontFamily: "Orbitron",
                  letterSpacing: 1,
                ),
              ),
              Icon(Icons.flash_on, color: AppTheme.primary, size: 20),
            ],
          ),
          const SizedBox(height: 15),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
            childAspectRatio: 1.2,
            children: [
              _buildActionCard(
                icon: FontAwesomeIcons.telegram,
                title: "TELEGRAM",
                subtitle: "Join channel",
                onTap: () async {
                  final uri = Uri.parse("tg://resolve?domain=ZYxxx80");
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  } else {
                    await launchUrl(Uri.parse("https://t.me/aanchannell"),
                        mode: LaunchMode.externalApplication);
                  }
                },
              ),
              _buildActionCard(
                icon: Icons.phone_android,
                title: "SENDERS",
                subtitle: "Manage devices",
                onTap: () {
                  setState(() {
                    _selectedPage = SenderPage(sessionKey: sessionKey);
                  });
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(26),
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: DarkAndxStyle.cardGradient,
          border: Border.all(
            color: AppTheme.border,
            width: 1,
          ),
          boxShadow: DarkAndxStyle.cardShadow,
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 45,
                height: 45,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.primary.withOpacity(0.1),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3), width: 1),
                ),
                child: Icon(
                  icon,
                  color: AppTheme.primary,
                  size: 22,
                ),
              ),
              const Spacer(),
              Text(
                title,
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Orbitron",
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 11,
                  fontFamily: "ShareTechMono",
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppUpdateInfo() {
    String downloadUrl = _appUpdateInfo['downloadUrl'] ?? '';
    bool hasUpdate = _appUpdateInfo.isNotEmpty;
    
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Text(
                    "📱 APP UPDATE",
                    style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 14,
                      fontFamily: "Orbitron",
                      letterSpacing: 1,
                    ),
                  ),
                  if (hasUpdate && !_isLoadingUpdateInfo)
                    Container(
                      margin: const EdgeInsets.only(left: 10),
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppTheme.primary.withOpacity(0.5)),
                      ),
                      child: Text(
                        "NEW",
                        style: TextStyle(
                          color: AppTheme.primary,
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                ],
              ),
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.refresh, color: AppTheme.textSecondary, size: 20),
                    onPressed: _refreshUpdateInfo,
                    tooltip: "Refresh",
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      gradient: DarkAndxStyle.cardGradient,
                      border: Border.all(color: AppTheme.border),
                    ),
                    child: Text(
                      "v${_appUpdateInfo['version'] ?? '4.0.0'}",
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 15),
          
          if (_isLoadingUpdateInfo)
            Container(
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: DarkAndxStyle.cardGradient,
                border: Border.all(color: AppTheme.border, width: 1),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(color: AppTheme.primary),
                    const SizedBox(height: 16),
                    Text(
                      "Checking for updates...",
                      style: TextStyle(color: AppTheme.textSecondary, fontFamily: "ShareTechMono"),
                    ),
                  ],
                ),
              ),
            )
          else if (_hasUpdateError)
            Container(
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: DarkAndxStyle.cardGradient,
                border: Border.all(color: AppTheme.border, width: 1),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, color: AppTheme.error, size: 48),
                    const SizedBox(height: 10),
                    Text(
                      "Failed to check updates",
                      style: TextStyle(color: AppTheme.textSecondary, fontSize: 14),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _refreshUpdateInfo,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        foregroundColor: AppTheme.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                          side: BorderSide(color: AppTheme.primary.withOpacity(0.3)),
                        ),
                      ),
                      child: const Text("Try Again"),
                    ),
                  ],
                ),
              ),
            )
          else
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: DarkAndxStyle.cardGradient,
                border: Border.all(
                  color: downloadUrl.isNotEmpty ? AppTheme.primary.withOpacity(0.3) : AppTheme.border,
                  width: 1,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppTheme.primary.withOpacity(0.1),
                            border: Border.all(color: AppTheme.primary.withOpacity(0.3), width: 1),
                          ),
                          child: Icon(
                            Icons.system_update_alt,
                            color: AppTheme.primary,
                            size: 24,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _appUpdateInfo['title'] ?? 'AzX Crasher V4',
                                style: TextStyle(
                                  color: AppTheme.textPrimary,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "Orbitron",
                                ),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Icon(Icons.calendar_today, size: 10, color: AppTheme.textMuted),
                                  const SizedBox(width: 4),
                                  Text(
                                    _appUpdateInfo['date'] ?? '2026-02-19',
                                    style: TextStyle(color: AppTheme.textSecondary, fontSize: 11),
                                  ),
                                  const SizedBox(width: 12),
                                  Icon(Icons.update, size: 10, color: AppTheme.textMuted),
                                  const SizedBox(width: 4),
                                  Text(
                                    "Latest",
                                    style: TextStyle(color: AppTheme.success, fontSize: 11),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 16),
                    
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: AppTheme.primary.withOpacity(0.05),
                        border: Border.all(color: AppTheme.primary.withOpacity(0.3), width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "What's New:",
                            style: TextStyle(
                              color: AppTheme.primary,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              fontFamily: "Orbitron",
                            ),
                          ),
                          const SizedBox(height: 10),
                          ...(_appUpdateInfo['changelog'] as List? ?? [
                            "✓ Performance improvements",
                            "✓ Bug fixes",
                            "✓ New attack methods",
                          ]).map((item) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(Icons.check_circle, color: AppTheme.primary, size: 14),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    item.toString(),
                                    style: TextStyle(
                                      color: AppTheme.textSecondary,
                                      fontSize: 12,
                                      fontFamily: "ShareTechMono",
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 20),
                    
                    if (_appUpdateInfo['isRequired'] == true)
                      Container(
                        margin: const EdgeInsets.only(bottom: 16),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppTheme.error.withOpacity(0.1),
                          border: Border.all(color: AppTheme.error.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.warning, color: AppTheme.error, size: 20),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                "This update is required to continue using the app",
                                style: TextStyle(color: AppTheme.error, fontSize: 12),
                              ),
                            ),
                          ],
                        ),
                      ),
                    
                    if (downloadUrl.isNotEmpty)
                      InkWell(
                        onTap: _copyDownloadLink,
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            gradient: DarkAndxStyle.buttonGradient,
                            border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                            boxShadow: DarkAndxStyle.cardShadow,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.copy, color: AppTheme.textPrimary, size: 20),
                              const SizedBox(width: 10),
                              Text(
                                "COPY DOWNLOAD LINK",
                                style: TextStyle(
                                  color: AppTheme.textPrimary,
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "Orbitron",
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildEnhancedInfoCard({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: DarkAndxStyle.cardGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.border,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppTheme.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
            ),
            child: Icon(icon, color: AppTheme.primary, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                    fontFamily: "ShareTechMono",
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGreyButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: DarkAndxStyle.cardGradient,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.border),
        boxShadow: DarkAndxStyle.cardShadow,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onPressed,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: AppTheme.primary, size: 18),
                const SizedBox(width: 8),
                Text(
                  label,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogo({double height = 40}) {
    return Image.asset(
      'assets/images/title.png',
      height: height,
      fit: BoxFit.contain,
    );
  }

  List<BottomNavigationBarItem> _buildBottomNavBarItems() {
    return [
      const BottomNavigationBarItem(
        icon: Icon(Icons.explore_outlined, size: 26),
        activeIcon: Icon(Icons.explore, size: 28),
        label: "Home",
      ),
      BottomNavigationBarItem(
        key: _bugButtonKey,
        icon: const Icon(Icons.extension_outlined, size: 26),
        activeIcon: const Icon(Icons.extension, size: 28),
        label: "Bug",
      ),
      const BottomNavigationBarItem(
        icon: Icon(Icons.tune_outlined, size: 26),
        activeIcon: Icon(Icons.tune, size: 28),
        label: "Tools",
      ),
    ];
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.surface,
          border: Border(
            right: BorderSide(color: AppTheme.border, width: 1),
          ),
        ),
        child: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: ListView(
              padding: const EdgeInsets.all(0),
              children: [
                Container(
                  height: 200,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppTheme.primary.withOpacity(0.1),
                        Colors.transparent,
                        AppTheme.surface,
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: Opacity(
                          opacity: 0.1,
                          child: Icon(
                            Icons.grid_on,
                            size: 200,
                            color: AppTheme.primary,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            _buildLogo(height: 35),
                            const SizedBox(height: 15),
                            Row(
                              children: [
                                TweenAnimationBuilder(
                                  duration: const Duration(milliseconds: 1000),
                                  tween: Tween<double>(begin: 0.8, end: 1.0),
                                  builder: (context, double value, child) {
                                    return Transform.scale(
                                      scale: value,
                                      child: Container(
                                        width: 50,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                            color: AppTheme.primary.withOpacity(0.5),
                                            width: 2,
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: AppTheme.primary.withOpacity(0.3),
                                              blurRadius: 15,
                                              spreadRadius: 2,
                                            ),
                                          ],
                                          image: const DecorationImage(
                                            image: NetworkImage(
                                              'https://cdn.yupra.my.id/yp/s3m8hy4p.jpg',
                                            ),
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        username,
                                        style: TextStyle(
                                          color: AppTheme.textPrimary,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: "Orbitron",
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                          vertical: 3,
                                        ),
                                        decoration: BoxDecoration(
                                          color: AppTheme.primary.withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(12),
                                          border: Border.all(
                                            color: AppTheme.primary.withOpacity(0.5),
                                            width: 0.5,
                                          ),
                                        ),
                                        child: Text(
                                          role.toUpperCase(),
                                          style: TextStyle(
                                            color: AppTheme.primary,
                                            fontSize: 10,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Text(
                    "ACCOUNT INFORMATION",
                    style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 12,
                      fontFamily: "ShareTechMono",
                      letterSpacing: 1,
                    ),
                  ),
                ),
                _buildEnhancedInfoCard(
                  icon: Icons.person_outline,
                  label: "Username",
                  value: username,
                ),
                _buildEnhancedInfoCard(
                  icon: Icons.admin_panel_settings,
                  label: "Role",
                  value: role.toUpperCase(),
                ),
                _buildEnhancedInfoCard(
                  icon: Icons.calendar_today,
                  label: "Expired Date",
                  value: expiredDate,
                ),
                _buildEnhancedInfoCard(
                  icon: Icons.devices,
                  label: "Device ID",
                  value: androidId.length > 20 ? '${androidId.substring(0, 20)}...' : androidId,
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildGreyButton(
                          icon: Icons.lock_reset,
                          label: "Password",
                          onPressed: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChangePasswordPage(
                                  username: username,
                                  sessionKey: sessionKey,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _buildGreyButton(
                          icon: Icons.logout,
                          label: "Logout",
                          onPressed: () async {
                            final prefs = await SharedPreferences.getInstance();
                            await prefs.clear();
                            if (!mounted) return;
                            Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(builder: (_) => const LoginPage()),
                              (route) => false,
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                ..._buildDrawerMenuItems(),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Divider(color: AppTheme.border, height: 1),
                      const SizedBox(height: 15),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildDrawerSocialIcon(
                            icon: FontAwesomeIcons.telegram,
                            onTap: () async {
                              await launchUrl(
                                Uri.parse("https://t.me/aanchannell"),
                                mode: LaunchMode.externalApplication,
                              );
                            },
                          ),
                          _buildDrawerSocialIcon(
                            icon: FontAwesomeIcons.github,
                            onTap: () {},
                          ),
                          _buildDrawerSocialIcon(
                            icon: FontAwesomeIcons.discord,
                            onTap: () {},
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        "Version 4.0.0",
                        style: TextStyle(
                          color: AppTheme.textMuted,
                          fontSize: 10,
                          fontFamily: "ShareTechMono",
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildDrawerMenuItems() {
    List<Map<String, dynamic>> menuItems = [];

    menuItems.add({
      'icon': Icons.home,
      'title': 'Home',
      'page': 'home',
      'show': true,
    });

    if (role == "reseller" || role == "owner") {
      menuItems.add({
        'icon': Icons.person_add,
        'title': 'Reseller Page',
        'page': 'reseller',
        'show': true,
      });
    }

    if (role == "owner") {
      menuItems.add({
        'icon': Icons.settings,
        'title': 'Admin Page',
        'page': 'admin',
        'show': true,
      });
    }

    menuItems.addAll([
      {
        'icon': Icons.phone_android,
        'title': 'Sender Management',
        'page': 'sender',
        'show': true,
      },
      {
        'icon': Icons.favorite,
        'title': 'Thank To',
        'page': 'thanksto',
        'show': true,
      },
      {
        'icon': Icons.info,
        'title': 'About',
        'page': 'about',
        'show': true,
      },
    ]);

    return menuItems.asMap().entries.map((entry) {
      int index = entry.key;
      var item = entry.value;
      
      if (!item['show']) return const SizedBox.shrink();

      return TweenAnimationBuilder(
        duration: Duration(milliseconds: 300 + (index * 50)),
        tween: Tween<double>(begin: 0.0, end: 1.0),
        builder: (context, double value, child) {
          return Opacity(
            opacity: value,
            child: Transform.translate(
              offset: Offset(20 * (1 - value), 0),
              child: child,
            ),
          );
        },
        child: _drawerMenuItem(
          icon: item['icon'],
          title: item['title'],
          onTap: () {
            if (item['page'] == 'home') {
              Navigator.pop(context);
              setState(() {
                _selectedIndex = 0;
                _selectedPage = _buildNewsPage();
              });
            } else {
              _selectFromDrawer(item['page']);
            }
          },
        ),
      );
    }).toList();
  }

  Widget _drawerMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: DarkAndxStyle.cardGradient,
            border: Border.all(
              color: AppTheme.border,
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: AppTheme.primary.withOpacity(0.1),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Icon(icon, color: AppTheme.primary, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 14,
                    fontFamily: "Orbitron",
                    letterSpacing: 0.6,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.primary.withOpacity(0.1),
                ),
                child: Icon(
                  Icons.chevron_right,
                  color: AppTheme.primary,
                  size: 16,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerSocialIcon({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: DarkAndxStyle.cardGradient,
          border: Border.all(
            color: AppTheme.border,
            width: 1,
          ),
        ),
        child: Icon(
          icon,
          color: AppTheme.primary,
          size: 18,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_selectedIndex != 0) {
          setState(() {
            _selectedIndex = 0;
            _selectedPage = _buildNewsPage();
          });
          return false;
        }
        return true;
      },
      child: Scaffold(
        extendBody: true,
        backgroundColor: AppTheme.background,
        appBar: AppBar(
          title: _buildLogo(height: 40),
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppTheme.background.withOpacity(0.5),
                  AppTheme.background.withOpacity(0.3),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              border: Border(
                bottom: BorderSide(color: AppTheme.border, width: 1),
              ),
            ),
            child: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(),
              ),
            ),
          ),
          actions: [
            Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(right: 16),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppTheme.primary.withOpacity(0.5),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.primary.withOpacity(0.3),
                        blurRadius: 10,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: CircleAvatar(
                    radius: 18,
                    backgroundImage: const NetworkImage(
                      'https://cdn.yupra.my.id/yp/s3m8hy4p.jpg',
                    ),
                    backgroundColor: AppTheme.glassBg,
                  ),
                ),
                Positioned(
                  right: 16,
                  bottom: 0,
                  child: Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppTheme.success,
                      border: Border.all(
                        color: AppTheme.background,
                        width: 2,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        drawer: _buildDrawer(),
        body: Container(
          color: AppTheme.background,
          child: SafeArea(
            child: FadeTransition(
              opacity: _animation,
              child: _selectedPage,
            ),
          ),
        ),
        bottomNavigationBar: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            gradient: DarkAndxStyle.cardGradient,
            border: Border.all(
              color: AppTheme.border,
              width: 1,
            ),
            boxShadow: DarkAndxStyle.cardShadow,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: BottomNavigationBar(
                backgroundColor: Colors.transparent,
                selectedItemColor: AppTheme.primary,
                unselectedItemColor: AppTheme.textMuted,
                currentIndex: _selectedIndex,
                onTap: _onTabSelected,
                type: BottomNavigationBarType.fixed,
                elevation: 0,
                items: _buildBottomNavBarItems(),
                selectedLabelStyle: const TextStyle(fontFamily: "ShareTechMono"),
                unselectedLabelStyle: const TextStyle(fontFamily: "ShareTechMono"),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _pageController.dispose();
    _bgController.dispose();
    _drawerAnimationController.dispose();
    _bgTimer?.cancel();
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0);
          _controller?.play();
        }).catchError((error) {
          print('Error loading video news: $error');
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _controller!.value.size.width,
            height: _controller!.value.size.height,
            child: VideoPlayer(_controller!),
          ),
        );
      } else {
        return Container(
          color: AppTheme.glassBg,
          child: Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primary),
            ),
          ),
        );
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: AppTheme.glassBg,
          child: Center(
            child: Icon(
              Icons.broken_image,
              color: AppTheme.primary,
              size: 40,
            ),
          ),
        ),
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Container(
            color: AppTheme.glassBg,
            child: Center(
              child: CircularProgressIndicator(
                value: loadingProgress.expectedTotalBytes != null
                    ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                    : null,
                valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primary),
              ),
            ),
          );
        },
      );
    }
  }
}