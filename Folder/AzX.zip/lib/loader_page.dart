//JANGAN LU MALING - UPGRADED VERSION
import 'report_wa.dart';
import 'thxto_page.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'dart:async';
import 'package:flutter/services.dart';

import 'telegram.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'sender_page.dart';

// ===== GLOBAL THEME COLORS - MUDAH DIGANTI =====
// Cukup ganti nilai di bawah ini untuk mengubah tema
class AppTheme {
  // Warna Utama - Default: Merah seperti gambar
  static Color primary = const Color(0xFFFF0000);      // Merah
  static Color primaryLight = const Color(0xFFFF3333); // Merah Muda
  static Color primaryDark = const Color(0xFFCC0000);  // Merah Tua
  
  // Warna Background
  static Color background = const Color(0xFF000000);   // Hitam Pekat
  static Color surface = const Color(0xFF0A0A0A);      // Hitam Sedikit Terang
  static Color surfaceLight = const Color(0xFF1A1A1A); // Abu-abu Gelap
  
  // Warna Teks
  static Color textPrimary = Colors.white;
  static Color textSecondary = const Color(0xFF9CA3AF); // Abu-abu
  static Color textMuted = const Color(0xFF6B7280);     // Abu-abu Gelap
  
  // Warna Status
  static Color success = const Color(0xFF10B981);
  static Color warning = const Color(0xFFFFB800);
  static Color error = const Color(0xFFFF0000);
  static Color info = const Color(0xFF3B82F6);
  
  // Warna Border
  static Color border = Colors.white.withOpacity(0.1);
  static Color borderLight = Colors.white.withOpacity(0.2);
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;
  late VideoPlayerController _bgController;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();

  final GlobalKey _bugButtonKey = GlobalKey();
  final PageController _pageController = PageController(viewportFraction: 0.85);
  int _currentNewsIndex = 0;

  Map<String, dynamic> _appUpdateInfo = {};
  bool _isLoadingUpdateInfo = false;
  bool _hasUpdateError = false;
  bool _showUpdateNotification = false;

  int _totalUsers = 0;
  bool _isLoadingTotalUsers = false;

  late AnimationController _drawerAnimationController;
  late Animation<double> _drawerAnimation;

  Timer? _bgTimer;

  // Status Online
  int _onlineUsers = 0;
  int _onlineSenders = 0;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _initBackgroundVideo();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _drawerAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _drawerAnimation = CurvedAnimation(
      parent: _drawerAnimationController,
      curve: Curves.easeInOut,
    );

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _fetchAppUpdateInfo();
    _fetchTotalUsers();

    _bgTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (_bgController.value.isInitialized && !_bgController.value.isPlaying) {
        _bgController.play();
      }
    });
  }

  Future<void> _initBackgroundVideo() async {
    _bgController = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        _bgController.setLooping(true);
        _bgController.setVolume(0);
        _bgController.play();
        if (mounted) setState(() {});
      }).catchError((error) {
        print('Error loading video: $error');
      });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('http://server.aanz-panel.web.id:2000'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      } else if (data['type'] == 'stats') {
        setState(() {
          _onlineUsers = data['onlineUsers'] ?? 0;
          _onlineSenders = data['onlineSenders'] ?? 0;
        });
      }
    });
  }

  Future<void> _fetchAppUpdateInfo() async {
    setState(() {
      _isLoadingUpdateInfo = true;
      _hasUpdateError = false;
    });

    try {
      final response = await http.get(
        Uri.parse('http://server.aanz-panel.web.id:2000/api/update/info'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _appUpdateInfo = Map<String, dynamic>.from(data['data']);
            _isLoadingUpdateInfo = false;
            _showUpdateNotification = true;
          });
          
          Future.delayed(const Duration(seconds: 1), () {
            if (mounted && _showUpdateNotification) {
              _showUpdateNotificationDialog();
            }
          });
        } else {
          setState(() {
            _isLoadingUpdateInfo = false;
            _hasUpdateError = true;
          });
        }
      } else {
        setState(() {
          _isLoadingUpdateInfo = false;
          _hasUpdateError = true;
        });
      }
    } catch (e) {
      print('Error fetching app update info: $e');
      setState(() {
        _isLoadingUpdateInfo = false;
        _hasUpdateError = true;
      });
    }
  }

  void _showUpdateNotificationDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppTheme.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: AppTheme.border, width: 1),
          ),
          title: Row(
            children: [
              Icon(Icons.system_update, color: AppTheme.primary, size: 28),
              const SizedBox(width: 10),
              Text(
                "Update Available",
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: "Orbitron",
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3), width: 0.5),
                ),
                child: Row(
                  children: [
                    Icon(Icons.new_releases, color: AppTheme.primary, size: 16),
                    const SizedBox(width: 8),
                    Text(
                      "Version ${_appUpdateInfo['version'] ?? '4.0.0'}",
                      style: TextStyle(
                        color: AppTheme.primary,
                        fontWeight: FontWeight.bold,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text(
                _appUpdateInfo['description'] ?? 'New update is available with latest features and improvements.',
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontFamily: "ShareTechMono",
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 12),
              ...(_appUpdateInfo['changelog'] as List? ?? []).take(3).map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("• ", style: TextStyle(color: AppTheme.primary)),
                    Expanded(
                      child: Text(
                        item.toString(),
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontFamily: "ShareTechMono",
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              )),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "Later",
                style: TextStyle(color: AppTheme.textSecondary, fontFamily: "ShareTechMono"),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                _copyDownloadLink();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primary.withOpacity(0.1),
                foregroundColor: AppTheme.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: BorderSide(color: AppTheme.primary.withOpacity(0.3)),
                ),
              ),
              child: Text(
                "Copy Link",
                style: TextStyle(fontFamily: "ShareTechMono", color: AppTheme.primary),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _fetchTotalUsers() async {
    if (_isLoadingTotalUsers) return;
    
    setState(() {
      _isLoadingTotalUsers = true;
    });

    try {
      final response = await http.get(
        Uri.parse('http://server.aanz-panel.web.id:2000/api/user/listUsers?key=$sessionKey'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _totalUsers = (data['users'] as List).length;
            _isLoadingTotalUsers = false;
          });
        } else {
          setState(() {
            _isLoadingTotalUsers = false;
          });
        }
      } else {
        setState(() {
          _isLoadingTotalUsers = false;
        });
      }
    } catch (e) {
      print('Error fetching total users: $e');
      setState(() {
        _isLoadingTotalUsers = false;
      });
    }
  }

  Future<void> _refreshUpdateInfo() async {
    await _fetchAppUpdateInfo();
    await _fetchTotalUsers();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: AppTheme.primary, size: 20),
              const SizedBox(width: 10),
              Text(
                "Dashboard refreshed!",
                style: TextStyle(fontFamily: "ShareTechMono", color: AppTheme.textPrimary),
              ),
            ],
          ),
          backgroundColor: AppTheme.surface,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: AppTheme.border),
          ),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _copyDownloadLink() async {
    String downloadUrl = _appUpdateInfo['downloadUrl'] ?? '';
    
    if (downloadUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Download link not available",
            style: TextStyle(fontFamily: "ShareTechMono", color: AppTheme.textPrimary),
          ),
          backgroundColor: AppTheme.surface,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: AppTheme.primary.withOpacity(0.3)),
          ),
        ),
      );
      return;
    }
    
    await Clipboard.setData(ClipboardData(text: downloadUrl));
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.check_circle, color: AppTheme.primary, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                "Download link copied! Paste in browser",
                style: TextStyle(fontFamily: "ShareTechMono", color: AppTheme.textPrimary),
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.surface,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: AppTheme.primary.withOpacity(0.3)),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: AppTheme.border, width: 1),
        ),
        title: const Text("⚠️ Session Expired", style: TextStyle(color: Colors.white, fontFamily: "Orbitron")),
        content: Text(message, style: const TextStyle(color: Color(0xFF9CA3AF), fontFamily: "ShareTechMono")),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            child: Text("OK", style: TextStyle(color: AppTheme.primary)),
          ),
        ],
      ),
    );
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
      _controller.reset();
      _controller.forward();

      if (index == 0) {
        _selectedPage = _buildNewsPage();
        _refreshUpdateInfo();
      } 
      else if (index == 1) {
        if (!["vip", "owner"].contains(role.toLowerCase())) {
          _selectedPage = AttackPage(
            username: username,
            password: password,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          );
        } else {
          _showBugMenu();
        }
      } 
      else if (index == 2) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
        );
      }
    });
  }

  void _showBugMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 30),
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          color: AppTheme.surface,
          border: Border.all(
            color: AppTheme.border,
            width: 1,
          ),
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 50,
                  height: 5,
                  decoration: BoxDecoration(
                    color: AppTheme.border,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  "SELECT ATTACK TYPE",
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 18,
                    fontFamily: "Orbitron",
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 22),
                _attackItem(
                  icon: Icons.person_add_alt_1,
                  title: "Bug Contact",
                  subtitle: "Target personal phone number",
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _selectedPage = AttackPage(
                        username: username,
                        password: password,
                        listBug: listBug,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey,
                      );
                    });
                  },
                ),
                _attackItem(
                  icon: Icons.auto_fix_high,
                  title: "Custom Bug",
                  subtitle: "Advanced payload customization",
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _selectedPage = CustomAttackPage(
                        username: username,
                        password: password,
                        listPayload: listPayload,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey,
                      );
                    });
                  },
                ),
                _attackItem(
                  icon: Icons.report_problem,
                  title: "Report Whatsapp",
                  subtitle: "Report accounts to WhatsApp",
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _selectedPage = const ReportWaPage(
                        sessionKey: "data",
                        role: "user",
                      );
                    });
                  },
                ),
                _attackItem(
                  icon: Icons.groups,
                  title: "Bug Group",
                  subtitle: "Massive attack via group links",
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _selectedPage = GroupBugPage(
                        username: username,
                        password: password,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey,
                      );
                    });
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _attackItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: AppTheme.surfaceLight,
            border: Border.all(
              color: AppTheme.border,
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: AppTheme.primary.withOpacity(0.1),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Icon(
                  icon,
                  color: AppTheme.primary,
                  size: 26,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 16,
                        fontFamily: "Orbitron",
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.6,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right, color: AppTheme.textMuted),
            ],
          ),
        ),
      ),
    );
  }

  void _selectFromDrawer(String page) {
    Navigator.pop(context);
    setState(() {
      if (page == 'reseller') {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (page == 'admin') {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (page == 'sender') {
        _selectedPage = SenderPage(sessionKey: sessionKey);
      } else if (page == 'thanksto') {
        _selectedPage = const ThanksToPage();
      }
    });
  }

  Widget _buildNewsPage() {
    return Container(
      color: AppTheme.background,
      child: Stack(
        children: [
          // Background video (splash.mp4)
          if (_bgController.value.isInitialized)
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _bgController,
                builder: (context, child) {
                  return FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _bgController.value.size.width,
                      height: _bgController.value.size.height,
                      child: VideoPlayer(_bgController),
                    ),
                  );
                },
              ),
            ),
          // Dark overlay
          Positioned.fill(
            child: Container(
              color: AppTheme.background.withOpacity(0.95),
            ),
          ),
          RefreshIndicator(
            color: AppTheme.primary,
            backgroundColor: AppTheme.surface,
            onRefresh: _refreshUpdateInfo,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),
                  _buildHeaderSection(),
                  const SizedBox(height: 20),
                  _buildServerStatus(),
                  const SizedBox(height: 20),
                  _buildWelcomeSection(),
                  const SizedBox(height: 20),
                  _buildStatsOverview(),
                  const SizedBox(height: 20),
                  _buildNewsCarousel(),
                  const SizedBox(height: 20),
                  _buildQuickActionsGrid(),
                  const SizedBox(height: 20),
                  _buildAppUpdateInfo(),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Dark Andx",
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 24,
                  fontFamily: "Orbitron",
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  Text(
                    "PROJECT",
                    style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 12,
                      fontFamily: "ShareTechMono",
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 4,
                    height: 4,
                    decoration: BoxDecoration(
                      color: AppTheme.primary,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    "NEW ENGINE",
                    style: TextStyle(
                      color: AppTheme.primary,
                      fontSize: 12,
                      fontFamily: "ShareTechMono",
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppTheme.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
            ),
            child: Text(
              "4764-01-05",
              style: TextStyle(
                color: AppTheme.primary,
                fontFamily: "ShareTechMono",
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildServerStatus() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatusItem(
                label: "Online Users",
                value: _onlineUsers.toString(),
              ),
              Container(
                height: 30,
                width: 1,
                color: AppTheme.border,
              ),
              _buildStatusItem(
                label: "Online Sender",
                value: _onlineSenders.toString(),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: AppTheme.border, width: 0.5),
                bottom: BorderSide(color: AppTheme.border, width: 0.5),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Online",
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontFamily: "ShareTechMono",
                    fontSize: 12,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 4,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.success,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  "Server Status",
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontFamily: "ShareTechMono",
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "99.9% Uptime",
            style: TextStyle(
              color: AppTheme.primary,
              fontFamily: "Orbitron",
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusItem({
    required String label,
    required String value,
  }) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(
            color: AppTheme.textSecondary,
            fontFamily: "ShareTechMono",
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: AppTheme.textPrimary,
            fontSize: 24,
            fontWeight: FontWeight.bold,
            fontFamily: "Orbitron",
          ),
        ),
      ],
    );
  }

  Widget _buildStatsOverview() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              title: "TOTAL USERS",
              value: _isLoadingTotalUsers ? "..." : _totalUsers.toString(),
              icon: Icons.people,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              title: "ACTIVE BUGS",
              value: listBug.length.toString(),
              icon: Icons.bug_report,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.border,
          width: 0.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.primary.withOpacity(0.1),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Icon(icon, color: AppTheme.primary, size: 16),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            value,
            style: TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 28,
              fontWeight: FontWeight.bold,
              fontFamily: "Orbitron",
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWelcomeSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Dark Andx Is Impossible...",
            style: TextStyle(
              color: AppTheme.primary,
              fontSize: 16,
              fontFamily: "ShareTechMono",
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Text(
                "Welcome back,",
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 14,
                  fontFamily: "ShareTechMono",
                ),
              ),
              const SizedBox(width: 4),
              Text(
                username,
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 16,
                  fontFamily: "Orbitron",
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Text(
                  "A",
                  style: TextStyle(
                    color: AppTheme.primary,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Text(
                  "Gacor",
                  style: TextStyle(
                    color: AppTheme.primary,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Text(
                  "Fast Bug",
                  style: TextStyle(
                    color: AppTheme.primary,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.warning.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.warning.withOpacity(0.3)),
                ),
                child: Text(
                  "owner",
                  style: TextStyle(
                    color: AppTheme.warning,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: AppTheme.border, width: 0.5),
                bottom: BorderSide(color: AppTheme.border, width: 0.5),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(
                  "High Quality",
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                    fontFamily: "ShareTechMono",
                  ),
                ),
                Text(
                  "Server Stable",
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                    fontFamily: "ShareTechMono",
                  ),
                ),
                Text(
                  "Damn Simple",
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    "./Dark Andx Project [ New Engine ]\nBuy Access Chat Me @andipmx",
                    style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontFamily: "ShareTechMono",
                      fontSize: 12,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                  ),
                  child: Center(
                    child: Text(
                      "[ Join Community ]",
                      style: TextStyle(
                        color: AppTheme.primary,
                        fontSize: 12,
                        fontFamily: "ShareTechMono",
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                  ),
                  child: Center(
                    child: Text(
                      "[ Manage Bug ]",
                      style: TextStyle(
                        color: AppTheme.primary,
                        fontSize: 12,
                        fontFamily: "ShareTechMono",
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getGreetingMessage() {
    var hour = DateTime.now().hour;
    if (hour < 12) return "Good morning! Ready to attack? ☀️";
    if (hour < 17) return "Good afternoon! Target is waiting 🔥";
    if (hour < 20) return "Good evening! Let's crash some numbers 🌙";
    return "Late night? The best time to attack 💀";
  }

  Color _getRoleColor() {
    switch (role.toLowerCase()) {
      case 'owner':
        return AppTheme.warning;
      case 'vip':
        return AppTheme.primary;
      case 'reseller':
        return AppTheme.info;
      default:
        return AppTheme.textPrimary;
    }
  }

  String _formatExpiredDate(String date) {
    try {
      DateTime expDate = DateTime.parse(date);
      Duration diff = expDate.difference(DateTime.now());
      if (diff.inDays > 30) return "${expDate.day}/${expDate.month}/${expDate.year}";
      if (diff.inDays > 0) return "${diff.inDays} days left";
      if (diff.inHours > 0) return "${diff.inHours} hours left";
      if (diff.inMinutes > 0) return "${diff.inMinutes} minutes left";
      return "EXPIRED";
    } catch (e) {
      return date;
    }
  }

  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppTheme.surfaceLight.withOpacity(0.3),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.border, width: 0.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "LATEST NEWS",
              style: TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 14,
                fontFamily: "Orbitron",
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: Column(
                children: [
                  Icon(Icons.newspaper, color: AppTheme.textMuted, size: 40),
                  const SizedBox(height: 10),
                  Text(
                    "No announcements",
                    style: TextStyle(color: AppTheme.textSecondary, fontFamily: "ShareTechMono"),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "LATEST NEWS",
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 14,
                  fontFamily: "Orbitron",
                  fontWeight: FontWeight.bold,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Text(
                  "${_currentNewsIndex + 1}/${newsList.length}",
                  style: TextStyle(color: AppTheme.primary, fontSize: 10),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 180,
            child: PageView.builder(
              controller: _pageController,
              itemCount: newsList.length,
              onPageChanged: (index) {
                setState(() {
                  _currentNewsIndex = index;
                });
              },
              itemBuilder: (context, index) {
                final item = newsList[index];
                return Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: AppTheme.surface,
                    border: Border.all(
                      color: _currentNewsIndex == index ? AppTheme.primary : AppTheme.border,
                      width: _currentNewsIndex == index ? 1 : 0.5,
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        if (item['image'] != null && item['image'].toString().isNotEmpty)
                          NewsMedia(url: item['image']),
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                AppTheme.background.withOpacity(0.8),
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 16,
                          left: 16,
                          right: 16,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item['title'] ?? 'No Title',
                                style: TextStyle(
                                  color: AppTheme.textPrimary,
                                  fontSize: 16,
                                  fontFamily: "Orbitron",
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                item['desc'] ?? '',
                                style: TextStyle(
                                  color: AppTheme.textSecondary,
                                  fontFamily: "ShareTechMono",
                                  fontSize: 11,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionsGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "QUICK ACTIONS",
            style: TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 14,
              fontFamily: "Orbitron",
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildActionCard(
                  icon: FontAwesomeIcons.telegram,
                  title: "TELEGRAM",
                  subtitle: "Join channel",
                  onTap: () async {
                    final uri = Uri.parse("tg://resolve?domain=ZYxxx80");
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri, mode: LaunchMode.externalApplication);
                    } else {
                      await launchUrl(Uri.parse("https://t.me/aanchannell"),
                          mode: LaunchMode.externalApplication);
                    }
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildActionCard(
                  icon: Icons.phone_android,
                  title: "SENDERS",
                  subtitle: "Manage devices",
                  onTap: () {
                    setState(() {
                      _selectedPage = SenderPage(sessionKey: sessionKey);
                    });
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: AppTheme.surfaceLight.withOpacity(0.3),
          border: Border.all(
            color: AppTheme.border,
            width: 0.5,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.primary.withOpacity(0.1),
                border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
              ),
              child: Icon(
                icon,
                color: AppTheme.primary,
                size: 20,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: "Orbitron",
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 11,
                fontFamily: "ShareTechMono",
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppUpdateInfo() {
    String downloadUrl = _appUpdateInfo['downloadUrl'] ?? '';
    bool hasUpdate = _appUpdateInfo.isNotEmpty;
    
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "APP UPDATE",
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 14,
                  fontFamily: "Orbitron",
                  fontWeight: FontWeight.bold,
                ),
              ),
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.refresh, color: AppTheme.textSecondary, size: 18),
                    onPressed: _refreshUpdateInfo,
                    tooltip: "Refresh",
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: AppTheme.primary.withOpacity(0.1),
                      border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                    ),
                    child: Text(
                      "v${_appUpdateInfo['version'] ?? '4.0.0'}",
                      style: TextStyle(
                        color: AppTheme.primary,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          if (_isLoadingUpdateInfo)
            Container(
              height: 150,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: AppTheme.surfaceLight.withOpacity(0.3),
                border: Border.all(color: AppTheme.border, width: 0.5),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(color: AppTheme.primary),
                    const SizedBox(height: 16),
                    Text(
                      "Checking for updates...",
                      style: TextStyle(color: AppTheme.textSecondary, fontFamily: "ShareTechMono"),
                    ),
                  ],
                ),
              ),
            )
          else if (_hasUpdateError)
            Container(
              height: 150,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: AppTheme.surfaceLight.withOpacity(0.3),
                border: Border.all(color: AppTheme.border, width: 0.5),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, color: AppTheme.error, size: 40),
                    const SizedBox(height: 10),
                    Text(
                      "Failed to check updates",
                      style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: _refreshUpdateInfo,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        foregroundColor: AppTheme.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                          side: BorderSide(color: AppTheme.primary.withOpacity(0.3)),
                        ),
                      ),
                      child: const Text("Try Again", style: TextStyle(fontSize: 12)),
                    ),
                  ],
                ),
              ),
            )
          else if (hasUpdate)
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: AppTheme.surfaceLight.withOpacity(0.3),
                border: Border.all(
                  color: downloadUrl.isNotEmpty ? AppTheme.primary.withOpacity(0.3) : AppTheme.border,
                  width: 0.5,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppTheme.primary.withOpacity(0.1),
                            border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                          ),
                          child: Icon(
                            Icons.system_update_alt,
                            color: AppTheme.primary,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _appUpdateInfo['title'] ?? 'AzX Crasher V4',
                                style: TextStyle(
                                  color: AppTheme.textPrimary,
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "Orbitron",
                                ),
                              ),
                              Text(
                                _appUpdateInfo['date'] ?? '2026-02-19',
                                style: TextStyle(color: AppTheme.textSecondary, fontSize: 10),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 16),
                    
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: AppTheme.primary.withOpacity(0.05),
                        border: Border.all(color: AppTheme.primary.withOpacity(0.3), width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "What's New:",
                            style: TextStyle(
                              color: AppTheme.primary,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: "Orbitron",
                            ),
                          ),
                          const SizedBox(height: 8),
                          ...(_appUpdateInfo['changelog'] as List? ?? [
                            "✓ Performance improvements",
                            "✓ Bug fixes",
                            "✓ New attack methods",
                          ]).take(3).map((item) => Padding(
                            padding: const EdgeInsets.only(bottom: 4),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(Icons.check_circle, color: AppTheme.primary, size: 12),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    item.toString(),
                                    style: TextStyle(
                                      color: AppTheme.textSecondary,
                                      fontSize: 11,
                                      fontFamily: "ShareTechMono",
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )),
                        ],
                      ),
                    ),
                    
                    if (downloadUrl.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      InkWell(
                        onTap: _copyDownloadLink,
                        borderRadius: BorderRadius.circular(30),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: AppTheme.primary.withOpacity(0.1),
                            border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.copy, color: AppTheme.primary, size: 16),
                              const SizedBox(width: 8),
                              Text(
                                "COPY DOWNLOAD LINK",
                                style: TextStyle(
                                  color: AppTheme.primary,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "ShareTechMono",
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildEnhancedInfoCard({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12, horizontal: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.border,
          width: 0.5,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppTheme.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
            ),
            child: Icon(icon, color: AppTheme.primary, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11,
                    fontFamily: "ShareTechMono",
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGreyButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight.withOpacity(0.3),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: onPressed,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: AppTheme.primary, size: 14),
                const SizedBox(width: 6),
                Text(
                  label,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogo({double height = 40}) {
    return Image.asset(
      'assets/images/title.png',
      height: height,
      fit: BoxFit.contain,
    );
  }

  List<BottomNavigationBarItem> _buildBottomNavBarItems() {
    return [
      const BottomNavigationBarItem(
        icon: Icon(Icons.home_outlined, size: 24),
        activeIcon: Icon(Icons.home, size: 24),
        label: "Home",
      ),
      BottomNavigationBarItem(
        key: _bugButtonKey,
        icon: const Icon(Icons.bug_report_outlined, size: 24),
        activeIcon: const Icon(Icons.bug_report, size: 24),
        label: "Bug",
      ),
      const BottomNavigationBarItem(
        icon: Icon(Icons.settings_outlined, size: 24),
        activeIcon: Icon(Icons.settings, size: 24),
        label: "Tools",
      ),
    ];
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.surface,
          border: Border(
            right: BorderSide(color: AppTheme.border, width: 0.5),
          ),
        ),
        child: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: ListView(
              padding: const EdgeInsets.all(0),
              children: [
                Container(
                  height: 180,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: AppTheme.border, width: 0.5),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      _buildLogo(height: 30),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: AppTheme.primary.withOpacity(0.5),
                                width: 2,
                              ),
                              image: const DecorationImage(
                                image: NetworkImage(
                                  'https://cdn.yupra.my.id/yp/s3m8hy4p.jpg',
                                ),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  username,
                                  style: TextStyle(
                                    color: AppTheme.textPrimary,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: "Orbitron",
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: AppTheme.primary.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: AppTheme.primary.withOpacity(0.5),
                                      width: 0.5,
                                    ),
                                  ),
                                  child: Text(
                                    role.toUpperCase(),
                                    style: TextStyle(
                                      color: AppTheme.primary,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Text(
                    "ACCOUNT INFORMATION",
                    style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 11,
                      fontFamily: "ShareTechMono",
                    ),
                  ),
                ),
                _buildEnhancedInfoCard(
                  icon: Icons.person_outline,
                  label: "Username",
                  value: username,
                ),
                _buildEnhancedInfoCard(
                  icon: Icons.admin_panel_settings,
                  label: "Role",
                  value: role.toUpperCase(),
                ),
                _buildEnhancedInfoCard(
                  icon: Icons.calendar_today,
                  label: "Expired Date",
                  value: expiredDate,
                ),
                _buildEnhancedInfoCard(
                  icon: Icons.devices,
                  label: "Device ID",
                  value: androidId.length > 20 ? '${androidId.substring(0, 20)}...' : androidId,
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildGreyButton(
                          icon: Icons.lock_reset,
                          label: "Password",
                          onPressed: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChangePasswordPage(
                                  username: username,
                                  sessionKey: sessionKey,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _buildGreyButton(
                          icon: Icons.logout,
                          label: "Logout",
                          onPressed: () async {
                            final prefs = await SharedPreferences.getInstance();
                            await prefs.clear();
                            if (!mounted) return;
                            Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(builder: (_) => const LoginPage()),
                              (route) => false,
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                ..._buildDrawerMenuItems(),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Divider(color: AppTheme.border, height: 1),
                      const SizedBox(height: 15),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildDrawerSocialIcon(
                            icon: FontAwesomeIcons.telegram,
                            onTap: () async {
                              await launchUrl(
                                Uri.parse("https://t.me/aanchannell"),
                                mode: LaunchMode.externalApplication,
                              );
                            },
                          ),
                          _buildDrawerSocialIcon(
                            icon: FontAwesomeIcons.github,
                            onTap: () {},
                          ),
                          _buildDrawerSocialIcon(
                            icon: FontAwesomeIcons.discord,
                            onTap: () {},
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        "Version 4.0.0",
                        style: TextStyle(
                          color: AppTheme.textMuted,
                          fontSize: 10,
                          fontFamily: "ShareTechMono",
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildDrawerMenuItems() {
    List<Map<String, dynamic>> menuItems = [];

    menuItems.add({
      'icon': Icons.home,
      'title': 'Home',
      'page': 'home',
      'show': true,
    });

    if (role == "reseller" || role == "owner") {
      menuItems.add({
        'icon': Icons.person_add,
        'title': 'Reseller Page',
        'page': 'reseller',
        'show': true,
      });
    }

    if (role == "owner") {
      menuItems.add({
        'icon': Icons.settings,
        'title': 'Admin Page',
        'page': 'admin',
        'show': true,
      });
    }

    menuItems.addAll([
      {
        'icon': Icons.phone_android,
        'title': 'Sender Management',
        'page': 'sender',
        'show': true,
      },
      {
        'icon': Icons.favorite,
        'title': 'Thank To',
        'page': 'thanksto',
        'show': true,
      },
      {
        'icon': Icons.info,
        'title': 'About',
        'page': 'about',
        'show': true,
      },
    ]);

    return menuItems.asMap().entries.map((entry) {
      int index = entry.key;
      var item = entry.value;
      
      if (!item['show']) return const SizedBox.shrink();

      return _drawerMenuItem(
        icon: item['icon'],
        title: item['title'],
        onTap: () {
          if (item['page'] == 'home') {
            Navigator.pop(context);
            setState(() {
              _selectedIndex = 0;
              _selectedPage = _buildNewsPage();
            });
          } else {
            _selectFromDrawer(item['page']);
          }
        },
      );
    }).toList();
  }

  Widget _drawerMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: AppTheme.surfaceLight.withOpacity(0.3),
            border: Border.all(
              color: AppTheme.border,
              width: 0.5,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: AppTheme.primary.withOpacity(0.1),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
                ),
                child: Icon(icon, color: AppTheme.primary, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 13,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: AppTheme.textMuted,
                size: 16,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerSocialIcon({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AppTheme.surfaceLight.withOpacity(0.3),
          border: Border.all(
            color: AppTheme.border,
            width: 0.5,
          ),
        ),
        child: Icon(
          icon,
          color: AppTheme.primary,
          size: 16,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_selectedIndex != 0) {
          setState(() {
            _selectedIndex = 0;
            _selectedPage = _buildNewsPage();
          });
          return false;
        }
        return true;
      },
      child: Scaffold(
        extendBody: true,
        backgroundColor: AppTheme.background,
        appBar: AppBar(
          title: _buildLogo(height: 35),
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(color: AppTheme.border, width: 0.5),
              ),
            ),
          ),
          actions: [
            Container(
              margin: const EdgeInsets.only(right: 16),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppTheme.primary.withOpacity(0.5),
                  width: 1.5,
                ),
              ),
              child: CircleAvatar(
                radius: 16,
                backgroundImage: const NetworkImage(
                  'https://cdn.yupra.my.id/yp/s3m8hy4p.jpg',
                ),
                backgroundColor: AppTheme.surface,
              ),
            ),
          ],
        ),
        drawer: _buildDrawer(),
        body: Container(
          color: AppTheme.background,
          child: SafeArea(
            child: FadeTransition(
              opacity: _animation,
              child: _selectedPage,
            ),
          ),
        ),
        bottomNavigationBar: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: AppTheme.surface,
            border: Border.all(
              color: AppTheme.border,
              width: 0.5,
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
              child: BottomNavigationBar(
                backgroundColor: Colors.transparent,
                selectedItemColor: AppTheme.primary,
                unselectedItemColor: AppTheme.textMuted,
                currentIndex: _selectedIndex,
                onTap: _onTabSelected,
                type: BottomNavigationBarType.fixed,
                elevation: 0,
                items: _buildBottomNavBarItems(),
                selectedLabelStyle: const TextStyle(fontFamily: "ShareTechMono", fontSize: 11),
                unselectedLabelStyle: const TextStyle(fontFamily: "ShareTechMono", fontSize: 11),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _pageController.dispose();
    _bgController.dispose();
    _drawerAnimationController.dispose();
    _bgTimer?.cancel();
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0);
          _controller?.play();
        }).catchError((error) {
          print('Error loading video news: $error');
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _controller!.value.size.width,
            height: _controller!.value.size.height,
            child: VideoPlayer(_controller!),
          ),
        );
      } else {
        return Container(
          color: AppTheme.surface,
          child: Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primary),
            ),
          ),
        );
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: AppTheme.surface,
          child: Center(
            child: Icon(
              Icons.broken_image,
              color: AppTheme.primary,
              size: 30,
            ),
          ),
        ),
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Container(
            color: AppTheme.surface,
            child: Center(
              child: CircularProgressIndicator(
                value: loadingProgress.expectedTotalBytes != null
                    ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                    : null,
                valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primary),
              ),
            ),
          );
        },
      );
    }
  }
}