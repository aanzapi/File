//JANGAN LU MALING
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:ui';

// ===== GLOBAL THEME COLOR (Hitam Putih dengan aksen merah) =====
const Color primaryWhite = Colors.white;
const Color secondaryGrey = Color(0xFF9CA3AF);
const Color backgroundBlack = Color(0xFF000000);
const Color glassWhite = Color(0x0DFFFFFF);
const Color borderGrey = Color(0x1AFFFFFF);
const Color accentRed = Color(0xFFFF0000);
const Color subtleRed = Color(0x33FF0000);

class ReportWaPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const ReportWaPage({
    super.key, 
    required this.sessionKey, 
    required this.role
  });

  @override
  State<ReportWaPage> createState() => _ReportWaPageState();
}

class _ReportWaPageState extends State<ReportWaPage> {
  // --- CONTROLLERS ---
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final ScrollController _logScrollController = ScrollController();

  // --- STATE VARIABLES ---
  bool _isAttacking = false;
  List<String> _logs = [];
  Timer? _attackTimer;

  @override
  void dispose() {
    _targetController.dispose();
    _amountController.dispose();
    _logScrollController.dispose();
    _attackTimer?.cancel();
    super.dispose();
  }

  // --- LOGIKA SIMULASI (TETAP UTUH) ---
  void _toggleAttack() {
    if (_isAttacking) {
      _stopAttack();
    } else {
      if (_targetController.text.isEmpty || _amountController.text.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: backgroundBlack.withOpacity(0.95),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
              side: BorderSide(color: accentRed.withOpacity(0.3)),
            ),
            content: Text(
              "Target & Amount cannot be empty!", 
              style: TextStyle(
                fontWeight: FontWeight.w400,
                color: primaryWhite,
                letterSpacing: 0.5,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        );
        return;
      }
      _startAttack();
    }
  }

  void _startAttack() {
    setState(() {
      _isAttacking = true;
      _logs.clear();
      _logs.add("> SYSTEM v2.4.3 INITIALIZED");
      _logs.add("> TARGET: ${_targetController.text}");
      _logs.add("> ESTABLISHING SECURE CONNECTION...");
      _logs.add("> PROTOCOL: REPORT GENERATION");
      _logs.add("> STATUS: ACTIVE");
    });

    // Simulasi Logs dengan format terminal asli
    _attackTimer = Timer.periodic(const Duration(milliseconds: 250), (timer) {
      if (!mounted) return;

      final randomId = Random().nextInt(999999);
      final statusCode = Random().nextInt(3);
      String statusText;
      
      switch(statusCode) {
        case 0:
          statusText = "SUCCESS";
          break;
        case 1:
          statusText = "PENDING";
          break;
        default:
          statusText = "PROCESSING";
      }

      final timestamp = DateTime.now().toString().split(' ')[1].substring(0, 8);
      
      setState(() {
        _logs.add("[${timestamp}] [REQ-${randomId.toString().padLeft(6, '0')}] ${_targetController.text} >> STATUS: ${statusText}");
        
        // Auto Scroll ke bawah
        if (_logScrollController.hasClients) {
          _logScrollController.jumpTo(_logScrollController.position.maxScrollExtent);
        }
      });

      // Stop otomatis jika logs terlalu banyak
      if (_logs.length > 150) {
        _stopAttack();
      }
    });
  }

  void _stopAttack() {
    _attackTimer?.cancel();
    setState(() {
      _isAttacking = false;
      _logs.add("> PROCESS TERMINATED BY USER");
      _logs.add("> CONNECTION CLOSED");
      _logs.add("> SYSTEM STANDBY");
    });
  }

  // --- WIDGET BUILDER ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundBlack,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        flexibleSpace: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(color: glassWhite),
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          color: backgroundBlack,
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              backgroundBlack,
              backgroundBlack,
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              children: [
                // 1. INPUT SECTION
                _buildTerminalInputCard(),
                const SizedBox(height: 16),

                // 2. ACTION BUTTON
                _buildTerminalButton(),
                const SizedBox(height: 16),

                // 3. TERMINAL LOGS
                Expanded(child: _buildTerminalConsole()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTerminalInputCard() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: borderGrey,
          width: 1,
        ),
        color: glassWhite,
      ),
      child: Column(
        children: [
          // Terminal Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            color: subtleRed,
            child: Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accentRed.withOpacity(0.5),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accentRed.withOpacity(0.5),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accentRed.withOpacity(0.5),
                  ),
                ),
                const SizedBox(width: 16),
                Text(
                  "target_config.sh",
                  style: TextStyle(
                    color: primaryWhite,
                    fontSize: 13,
                    fontWeight: FontWeight.w300,
                    letterSpacing: 0.5,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
          
          // Input Fields
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildTerminalTextField(
                  controller: _targetController,
                  label: "TARGET_NUMBER",
                  hint: "628xxxxxxxx",
                  icon: Icons.phone_iphone_rounded,
                ),
                const SizedBox(height: 20),
                _buildTerminalTextField(
                  controller: _amountController,
                  label: "AMOUNT",
                  hint: "enter_integer",
                  icon: Icons.confirmation_number_rounded,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTerminalTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              "\$ ",
              style: TextStyle(
                color: accentRed,
                fontSize: 14,
                fontWeight: FontWeight.w400,
                fontFamily: 'ShareTechMono',
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: primaryWhite,
                fontSize: 13,
                fontWeight: FontWeight.w300,
                letterSpacing: 0.5,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            border: Border.all(
              color: borderGrey,
              width: 1,
            ),
            color: backgroundBlack,
          ),
          child: TextField(
            controller: controller,
            style: TextStyle(
              color: primaryWhite,
              fontSize: 14,
              fontWeight: FontWeight.w300,
              fontFamily: "monospace",
            ),
            cursorColor: accentRed,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(
                color: secondaryGrey.withOpacity(0.5),
                fontSize: 13,
                fontFamily: "monospace",
              ),
              prefixIcon: Icon(
                icon,
                color: accentRed,
                size: 18,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTerminalButton() {
    return GestureDetector(
      onTap: _toggleAttack,
      child: Container(
        width: double.infinity,
        height: 50,
        decoration: BoxDecoration(
          border: Border.all(
            color: _isAttacking ? accentRed : accentRed.withOpacity(0.5),
            width: 1,
          ),
          color: _isAttacking ? subtleRed : glassWhite,
        ),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _isAttacking ? accentRed : primaryWhite,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                _isAttacking ? "> TERMINATE PROCESS <" : "> EXECUTE COMMAND <",
                style: TextStyle(
                  color: _isAttacking ? accentRed : primaryWhite,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  letterSpacing: 1,
                  fontFamily: "monospace",
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTerminalConsole() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: borderGrey,
          width: 1,
        ),
        color: glassWhite,
      ),
      child: Column(
        children: [
          // Console Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            color: subtleRed,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Text(
                      "root@server:",
                      style: TextStyle(
                        color: accentRed,
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        fontFamily: "monospace",
                      ),
                    ),
                    Text(
                      " ~/logs",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 13,
                        fontWeight: FontWeight.w300,
                        fontFamily: "monospace",
                      ),
                    ),
                    Text(
                      " \$",
                      style: TextStyle(
                        color: accentRed,
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        fontFamily: "monospace",
                      ),
                    ),
                  ],
                ),
                if (_isAttacking)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: accentRed.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: accentRed,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "ACTIVE",
                          style: TextStyle(
                            color: accentRed,
                            fontSize: 10,
                            fontWeight: FontWeight.w400,
                            fontFamily: "monospace",
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),

          // Log Container
          Expanded(
            child: Container(
              color: backgroundBlack,
              padding: const EdgeInsets.all(16),
              child: _logs.isEmpty
                  ? Center(
                      child: Text(
                        "> system ready for input...\n> enter target and amount to begin",
                        style: TextStyle(
                          color: secondaryGrey.withOpacity(0.5),
                          fontSize: 13,
                          height: 1.8,
                          fontFamily: "monospace",
                        ),
                        textAlign: TextAlign.center,
                      ),
                    )
                  : ListView.builder(
                      controller: _logScrollController,
                      itemCount: _logs.length,
                      itemBuilder: (context, index) {
                        final log = _logs[index];
                        Color textColor = primaryWhite;
                        
                        // Color coding untuk log
                        if (log.contains("SUCCESS")) {
                          textColor = const Color(0xFF22C55E);
                        } else if (log.contains("PENDING")) {
                          textColor = accentRed;
                        } else if (log.contains("TERMINATED") || log.contains("ERROR")) {
                          textColor = accentRed;
                        } else if (log.startsWith(">")) {
                          textColor = accentRed;
                        }
                        
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Text(
                            log,
                            style: TextStyle(
                              color: textColor,
                              fontSize: 12,
                              height: 1.5,
                              fontFamily: "monospace",
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ),

          // Status Bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            color: subtleRed,
            child: Row(
              children: [
                Text(
                  "[${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}:${DateTime.now().second.toString().padLeft(2, '0')}]",
                  style: TextStyle(
                    color: secondaryGrey,
                    fontSize: 11,
                    fontFamily: "monospace",
                  ),
                ),
                const SizedBox(width: 16),
                Text(
                  "LINES: ${_logs.length}",
                  style: TextStyle(
                    color: secondaryGrey,
                    fontSize: 11,
                    fontFamily: "monospace",
                  ),
                ),
                const Spacer(),
                Text(
                  _isAttacking ? "PROCESSING" : "STANDBY",
                  style: TextStyle(
                    color: _isAttacking ? accentRed : secondaryGrey,
                    fontSize: 11,
                    fontFamily: "monospace",
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}