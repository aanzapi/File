import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // <-- TAMBAHKAN INI
import 'package:http/http.dart' as http;
import 'theme_provider.dart'; // <-- TAMBAHKAN INI

class Ayat {
  final int nomor;
  final String arab;
  final String arti;

  Ayat({
    required this.nomor,
    required this.arab,
    required this.arti,
  });
}

class Surat {
  final int nomor;
  final String nama;
  final String latin;
  final List<Ayat> ayat;

  Surat({
    required this.nomor,
    required this.nama,
    required this.latin,
    required this.ayat,
  });
}

class AlQuranPage extends StatefulWidget {
  const AlQuranPage({super.key});

  @override
  State<AlQuranPage> createState() => _AlQuranPageState();
}

class _AlQuranPageState extends State<AlQuranPage> {
  bool loading = true;
  List<Surat> suratList = [];

  @override
  void initState() {
    super.initState();
    _loadQuran();
  }

  Future<void> _loadQuran() async {
    try {
      final arabRes = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/quran/quran-uthmani'),
      );
      final indoRes = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/quran/id.indonesian'),
      );

      final arabData = jsonDecode(arabRes.body);
      final indoData = jsonDecode(indoRes.body);

      final List arabSurah = arabData['data']['surahs'];
      final List indoSurah = indoData['data']['surahs'];

      List<Surat> result = [];

      for (int i = 0; i < arabSurah.length; i++) {
        final List arabAyat = arabSurah[i]['ayahs'];
        final List indoAyat = indoSurah[i]['ayahs'];

        List<Ayat> ayatList = [];

        for (int j = 0; j < arabAyat.length; j++) {
          ayatList.add(
            Ayat(
              nomor: arabAyat[j]['numberInSurah'],
              arab: arabAyat[j]['text'],
              arti: indoAyat[j]['text'],
            ),
          );
        }

        result.add(
          Surat(
            nomor: arabSurah[i]['number'],
            nama: arabSurah[i]['name'],
            latin: arabSurah[i]['englishName'],
            ayat: ayatList,
          ),
        );
      }

      setState(() {
        suratList = result;
        loading = false;
      });
    } catch (e) {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final bgColor = theme.scaffoldBackgroundColor;
    final cardColor = theme.cardColor;
    
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: bgColor,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'AL-QUR\'AN',
          style: TextStyle(
            fontFamily: 'Orbitron',
            letterSpacing: 2,
          ),
        ),
      ),
      body: loading
          ? Center(
              child: CircularProgressIndicator(
                color: accentColor,
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: suratList.length,
              itemBuilder: (context, index) {
                return _suratCard(suratList[index]);
              },
            ),
    );
  }

  Widget _suratCard(Surat surat) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final cardColor = theme.cardColor;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: accentColor.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withOpacity(0.3),
            blurRadius: 16,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ExpansionTile(
        iconColor: accentColor,
        collapsedIconColor: accentColor.withOpacity(0.7),
        collapsedTextColor: accentColor.withOpacity(0.7),
        textColor: accentColor,
        title: Text(
          '${surat.nomor}. ${surat.latin}',
          style: TextStyle(
            fontFamily: 'Orbitron',
            color: accentColor,
            letterSpacing: 1.5,
            fontWeight: FontWeight.w500,
          ),
        ),
        subtitle: Text(
          surat.nama,
          textAlign: TextAlign.right,
          style: const TextStyle(
            fontSize: 18,
            color: Colors.white70,
          ),
        ),
        children: surat.ayat.map(_ayatTile).toList(),
      ),
    );
  }

  Widget _ayatTile(Ayat ayat) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: primaryColor.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              'Ayat ${ayat.nomor}',
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: accentColor.withOpacity(0.7),
                fontSize: 12,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            ayat.arab,
            textAlign: TextAlign.right,
            style: const TextStyle(
              fontSize: 24,
              height: 1.9,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: accentColor.withOpacity(0.3),
              ),
            ),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                ayat.arti,
                style: TextStyle(
                  fontSize: 14,
                  color: accentColor.withOpacity(0.7),
                  height: 1.5,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Divider(
            color: accentColor.withOpacity(0.3),
            thickness: 1,
          ),
        ],
      ),
    );
  }
}