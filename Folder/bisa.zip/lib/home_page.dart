import 'dart:convert';
import 'dart:ui'; // Untuk ImageFilter
import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // <-- TAMBAHKAN INI
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'theme_provider.dart'; // <-- TAMBAHKAN INI

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  String selectedBugId = "";

  // --- Mode Target ---
  String _selectedBugMode = "number";

  bool _isSending = false;
  String? _responseMessage;

  // Video Player Variables
  late VideoPlayerController _videoController;
  late ChewieController _chewieController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _initializeVideoPlayer();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');

    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(0.1);
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          autoInitialize: true,
        );
        _isVideoInitialized = true;
      });
    }).catchError((error) {
      print("Video initialization error: $error");
      setState(() {
        _isVideoInitialized = false;
      });
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    _videoController.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("❌ Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final res = await http.get(Uri.parse(
          "http://rasyaprivat.orang-gantengg.biz.id:2106/sendBug?key=$key&target=$rawInput&bug=$selectedBugId"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Gagal: Server sedang maintenance.");
      } else {
        setState(() => _responseMessage = "✅ Berhasil mengirim bug!");
        targetController.clear();
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Theme.of(context).dialogBackgroundColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: Theme.of(context).colorScheme.secondary.withOpacity(0.5), width: 1),
        ),
        title: Text(title,
            style: TextStyle(
              color: Theme.of(context).colorScheme.secondary,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
            )),
        content: Text(msg,
            style: TextStyle(
                color: Colors.grey.shade600,
                fontFamily: 'ShareTechMono'
            )),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK",
                style: TextStyle(
                  color: Theme.of(context).primaryColor,
                  fontWeight: FontWeight.bold,
                )),
          ),
        ],
      ),
    );
  }

  // WIDGET DENGAN EFEK GLOW (MENGGUNAKAN THEME)
  Widget _buildGlowContainer({
    required Widget child,
    double blurRadius = 20,
    double spreadRadius = 1,
    Color? glowColor,
    double opacity = 0.3,
    BorderRadius? borderRadius,
  }) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        borderRadius: borderRadius,
        boxShadow: [
          BoxShadow(
            color: (glowColor ?? theme.primaryColor).withOpacity(opacity),
            blurRadius: blurRadius,
            spreadRadius: spreadRadius,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _buildGlowText({
    required String text,
    required TextStyle style,
    double blurRadius = 10,
    Color? glowColor,
  }) {
    final theme = Theme.of(context);
    return Text(
      text,
      style: style.copyWith(
        shadows: [
          Shadow(
            color: (glowColor ?? theme.primaryColor).withOpacity(0.5),
            blurRadius: blurRadius,
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderPanel() {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    
    return _buildGlowContainer(
      blurRadius: 30,
      spreadRadius: 2,
      opacity: 0.2,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: theme.cardColor.withOpacity(0.3),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
        ),
        child: Row(
          children: [
            // Logo Container dengan glow
            _buildGlowContainer(
              blurRadius: 25,
              spreadRadius: 2,
              opacity: 0.4,
              glowColor: accentColor,
              borderRadius: BorderRadius.circular(40),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [primaryColor, accentColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: CircleAvatar(
                  radius: 35,
                  backgroundColor: Colors.transparent,
                  backgroundImage: AssetImage('assets/images/logo.png'),
                ),
              ),
            ),
            const SizedBox(width: 20),
            // User Info Column
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildGlowText(
                    text: widget.username,
                    style: const TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 22,
                      letterSpacing: 1.0,
                    ),
                    blurRadius: 15,
                  ),
                  const SizedBox(height: 8),
                  _buildGlowContainer(
                    blurRadius: 15,
                    spreadRadius: 0.5,
                    opacity: 0.15,
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: primaryColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: accentColor.withOpacity(0.3), width: 1),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.badge, color: accentColor, size: 14),
                          const SizedBox(width: 6),
                          Text(
                            widget.role.toUpperCase(),
                            style: TextStyle(
                              color: accentColor,
                              fontFamily: 'ShareTechMono',
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(width: 1, height: 12, color: accentColor.withOpacity(0.3)),
                          const SizedBox(width: 8),
                          Icon(Icons.timer, color: accentColor, size: 14),
                          const SizedBox(width: 6),
                          Text(
                            widget.expiredDate,
                            style: TextStyle(
                              color: accentColor,
                              fontFamily: 'ShareTechMono',
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoPlayer() {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    
    if (!_isVideoInitialized) {
      return _buildGlowContainer(
        blurRadius: 20,
        spreadRadius: 1,
        opacity: 0.15,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          width: double.infinity,
          height: 200,
          margin: const EdgeInsets.symmetric(vertical: 20),
          decoration: BoxDecoration(
            color: theme.cardColor.withOpacity(0.3),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withOpacity(0.05)),
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(
                  color: accentColor,
                  strokeWidth: 3,
                ),
                const SizedBox(height: 12),
                Text(
                  "Loading Video...",
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return _buildGlowContainer(
      blurRadius: 40,
      spreadRadius: 3,
      opacity: 0.3,
      glowColor: accentColor,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: accentColor.withOpacity(0.3), width: 1.5),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: AspectRatio(
            aspectRatio: _videoController.value.aspectRatio,
            child: Stack(
              children: [
                Chewie(controller: _chewieController),
                // Overlay gradient
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        theme.primaryColor.withOpacity(0.2),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildModeSelector() {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedBugMode = "number";
                targetController.clear();
              });
            },
            child: _buildGlowContainer(
              blurRadius: _selectedBugMode == "number" ? 25 : 10,
              spreadRadius: _selectedBugMode == "number" ? 2 : 0.5,
              opacity: _selectedBugMode == "number" ? 0.4 : 0.1,
              glowColor: accentColor,
              borderRadius: BorderRadius.circular(16),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  color: _selectedBugMode == "number"
                      ? accentColor.withOpacity(0.15)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: _selectedBugMode == "number" ? accentColor : Colors.white.withOpacity(0.05),
                    width: _selectedBugMode == "number" ? 2 : 1,
                  ),
                ),
                child: Column(
                  children: [
                    Icon(
                      Icons.phone_android_rounded,
                      color: _selectedBugMode == "number" ? accentColor : Colors.grey.shade600,
                      size: 28,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      "BUG NOMOR",
                      style: TextStyle(
                        color: _selectedBugMode == "number" ? accentColor : Colors.grey.shade600,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedBugMode = "group";
                targetController.clear();
              });
            },
            child: _buildGlowContainer(
              blurRadius: _selectedBugMode == "group" ? 25 : 10,
              spreadRadius: _selectedBugMode == "group" ? 2 : 0.5,
              opacity: _selectedBugMode == "group" ? 0.4 : 0.1,
              glowColor: accentColor,
              borderRadius: BorderRadius.circular(16),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  color: _selectedBugMode == "group"
                      ? accentColor.withOpacity(0.15)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: _selectedBugMode == "group" ? accentColor : Colors.white.withOpacity(0.05),
                    width: _selectedBugMode == "group" ? 2 : 1,
                  ),
                ),
                child: Column(
                  children: [
                    Icon(
                      Icons.group_add,
                      color: _selectedBugMode == "group" ? accentColor : Colors.grey.shade600,
                      size: 28,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      "BUG GROUP",
                      style: TextStyle(
                        color: _selectedBugMode == "group" ? accentColor : Colors.grey.shade600,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInputPanel() {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // MODE SELECTOR
        _buildModeSelector(),

        const SizedBox(height: 30),

        // LABEL INPUT
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 16,
                decoration: BoxDecoration(
                  color: accentColor,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              const SizedBox(width: 8),
              _buildGlowText(
                text: _selectedBugMode == "number" ? "NOMOR TARGET" : "LINK GROUP WA",
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
                blurRadius: 8,
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),

        // INPUT FIELD DENGAN GLOW
        _buildGlowContainer(
          blurRadius: 20,
          spreadRadius: 1,
          opacity: 0.15,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            decoration: BoxDecoration(
              color: theme.cardColor.withOpacity(0.3),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
            ),
            child: TextField(
              controller: targetController,
              style: const TextStyle(color: Colors.white, fontSize: 16),
              cursorColor: accentColor,
              keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
              decoration: InputDecoration(
                hintText: _selectedBugMode == "number"
                    ? "Contoh: +62xxxxxxxxxx"
                    : "Contoh: https://chat.whatsapp.com/...",
                hintStyle: TextStyle(color: Colors.grey.shade600.withOpacity(0.5)),
                filled: true,
                fillColor: Colors.transparent,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide.none,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide.none,
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide(color: accentColor, width: 2),
                ),
                prefixIcon: Container(
                  margin: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: accentColor.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link,
                    color: accentColor,
                    size: 20,
                  ),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
              ),
            ),
          ),
        ),

        const SizedBox(height: 30),

        // LABEL PILIH BUG
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 16,
                decoration: BoxDecoration(
                  color: accentColor,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              const SizedBox(width: 8),
              _buildGlowText(
                text: "PILIH BUG",
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
                blurRadius: 8,
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),

        // DROPDOWN BUG DENGAN GLOW
        _buildGlowContainer(
          blurRadius: 20,
          spreadRadius: 1,
          opacity: 0.15,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: theme.cardColor.withOpacity(0.3),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: theme.scaffoldBackgroundColor,
                value: selectedBugId,
                isExpanded: true,
                iconEnabledColor: accentColor,
                iconSize: 28,
                style: const TextStyle(color: Colors.white, fontSize: 16, fontFamily: 'ShareTechMono'),
                items: widget.listBug.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Row(
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: accentColor,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            bug['bug_name'],
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedBugId = value ?? "";
                  });
                },
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSendButton() {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return _buildGlowContainer(
          blurRadius: 30 + (_pulseController.value * 20),
          spreadRadius: 2 + (_pulseController.value * 2),
          opacity: 0.4 + (_pulseController.value * 0.2),
          glowColor: accentColor,
          borderRadius: BorderRadius.circular(24),
          child: Container(
            height: 70,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, accentColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.white.withOpacity(0.3), width: 1),
            ),
            child: ElevatedButton(
              onPressed: _isSending ? null : _sendBug,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
                elevation: 0,
              ),
              child: _isSending
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(
                          height: 24,
                          width: 24,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 3,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          "MENGIRIM...",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                            letterSpacing: 2,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 24),
                        const SizedBox(width: 12),
                        _buildGlowText(
                          text: "SEND BUG ATTACK",
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 18,
                            letterSpacing: 2,
                            fontFamily: 'Orbitron',
                          ),
                          blurRadius: 15,
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color glowColor;
    IconData icon;

    if (_responseMessage!.startsWith('✅')) {
      glowColor = Colors.green;
      icon = Icons.check_circle_outline_rounded;
    } else if (_responseMessage!.startsWith('❌')) {
      glowColor = Colors.red;
      icon = Icons.error_outline_rounded;
    } else {
      glowColor = Theme.of(context).colorScheme.secondary;
      icon = Icons.info_outline_rounded;
    }

    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: _buildGlowContainer(
        blurRadius: 20,
        spreadRadius: 1,
        opacity: 0.3,
        glowColor: glowColor,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor.withOpacity(0.3),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: glowColor.withOpacity(0.3), width: 1),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: glowColor.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: glowColor, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _responseMessage!,
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    
    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: Stack(
        children: [
          // Background dengan efek blur
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center,
                radius: 1.2,
                colors: [
                  theme.scaffoldBackgroundColor,
                  primaryColor.withOpacity(0.15),
                  theme.scaffoldBackgroundColor,
                ],
                stops: const [0.3, 0.7, 1.0],
              ),
            ),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
              child: Container(
                color: Colors.transparent,
              ),
            ),
          ),
          
          // Efek glow besar di background
          Positioned(
            top: -150,
            right: -100,
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.15),
                    blurRadius: 200,
                    spreadRadius: 100,
                  ),
                ],
              ),
            ),
          ),
          
          Positioned(
            bottom: -100,
            left: -50,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withOpacity(0.1),
                    blurRadius: 150,
                    spreadRadius: 50,
                  ),
                ],
              ),
            ),
          ),
          
          // Konten utama
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Header dengan glow
                  _buildHeaderPanel(),
                  const SizedBox(height: 20),
                  
                  // Video Player dengan glow
                  _buildVideoPlayer(),
                  const SizedBox(height: 20),
                  
                  // Input Panel dengan glow
                  _buildInputPanel(),
                  const SizedBox(height: 40),
                  
                  // Send Button dengan glow animasi
                  _buildSendButton(),
                  
                  // Response Message dengan glow
                  _buildResponseMessage(),
                  
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}