import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider extends ChangeNotifier {
  static const String _primaryColorKey = 'primary_color';
  static const String _accentColorKey = 'accent_color';
  static const String _isDarkModeKey = 'is_dark_mode';
  
  Color _primaryColor = Colors.purple; // Default sesuai tema Anda (purple)
  Color _accentColor = Colors.purpleAccent;
  bool _isDarkMode = true; // Default dark mode karena Anda pakai Brightness.dark
  
  ThemeProvider() {
    loadThemeFromPrefs();
  }
  
  Color get primaryColor => _primaryColor;
  Color get accentColor => _accentColor;
  bool get isDarkMode => _isDarkMode;
  
  Future<void> loadThemeFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    
    final primaryColorValue = prefs.getInt(_primaryColorKey);
    final accentColorValue = prefs.getInt(_accentColorKey);
    final isDarkModeValue = prefs.getBool(_isDarkModeKey);
    
    if (primaryColorValue != null) {
      _primaryColor = Color(primaryColorValue);
    }
    
    if (accentColorValue != null) {
      _accentColor = Color(accentColorValue);
    }
    
    if (isDarkModeValue != null) {
      _isDarkMode = isDarkModeValue;
    }
    
    notifyListeners();
  }
  
  Future<void> setPrimaryColor(Color color) async {
    _primaryColor = color;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_primaryColorKey, color.value);
    notifyListeners();
  }
  
  Future<void> setAccentColor(Color color) async {
    _accentColor = color;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_accentColorKey, color.value);
    notifyListeners();
  }
  
  Future<void> toggleDarkMode() async {
    _isDarkMode = !_isDarkMode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_isDarkModeKey, _isDarkMode);
    notifyListeners();
  }
  
  Future<void> resetToDefault() async {
    _primaryColor = Colors.purple;
    _accentColor = Colors.purpleAccent;
    _isDarkMode = true;
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_primaryColorKey, Colors.purple.value);
    await prefs.setInt(_accentColorKey, Colors.purpleAccent.value);
    await prefs.setBool(_isDarkModeKey, true);
    
    notifyListeners();
  }
}