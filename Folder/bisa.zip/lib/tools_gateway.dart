import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'al_quran.dart';
import 'theme_provider.dart';

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final bgColor = theme.scaffoldBackgroundColor;
    
    return Scaffold(
      backgroundColor: bgColor,
      body: Stack(
        children: [
          // Background dengan efek blur
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 1.2,
                  colors: [
                    bgColor,
                    primaryColor,
                    bgColor,
                  ],
                  stops: const [0.3, 0.7, 1.0],
                ),
              ),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
                child: Container(
                  color: Colors.transparent,
                ),
              ),
            ),
          ),
          
          // Efek glow besar di background
          Positioned(
            top: -150,
            right: -100,
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.15),
                    blurRadius: 200,
                    spreadRadius: 100,
                  ),
                ],
              ),
            ),
          ),
          
          Positioned(
            bottom: -100,
            left: -50,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withOpacity(0.1),
                    blurRadius: 150,
                    spreadRadius: 50,
                  ),
                ],
              ),
            ),
          ),
          
          // Konten utama
          SafeArea(
            child: Column(
              children: [
                // === HEADER ===
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        primaryColor.withOpacity(0.3),
                        accentColor.withOpacity(0.2),
                        primaryColor.withOpacity(0.3),
                      ],
                    ),
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                    border: Border.all(color: accentColor.withOpacity(0.3), width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: accentColor.withOpacity(0.2),
                        blurRadius: 20,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: accentColor.withOpacity(0.2),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: accentColor.withOpacity(0.4),
                                  blurRadius: 15,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                            child: Icon(Icons.build_circle_outlined,
                                color: Colors.white, size: 28),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            "TOOLS DASHBOARD",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                              shadows: [
                                Shadow(
                                  color: accentColor.withOpacity(0.5),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Advanced Security & OSINT Tools",
                        style: TextStyle(
                          color: Colors.grey.shade400,
                          fontSize: 14,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),

                // === CATEGORY CARDS ===
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: GridView.count(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 1.2,
                      children: [
                        // DDoS Tools
                        _buildToolCard(
                          icon: Icons.flash_on,
                          title: "DDoS Tools",
                          subtitle: "Attack & Server",
                          primaryColor: primaryColor,
                          accentColor: accentColor,
                          onTap: () => _showDDoSTools(context),
                        ),

                        // Network Tools
                        _buildToolCard(
                          icon: Icons.wifi,
                          title: "Network",
                          subtitle: "WiFi & Spam",
                          primaryColor: primaryColor,
                          accentColor: accentColor,
                          onTap: () => _showNetworkTools(context),
                        ),

                        // OSINT Tools
                        _buildToolCard(
                          icon: Icons.search,
                          title: "OSINT",
                          subtitle: "Investigation",
                          primaryColor: primaryColor,
                          accentColor: accentColor,
                          onTap: () => _showOSINTTools(context),
                        ),

                        // Media Downloader
                        _buildToolCard(
                          icon: Icons.download,
                          title: "Downloader",
                          subtitle: "Social Media",
                          primaryColor: primaryColor,
                          accentColor: accentColor,
                          onTap: () => _showDownloaderTools(context),
                        ),

                        // Additional Tools
                        _buildToolCard(
                          icon: Icons.build,
                          title: "Utilities",
                          subtitle: "Extra Tools",
                          primaryColor: primaryColor,
                          accentColor: accentColor,
                          onTap: () => _showUtilityTools(context),
                        ),

                        // Quick Access
                        _buildToolCard(
                          icon: Icons.rocket_launch,
                          title: "Quick Access",
                          subtitle: "Favorites",
                          primaryColor: primaryColor,
                          accentColor: accentColor,
                          onTap: () => _showQuickAccess(context),
                        ),

                        // AL-QUR'AN
                        _buildToolCard(
                          icon: Icons.menu_book,
                          title: "AL-QUR'AN",
                          subtitle: "Digital Quran",
                          primaryColor: primaryColor,
                          accentColor: accentColor,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const AlQuranPage(),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToolCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color primaryColor,
    required Color accentColor,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeOutBack,
      builder: (context, double scale, child) {
        return Transform.scale(
          scale: scale,
          child: Container(
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: accentColor.withOpacity(0.2),
                  blurRadius: 15,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: child,
          ),
        );
      },
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                primaryColor.withOpacity(0.3),
                accentColor.withOpacity(0.2),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: accentColor.withOpacity(0.3), width: 1),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [primaryColor, accentColor],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.grey.shade400.withOpacity(0.3)),
                    boxShadow: [
                      BoxShadow(
                        color: accentColor.withOpacity(0.3),
                        blurRadius: 10,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: Icon(icon, color: Colors.white, size: 24),
                ),
                const SizedBox(height: 10),
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(
                        color: accentColor.withOpacity(0.5),
                        blurRadius: 5,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Colors.grey.shade400,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildToolOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    BuildContext? context, // Tambahkan parameter context opsional
  }) {
    // Gunakan context dari parameter atau dari Builder
    return Builder(
      builder: (context) {
        final theme = Theme.of(context);
        final accentColor = theme.colorScheme.secondary;
        
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: accentColor.withOpacity(0.15),
                blurRadius: 10,
                spreadRadius: 0,
              ),
            ],
          ),
          child: Card(
            color: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
              side: BorderSide(color: accentColor.withOpacity(0.3), width: 1),
            ),
            elevation: 4,
            shadowColor: accentColor.withOpacity(0.2),
            child: ListTile(
              leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: accentColor.withOpacity(0.2),
                  shape: BoxShape.circle,
                  border: Border.all(color: accentColor.withOpacity(0.3)),
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.3),
                      blurRadius: 8,
                      spreadRadius: 0,
                    ),
                  ],
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              title: Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w500,
                ),
              ),
              trailing: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: accentColor.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.arrow_forward_ios, color: color, size: 14),
              ),
              onTap: onTap,
            ),
          ),
        );
      },
    );
  }

  void _showDDoSTools(BuildContext context) {
    _showBottomSheet(
      context,
      title: "DDoS Tools",
      icon: Icons.flash_on,
      children: [
        _buildToolOption(
          icon: Icons.flash_on,
          label: "Attack Panel",
          color: Colors.grey.shade400,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AttackPanel(
                  sessionKey: sessionKey,
                  listDoos: listDoos,
                ),
              ),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.dns,
          label: "Manage Server",
          color: Colors.grey.shade400,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ManageServerPage(keyToken: sessionKey),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    List<Widget> children = [
      _buildToolOption(
        icon: Icons.newspaper_outlined,
        label: "Spam NGL",
        color: Colors.grey.shade400,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => NglPage()),
          );
        },
      ),
      _buildToolOption(
        icon: Icons.wifi_off,
        label: "WiFi Killer (Internal)",
        color: Colors.grey.shade400,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => WifiKillerPage()),
          );
        },
      ),
    ];

    if (userRole == "vip" || userRole == "owner") {
      children.add(
        _buildToolOption(
          icon: Icons.router,
          label: "WiFi Killer (External)",
          color: Colors.grey.shade400,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => WifiInternalPage(sessionKey: sessionKey),
              ),
            );
          },
        ),
      );
    }

    _showBottomSheet(
      context,
      title: "Network Tools",
      icon: Icons.wifi,
      children: children,
    );
  }

  void _showOSINTTools(BuildContext context) {
    _showBottomSheet(
      context,
      title: "OSINT Tools",
      icon: Icons.search,
      children: [
        _buildToolOption(
          icon: Icons.badge,
          label: "NIK Detail",
          color: Colors.grey.shade400,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NikCheckerPage()),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.domain,
          label: "Domain OSINT",
          color: Colors.grey.shade400,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const DomainOsintPage()),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.person_search,
          label: "Phone Lookup",
          color: Colors.grey.shade400,
          onTap: () => _showComingSoon(context),
        ),
        _buildToolOption(
          icon: Icons.email,
          label: "Email OSINT",
          color: Colors.grey.shade400,
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    _showBottomSheet(
      context,
      title: "Media Downloader",
      icon: Icons.download,
      children: [
        _buildToolOption(
          icon: Icons.video_library,
          label: "TikTok Downloader",
          color: Colors.grey.shade400,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.camera_alt,
          label: "Instagram Downloader",
          color: Colors.grey.shade400,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()),
            );
          },
        ),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    _showBottomSheet(
      context,
      title: "Utility Tools",
      icon: Icons.build,
      children: [
        _buildToolOption(
          icon: Icons.qr_code,
          label: "QR Generator",
          color: Colors.grey.shade400,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const QrGeneratorPage()),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.security,
          label: "IP Scanner",
          color: Colors.grey.shade400,
          onTap: () => _showComingSoon(context),
        ),
        _buildToolOption(
          icon: Icons.network_check,
          label: "Port Scanner",
          color: Colors.grey.shade400,
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  void _showQuickAccess(BuildContext context) {
    _showComingSoon(context);
  }

  void _showBottomSheet(BuildContext context, {
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor.withOpacity(0.95),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(30),
          ),
          border: Border.all(color: accentColor.withOpacity(0.3), width: 1),
          boxShadow: [
            BoxShadow(
              color: accentColor.withOpacity(0.2),
              blurRadius: 30,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryColor, accentColor],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withOpacity(0.3),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, color: Colors.white),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          color: Color(0x4CFFFFFF),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: ListView(
                  children: children,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: accentColor.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.hourglass_top, color: Colors.white),
            ),
            const SizedBox(width: 8),
            const Text(
              'Feature Coming Soon!',
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
        backgroundColor: primaryColor,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: accentColor.withOpacity(0.5)),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}